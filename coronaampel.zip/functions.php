<?php
	$GLOBALS['php_start'] = time();
	error_reporting(E_ALL);
	set_error_handler(function ($severity, $message, $file, $line) {
		throw new \ErrorException($message, $severity, $severity, $file, $line);
	});

	ini_set('display_errors', 1);

	header_remove("X-Powered-By"); // Serverinfos entfernen

	// Definition globaler Variablen
	$GLOBALS['insert_anlage_failed'] = 0;
	$GLOBALS['error'] = array();
	$GLOBALS['mysql_error'] = array();
	$GLOBALS['hint'] = array();
	$GLOBALS['message'] = array();
	$GLOBALS['warning'] = array();
	$GLOBALS['mysql_warning'] = array();
	$GLOBALS['trash'] = array();
	$GLOBALS['success'] = array();
	$GLOBALS['debug'] = array();
	$GLOBALS['easter_egg'] = array();
	$GLOBALS['number_of_non_month_columns'] = 7;
	$GLOBALS['import_table'] = '';
	$GLOBALS['return_null_if_anlage_creation_failed'] = 1;
	$GLOBALS['show_backtrace'] = 0;
	if(file_exists('/etc/show_trace')) {
		$GLOBALS['show_backtrace'] = 1;
	}

	$GLOBALS['compare_db'] = '';

	$GLOBALS['already_deleted_old_session_ids'] = 0;

	$GLOBALS['submenu_id'] = null;

	$GLOBALS['end_html'] = 1;

	$GLOBALS['slurped_sql_file'] = 0;

	$GLOBALS['deletion_page'] = 0;

	$GLOBALS['rquery_print'] = 0;

	$GLOBALS['queries'] = array();
	$GLOBALS['function_usage'] = array();

	$GLOBALS['dbh'] = '';
	$GLOBALS['right_issue'] = array();
	$GLOBALS['reload_page'] = 0;

	$GLOBALS['get_anlagen_name_by_id_cache'] = array();
	$GLOBALS['get_kunde_name_by_id_cache'] = array();
	$GLOBALS['get_anlage_name_by_id_cache'] = array();
	$GLOBALS['get_wartungen_pro_monat_from_anlage_id_cache'] = array();
	$GLOBALS['get_wartungen_pro_monat_from_anlage_id_cache'] = array();
	$GLOBALS['get_anlage_comment_and_ansprechpartner_id_zeit_pro_wartung_cache'] = array();
	$GLOBALS['get_ansprechpartner_by_anlage_id_cache'] = array();
	$GLOBALS['get_h_pro_wartung_cache'] = array();
	$GLOBALS['get_material_wartung_cache'] = array();
	$GLOBALS['get_anlage_comment_cache'] = array();
	$GLOBALS['get_addressdaten_cache'] = array();
	$GLOBALS['get_kunden_array_cache'] = array();
	$GLOBALS['get_statistik_gebrauchte_zeit_pro_wartung_cache'] = array();
	$GLOBALS['get_wartungspauschale_cache'] = array();
	$GLOBALS['get_naechste_wartung_cache'][0] = array();
	$GLOBALS['get_naechste_wartung_cache'][1] = array();
	$GLOBALS['create_select_for_kunden_cache'] = array();
	$GLOBALS['ibn_beendet_cache'] = array();
	$GLOBALS['anlagendaten_cache'] = array();
	$GLOBALS['get_erinnerung_pruefung_and_pruefung_ortsfester_anlagen_cache'] = array();
	$GLOBALS['get_anzahl_anlagen_pro_kunde_cache_old'] = array();
	$GLOBALS['get_anzahl_anlagen_pro_kunde_cache'] = array();
	$GLOBALS['get_anlagen_cache'] = array();
	$GLOBALS['get_anlagen_data_cache'] = array();
	$GLOBALS['get_turnus_cache'] = array();
	$GLOBALS['termin_already_exists_cache'] = array();
	$GLOBALS['get_year_month_from_termin_id_cache'] = array();
	$GLOBALS['user_role_cache'] = array();
	$GLOBALS['settings_cache'] = array();
	$GLOBALS['table_exists_cache'] = array();
	$GLOBALS['db_exists_cache'] = array();
	$GLOBALS['get_ende_gewaehrleistung_cache'][0][0] = array();
	$GLOBALS['get_ende_gewaehrleistung_cache'][0][1] = array();
	$GLOBALS['get_ende_gewaehrleistung_cache'][1][0] = array();
	$GLOBALS['get_ende_gewaehrleistung_cache'][1][1] = array();
	$GLOBALS['get_ansprechpartner_daten_cache'] = array();
	$GLOBALS['get_turnus_name_by_id_cache'] = array();
	$GLOBALS['create_select_for_status_array'] = array();
	$GLOBALS['get_ansprechpartner_telnr_cache'] = array();
	$GLOBALS['get_ansprechpartner_email_cache'] = array();
	$GLOBALS['get_ansprechpartner_name_cache'] = array();
	$GLOBALS['status_color_cache'] = array();

	$GLOBALS['memoize'] = array();

	include_once('mysql.php');

	if(!isset($GLOBALS['setup_mode'])) {
		$GLOBALS['setup_mode'] = 0;
	}

	if(file_exists('new_setup')) {
		$GLOBALS['setup_mode'] = 1;
	}

	if(!$GLOBALS['setup_mode']) {
		if(!function_exists('mysqli_connect')) {
			dier("Das PHP-Plugin für MySQL-Verbindungen ist nicht installiert!");
		}
		if(!database_exists($GLOBALS['dbname'])) {
			rquery("CREATE DATABASE ".$GLOBALS['dbname']);
		}

		rquery('USE `'.$GLOBALS['dbname'].'`');
		rquery('SELECT @@FOREIGN_KEY_CHECKS');
		rquery('SET FOREIGN_KEY_CHECKS=1');
	}

	rquery("SET NAMES utf8");

	/* Login-Kram */
	$GLOBALS['logged_in_was_tried'] = 0;
	$GLOBALS['logged_in'] = 0;
	$GLOBALS['logged_in_user_id'] = NULL;
	$GLOBALS['logged_in_data'] = NULL;
	$GLOBALS['accepted_public_data'] = NULL;

	$GLOBALS['pages'] = array();

	if(!$GLOBALS['setup_mode']) {
		if(get_post('try_login')) {
			$GLOBALS['logged_in_was_tried'] = 1;
		}

		if(get_cookie('session_id')) {
			delete_old_session_ids();
			if(table_exists('view_user_session_id')) {
				try {
					$query = 'SELECT `user_id`, `username`, `accepted_public_data` FROM `view_user_session_id` WHERE `session_id` = '.
						esc($_COOKIE['session_id']).' AND `enabled` = "1"';
					$result = rquery($query, 0, 1);
					while ($row = mysqli_fetch_row($result)) {
						$GLOBALS['logged_in'] = 1;
						$GLOBALS['logged_in_data'] = $row;
						$GLOBALS['logged_in_user_id'] = $row[0];
						$GLOBALS['user_role_id'] = get_role_id_by_user($row[0]);
						$GLOBALS['accepted_public_data'] = $row[2];
					}
					$result->free();
				} catch (Exception $e) {
					$GLOBALS['logged_in'] = 0;
				}
			}
		}

		if (!$GLOBALS['logged_in'] && get_post('username') && get_post('password')) {
			delete_old_session_ids();
			$GLOBALS['logged_in_was_tried'] = 1;
			$user = $_POST['username'];
			$possible_user_id = get_user_id($user);
			$salt = get_salt($possible_user_id);
			$pass = hash('sha256', $_POST['password'].$salt);

			$query = 'SELECT `id`, `username`, `accepted_public_data` FROM `users` WHERE `username` = '.
				esc($user).' AND `password_sha256` = '.esc($pass).' AND `enabled` = "1"';
			$result = rquery($query);
			while ($row = mysqli_fetch_row($result)) {
				delete_old_session_ids($GLOBALS['logged_in_user_id']);
				$GLOBALS['logged_in'] = 1;
				$GLOBALS['logged_in_data'] = $row;
				$GLOBALS['logged_in_user_id'] = $row[0];
				$GLOBALS['user_role_id'] = get_role_id_by_user($row[0]);
				$GLOBALS['accepted_public_data'] = $row[2];

				$session_id = generate_random_string(1024);
				$query = 'INSERT IGNORE INTO `session_ids` (`session_id`, `user_id`) VALUES ('.esc($session_id).', '.esc($row[0]).')';
				rquery($query);

				setcookie('session_id', $session_id, time() + (86400 * 2), "/");
			}
			$result->free();
		}

		if($GLOBALS['logged_in_user_id'] && basename($_SERVER['SCRIPT_NAME']) == 'admin.php') {
			$query = 'SELECT `name`, `file`, `page_id`, `show_in_navigation`, `parent` FROM `view_account_to_role_pages` WHERE `user_id` = '.esc($GLOBALS['logged_in_user_id']);
			$query .= ' ORDER BY `parent`, `name`';
			$result = rquery($query);

			while ($row = mysqli_fetch_row($result)) {
				$GLOBALS['pages'][$row[2]] = $row;
			}
			$result->free();

			if(get_get('sdsg_einverstanden')) {
				$query = 'UPDATE `users` SET `accepted_public_data` = "1" WHERE `id` = '.esc($GLOBALS['logged_in_user_id']);
				rquery($query);

				$GLOBALS['accepted_public_data'] = 1;
			}
		}

		if(array_key_exists('REQUEST_URI', $_SERVER) && preg_match('/\/pages\//', $_SERVER['REQUEST_URI'])) {
			$script_name = basename($_SERVER['REQUEST_URI']);
			$page_id = get_page_id_by_filename($script_name);
			if($page_id) {
				$header = 'Location: ../admin.php?page='.$page_id;
				header($header);
			} else {
				die("Die internen Seiten dürfen nicht direkt aufgerufen werden. Die gesuchte Seite konnte im Index nicht gefunden werden. Nehmen Sie &mdash; statt der direkten URL &mdash; den Weg über das Administrationsmenü.");
			}
		}
	}

	/* Parameter verarbeiten */

	if($GLOBALS['logged_in']) { // Wichtig, damit Niemand ohne Anmeldung etwas ändern kann
		// Falls eine ID gegeben ist, dann sind bereits Daten vorhanden, die editiert oder gelöscht werden sollen.

		#dier($_POST);

		if(get_post("frage_id")) {
			if(get_post("delete_frage")) {
				delete_frage(get_post("frage_id"));
			} else {
				$frage_id = get_post("frage_id");
				$frage = get_post("frage");
				$antwort = get_post("antwort");

				$show_ampel = get_post("show_ampel") ? 1 : 0;
				$red = get_post("red") ? 1 : 0;
				$yellow = get_post("yellow") ? 1 : 0;
				$green = get_post("green") ? 1 : 0;

				update_frage($frage_id, $frage, $antwort, $show_ampel, $red, $yellow, $green);
			}
		}


		if(get_post('update_kommentar_from_ersatzteilewartung') && get_post('termin_id')) {
			set_comments(get_post('termin_id'), get_post('kommentar1'), get_post('kommentar2'));
		}

		if(get_post('verschiebe_anlage')) {
			$anlage_id = get_post('anlage_id');
			$neue_firma_id = get_post('neue_firma_id');

			$query = 'update anlagen set kunde_id = '.esc($neue_firma_id).' where id = '.esc($anlage_id);;
			if(rquery($query)) {
				success("Anlage wurde auf den neuen Kunden verschoben");
			} else {
				error("Anlage wurde NICHT auf den neuen Kunden verschoben");
			}
		}

		if(get_post('update_wartung_via_map')) {
			$wartung_id = get_post('update_wartung_via_map');
			$status_id = get_post('aendere_status');
			$kommentar1 = get_post('kommentar1');
			$kommentar2 = get_post('kommentar2');

			update_wartung_via_map($wartung_id, $status_id, $kommentar1, $kommentar2);
		}

		if(!is_null(get_post('id')) || !is_null(get_get('id'))) {
			$this_id = get_post('id');
			if(!$this_id) {
				$this_id = get_get('id');
			}
			if(get_post('delete') && !get_post('delete_for_sure')) {
				/*
					Festlegung der Tabellen, aus denen etwas gelöscht werden soll.
				 */
				$GLOBALS['deletion_page'] = 1;

				$GLOBALS['deletion_where'] = array('id' => $this_id);

				if(get_post('funktion_name')) {
					$GLOBALS['deletion_db'] = 'function_rights';
				}

				if(get_post('update_status')) {
					$GLOBALS['deletion_db'] = 'status';
				}

				if(get_post('update_turnus')) {
					$GLOBALS['deletion_db'] = 'turnus';
				}

				if(get_post('update_anlage')) {
					$GLOBALS['deletion_db'] = 'anlagen';
				}

				if(get_post('update_kunde')) {
					$GLOBALS['deletion_db'] = 'kunden';
				}

				if(get_post('update_wartungstermine')) {
					$GLOBALS['deletion_db'] = 'kunden';
				}

				if(get_post('neue_rolle') && get_post('page')) {
					$GLOBALS['deletion_db'] = 'role';
				}

				if(get_post('name') && get_post('id') && get_post('role')) {
					$GLOBALS['deletion_db'] = 'users';
				}

				if(get_post('updatepage') && get_post('id')) {
					$GLOBALS['deletion_db'] = 'page';
				}

				if(get_post('update_ersatzteil') && get_post('id')) {
					$GLOBALS['deletion_db'] = 'ersatzteil';
				}
			} else {
				/*

					(
						[id] => 1
						[update_ersatzteil] => 1
						[ersatzteil_name] => test 1
						[default_price] => 200.50
						[price] => 30
					)

				 */

				if(get_post('update_ersatzteil') && get_post('ersatzteil_name')) {
					$kundendaten = array();
					if(get_get('kunde') && get_get('kunde') != "alle" && get_post('kunden_price')) {
						$kunde_id = get_get('kunde');
						$kunde_price = get_post('kunden_price');
						$kundendaten = array(
							'kunde_id' => $kunde_id,
							'kunde_price' => $kunde_price
						);
					}

					update_ersatzteil(get_post('id'), get_post("ersatzteil_name"), get_post("default_price"), $kundendaten);
				}

				if(get_post('update_anlage') && get_post('delete') && get_post('id')) {
					delete_anlage(get_post('id'));
				}

				if(get_post('update_ersatzteil') && get_post('delete') && get_post('id')) {
					delete_ersatzteil(get_post('id'));
				}

				foreach ($_POST as $this_post_key => $this_post_value) {
					if (preg_match('/^update_anlage_(\d+)_for_(\d+)$/', $this_post_key, $founds)) {
						$anlage_id = $founds[1];
						$kunde_id = $founds[2];
						$name = get_post($founds[0]);

						$turnus = get_post('turnus');
						$ibn_beendet_am = get_post('ibn_beendet_am');
						$letzte_wartung = get_post('letzte_wartung');
						$ende_gewaehrleistung = get_post('ende_gewaehrleistung');
						$this_anlage_comment = get_post('this_anlage_comment');
						$wartungspauschale = get_post('wartungspauschale');

						$ansprechpartner_email = get_post('ansprechpartner_email');
						$ansprechpartner_telnr = get_post('ansprechpartner_telnr');
						$ansprechpartner_name = get_post('ansprechpartner_name');
						$ansprechpartner_id = get_or_create_ansprechpartner($ansprechpartner_email, $ansprechpartner_telnr, $ansprechpartner_name);

						$zeit_pro_wartung = get_post('zeit_pro_wartung');

						$plz = get_post("plz");
						$ort = get_post("ort");
						$strasse = get_post("strasse");
						$hausnummer = get_post("hausnummer");
						$land = get_post("land");

						$material_wartung = get_post("material_wartung");

						update_anlage($anlage_id, $name, $turnus, $ibn_beendet_am, $letzte_wartung, $ende_gewaehrleistung, $this_anlage_comment, $wartungspauschale, $ansprechpartner_id, $zeit_pro_wartung, $plz, $ort, $strasse, $hausnummer, $land, $material_wartung);
					}
				}

				if(get_post('update_status')) {
					$id = get_post('id');
					if(!get_post('delete')) {
						$name = get_post('name');
						$color = get_post('color');
						update_status($id, $name, $color);
					} else {
						delete_status($id);
					}
				}

				if(get_post('update_turnus')) {
					$id = get_post('id');
					if(!get_post('delete')) {
						$name = get_post('name');
						$anzahl_monate = get_post('anzahl_monate');
						$wartungen_pro_monat = get_post('wartungen_pro_monat');
						update_turnus($id, $name, $anzahl_monate, $wartungen_pro_monat);
					} else {
						delete_turnus($id);
					}
				}

				if(get_post('newpage')) {
					$titel = get_post('titel');
					$datei = get_post('datei');
					$show_in_navigation = get_post('show_in_navigation') ? 1 : 0;
					$eltern = get_post('eltern') ? get_post('eltern') : '';
					$role_to_page = get_post('role_to_page');
					$beschreibung = get_post('beschreibung') ? get_post('beschreibung') : '';
					$hinweis = get_post('hinweis') ? get_post('hinweis') : '';

					if(isset($titel) && isset($datei) && isset($show_in_navigation) && isset($eltern) && isset($role_to_page) && isset($beschreibung) && isset($hinweis)) {

						create_new_page($titel, $datei, $show_in_navigation, $eltern, $role_to_page, $beschreibung, $hinweis);
					} else {
						error('Missing parameters!');
					}
				}

				if(get_post('updatepage')) {
					$id = get_post('id');
					if(get_post('delete')) {
						if(isset($id)) {
							delete_page($id);
						}
					} else {
						$titel = get_post('titel');
						$datei = get_post('datei');
						$show_in_navigation = get_post('show_in_navigation') ? 1 : 0;
						$eltern = get_post('eltern') ? get_post('eltern') : '';
						$role_to_page = get_post('role_to_page');
						$beschreibung = get_post('beschreibung') ? get_post('beschreibung') : '';
						$hinweis = get_post('hinweis') ? get_post('hinweis') : '';

						if(isset($id) && isset($titel) && isset($role_to_page)) {
							update_page_full($id, $titel, $datei, $show_in_navigation, $eltern, $role_to_page, $beschreibung, $hinweis);
						} else {
							error('Missing parameters!');
						}
					}
				}

				if(get_post('funktion_name')) {
					if(get_post('delete')) {
						delete_funktion_rights($this_id);
					} else {
						update_funktion_rights($this_id, get_post('funktion_name'));
					}
				}

				if(get_post('update_page_info')) {
					update_page_info(get_post('id'), get_post('info'));
				}

				if(get_post_multiple_check(array('name', 'plz', 'ort')) && !get_post('delete') && !get_post("update_kunde")) {
					$name = get_post('name');
					$plz = get_post('plz');
					$ort = get_post('ort');
					$strasse = get_post('strasse');
					$hausnummern = get_post('hausnummern');
					$erinnerung = get_post('erinnerung');
					$pruefung = get_post("pruefung");
					$pruefung_abgelehnt = get_post("pruefung_abgelehnt");
					$phone = get_post("telefon");
					$email = get_post("email");
					$land = get_post("land");
					create_kunde($name, $plz, $ort, $strasse, $hausnummern, $erinnerung, $pruefung, $pruefung_abgelehnt, $phone, $email, $land);
				} else if (get_post('new_user')) {
					warning('Benutzer müssen einen Namen, ein Passwort und eine Rolle haben. ');
				}


				if(get_post('neue_rolle') && get_post('page')) {
					if(get_post('delete')) {
						delete_role($this_id);
					} else {
						update_role($this_id, get_post('neue_rolle'));
						$query = 'DELETE FROM `role_to_page` WHERE `role_id` = '.esc(get_role_id(get_post('neue_rolle')));;
						rquery($query);
						foreach (get_post('page') as $key => $this_page_id) {
							if(preg_match('/^\d+$/', $this_page_id)) {
								assign_page_to_role(get_role_id(get_post('neue_rolle')), $this_page_id);
							}
						}
					}
				}

				if(get_post('id') && get_post('update_kunde')) {
					if(get_post('delete')) {
						delete_kunde(get_post('id'));
					} else {
						$id = get_post("id");
						$name = get_post("name");
						$plz = get_post("plz");
						$ort = get_post("ort");
						$strasse = get_post("strasse");
						$hausnummern = get_post("hausnummern");
						$ibn_beendet_am = get_post("ibn_beendet_am");
						$turnus = get_post("turnus");
						$letzte_wartung = get_post("letzte_wartung");
						$erinnerung = get_post('erinnerung');
						$pruefung = get_post('pruefung');
						$pruefung_abgelehnt = get_post("pruefung_abgelehnt");
						$phone = get_post("telefon");
						$email = get_post("email");
						$land = get_post("land");

						update_kunde($id, $name, $plz, $ort, $strasse, $hausnummern, $erinnerung, $pruefung, $pruefung_abgelehnt, $phone, $email, $land);
					}
				}

				if(get_post('name') && get_post('id') && get_post('role')) {
					if(get_post('delete')) {
						delete_user($this_id);
					} else {
						$enabled = get_account_enabled_by_id($this_id);
						if(get_post('disable_account')) {
							$enabled = 0;
						}

						if(get_post('enable_account')) {
							$enabled = 1;
						}

						$accpubdata = 1;
						if(get_post('accepted_public_data')) {
							$accpubdata = 1;
						}

						update_user(get_post('name'), get_post('id'), get_post('password'), get_post('role'), $enabled, $accpubdata);
					}
				}
			}
		} else {
			if(get_post('update_gebrauchte_zeit_pro_wartung') && get_post('termin_id')) {
				$termin_id = get_post("termin_id");
				$update_zeit_pro_wartung = get_post("update_zeit_pro_wartung");
				add_gebrauchte_zeit_zu_wartung($termin_id, $update_zeit_pro_wartung);
			}
			/*
				Array
				(
					[edit_ersatzteil] => 3
					[update_termin_ersatzteil] => 1
					[spezialpreis] => 
					[amount] => 6
				)
			 */

			if(get_post('edit_ersatzteil') && get_post('update_termin_ersatzteil')) {
				$ersatzteil_id = get_post('edit_ersatzteil');
				$anzahl = get_post('amount');
				$spezialpreis = get_post('spezialpreis');
				$termin_id = get_get('terminid');
				update_termin_ersatzteil_2($ersatzteil_id, $anzahl, $termin_id, $spezialpreis);
			}

			#dier($_POST);

			if(get_post("neue_frage")) {
				$frage = get_post("frage");
				$antwort = get_post("antwort");

				$show_ampel = get_post("show_ampel") ? 1 : 0;
				$red = get_post("red") ? 1 : 0;
				$yellow = get_post("yellow") ? 1 : 0;
				$green = get_post("green") ? 1 : 0;

				create_frage($frage, $antwort, $show_ampel, $red, $yellow, $green);
			}


			if(get_post('create_ersatzteil') && get_post('ersatzteil_name')) {
				$kundendaten = array();
				if(get_get('kunde') && get_get('kunde') != "alle" && get_post('kunden_price')) {
					$kunde_id = get_get('kunde');
					$kunde_price = get_post('kunden_price');
					$kundendaten = array(
						'kunde_id' => $kunde_id,
						'kunde_price' => $kunde_price
					);
				}
				create_ersatzteil(get_post("ersatzteil_name"), get_post("default_price"), $kundendaten);
			}

			if(get_post('disable_termin') && !is_null(get_post('termin_id'))) {
				$termin_id = get_post('termin_id');

				disable_termin($termin_id);
			}

			if(get_post('disable_termin') && !is_null(get_post('termin_id'))) {
				$termin_id = get_post('termin_id');

				disable_termin($termin_id);
			}

			if(get_post('new_termin') && !is_null(get_post('anlage_id')) && get_post('monat') && get_post('year')) {
				$anlage_id = get_post('anlage_id');
				$monat = get_post('monat');
				$year = get_post('year');

				insert_wartungstermin($anlage_id, $monat, $year);
			}

			if(get_post('terminid') && get_post('new_jahr') && get_post('new_monat')) {
				verschiebe_termin(get_post('terminid'), get_post('new_jahr'), get_post('new_monat'), get_post('verschiebe_spaetere'));
			}

			if(get_post('terminid') && get_post('monat_diff')) {
				verschiebe_termin_um_monat(get_post('terminid'), get_post('monat_diff'), get_post('verschiebe_spaetere'));
			}

			if(get_post('create_anlage_page')) {
				foreach ($_POST as $this_post_key => $this_post_value) {
					if(preg_match('/^create_anlage_for_(\d+)/', $this_post_key, $founds)) {
						$name = get_post($founds[0]);
						$kunde_id = $founds[1];

						$turnus_id = get_post('turnus');
						$ibn_beendet_am = get_post('ibn_beendet_am');
						$letzte_wartung = get_post('letzte_wartung');
						$ende_gewaehrleistung = get_post('ende_gewaehrleistung');
						$this_anlage_comment = get_post('this_anlage_comment');
						$status_default_id = get_post('status_default');
						$wartungspauschale = get_post('wartungspauschale');

						$ansprechpartner_email = get_post('ansprechpartner_email');
						$ansprechpartner_telnr = get_post('ansprechpartner_telnr');
						$ansprechpartner_name = get_post('ansprechpartner_name');
						$ansprechpartner_id = get_or_create_ansprechpartner($ansprechpartner_email, $ansprechpartner_telnr, $ansprechpartner_name);

						$zeit_pro_wartung = get_post("zeit_pro_wartung");

						$plz = get_post("plz");
						$ort = get_post("ort");
						$strasse = get_post("strasse");
						$hausnummer = get_post("hausnummer");
						$land = get_post("land");

						$material_wartung = get_post("material_wartung");


						create_anlage($kunde_id, $name, $turnus_id, $ibn_beendet_am, $letzte_wartung, $ende_gewaehrleistung, $this_anlage_comment, $status_default_id, $wartungspauschale, $ansprechpartner_id, $zeit_pro_wartung, $plz, $ort, $strasse, $hausnummer, $land, $material_wartung);
					} else if (preg_match('/^update_anlage_(\d+)_for_(\d+)$/', $this_post_key, $founds)) {
						$anlage_id = $founds[1];
						$kunde_id = $founds[2];
						$name = get_post($founds[0]);

						$turnus = get_post('turnus');
						$ibn_beendet_am = get_post('ibn_beendet_am');
						$letzte_wartung = get_post('letzte_wartung');
						$ende_gewaehrleistung = get_post('ende_gewaehrleistung');
						$this_anlage_comment = get_post('this_anlage_comment');
						$wartungspauschale = get_post('wartungspauschale');

						$ansprechpartner_email = get_post('ansprechpartner_email');
						$ansprechpartner_telnr = get_post('ansprechpartner_telnr');
						$ansprechpartner_name = get_post('ansprechpartner_name');
						$ansprechpartner_id = get_or_create_ansprechpartner($ansprechpartner_email, $ansprechpartner_telnr, $ansprechpartner_name);

						$zeit_pro_wartung = get_post('zeit_pro_wartung');

						$plz = get_post("plz");
						$ort = get_post("ort");
						$strasse = get_post("strasse");
						$hausnummer = get_post("hausnummer");
						$land = get_post("land");

						$material_wartung = get_post("material_wartung");

						$GLOBALS['ibn_beendet_cache'] = array();
						update_anlage($anlage_id, $name, $turnus_id, $ibn_beendet_am, $letzte_wartung, $ende_gewaehrleistung, $this_anlage_comment, $wartungspauschale, $ansprechpartner_id, $zeit_pro_wartung, $plz, $ort, $strasse, $hausnummer, $land, $material_wartung);
						$GLOBALS['ibn_beendet_cache'] = array();
					}
				}
			}

			if(get_post('update_wartungstermine')) {
				$termine = array();
				$kommentare = array();
				$kommentare2 = array();

				foreach ($_POST as $this_get_key => $this_get_value) {
					if(preg_match('/(kommentar2?|termin)_(\d+)/', $this_get_key, $founds)) {
						$type = $founds[1];
						$id = $founds[2];

						if($type == 'termin') {
							if(preg_match('/^\d+$/', $this_get_value)) {
								$termine[$id] = $this_get_value;
							} else {
								error('Invalider Datentyp für Status!');
							}
						} else if ($type == 'kommentar') {
							if(preg_match('/.+/', $this_get_value)) {
								$kommentare[$id] = $this_get_value;
							}
						} else if ($type == 'kommentar2') {
							if(preg_match('/^.+/', $this_get_value)) {
								$kommentare2[$id] = $this_get_value;
							}

						}
					}
				}

				if(count($termine)) {
					update_wartungstermine($termine, $kommentare, $kommentare2);
				} else {
					warning("ACHTUNG: update_wartungstermine wird nicht ausgeführt, weil keine \$termine gefunden werden konnten! Bitte melde mir das!");
				}
			}

			if(get_post('update_setting')) {
				if(get_post('reset_setting')) {
					reset_setting(get_post('name'));
				} else {
					set_setting(get_post('name'), get_post('value'), get_post("description"));
				}
			}

			if(get_post("sqlinserter")) {
				$query_array = preg_split("/\n|;/", get_post("sqlinserter"));
				foreach ($query_array as $this_query) {
					if(!preg_match("/^\s*$/", $this_query)) {
						rquery($this_query);
					}
				}
			}

			if(get_post('create_status')) {
				create_status(get_post('new_name'), get_post('new_color'));
			}

			if(get_post('create_turnus')) {
				create_turnus(get_post('new_name'), get_post('new_anzahl_monate'), get_post('new_wartungen_pro_monat'));
			}

			if(get_post('merge_data')) {
				if(get_get('table') && get_post('merge_from') && get_post('merge_to')) {
					merge_data(get_get('table'), get_post('merge_from'), get_post('merge_to'));
				} else {
					error(' Sowohl eine bzw. mehrere Quelle als auch ein Zielort müssen angegeben werden.');
				}
			}

			if(get_post('new_function_right')) {
				$role_id = get_post('role_id');
				if($role_id) {
					$funktion_name = get_post('funktion_name');
					if($funktion_name) {
						create_function_right($role_id, $funktion_name);
					} else {
						error('Die Funktion konnte nicht angelegt werden, da sie keinen validen Namen zugeordnet bekommen hat. ');
					}
				} else {
					error('Die Funktion konnte nicht angelegt werden, da sie keiner Rolle zugeordnet wurden ist. ');
				}
			}

			if(get_post('import_datenbank')) {
				if(array_key_exists('sql_file', $_FILES) && array_key_exists('tmp_name', $_FILES['sql_file'])) {
					SplitSQL($_FILES['sql_file']['tmp_name']);
				}
			}

			if(get_post('datenbankvergleich')) {
				if(array_key_exists('sql_file', $_FILES) && array_key_exists('tmp_name', $_FILES['sql_file'])) {
					$GLOBALS['compare_db'] = compare_db($_FILES['sql_file']['tmp_name']);
				}
			}

			if(get_post('change_own_data')) {
				$new_password = get_post('password');
				$new_password_repeat = get_post('password_repeat');
				if($new_password && strlen($new_password) >= 5) {
					if($new_password == $new_password_repeat) {
						update_own_data($new_password);
					} else {
						error('Beide Passworteingaben müssen identisch sein. ');
					}
				} else {
					error('Das Passwort muss mindestens 5 Zeichen haben.');
				}
			}

			if(get_post('startseitentext')) {
				$startseitentext = get_post('startseitentext');
				update_startseitentext($startseitentext);
			}

			if(get_post('update_text') && get_post('page_id')) {
				update_text(get_post('page_id'), get_post('text'));
			}

			if(get_post('update_hinweis') && get_post('page_id')) {
				update_hinweis(get_post('page_id'), get_post('hinweis'));
			}

			if(get_post('update_wartung_preis')) {
				$wartung_id = get_post("wartung_id");
				$wartung_kosten = get_post("wartung_kosten");
				set_wartung_kosten($wartung_id, $wartung_kosten);
			}

			if(get_post('update_termin_ersatzteil')) {
				$ersatzteil_id = get_post('neues_ersatzteil');
				$anzahl = get_post('anzahl');
				$termin_id = get_post('terminid');
				$spezialpreis = get_post("spezialpreis");

				update_termin_ersatzteil($ersatzteil_id, $anzahl, $termin_id, $spezialpreis);
			}

			if(get_post_multiple_check(array('new_user', 'name', 'password', 'role'))) {
				create_user(get_post('name'), get_post('password'), get_post('role'));
			} else if (get_post('new_user')) {
				warning('Benutzer müssen einen Namen, ein Passwort und eine Rolle haben. ');
			}

			if(get_post('create_new_kunde')) {
				$name = get_post('name');
				$plz = get_post('plz');
				$ort = get_post('ort');
				$strasse = get_post('strasse');
				$hausnummern = get_post('hausnummern');

				$erinnerung = get_post('erinnerung');
				$pruefung = get_post('pruefung');
				$pruefung_abgelehnt = get_post('pruefung_abgelehnt');

				$email = get_post("email");
				$phone = get_post("telefon");

				$land = get_post("land");

				create_kunde($name, $plz, $ort, $strasse, $hausnummern, $erinnerung, $pruefung, $pruefung_abgelehnt, $phone, $email, $land);
			}

			if(get_post('neue_rolle') && get_post('page')) {
				create_role(get_post('neue_rolle'));
				// Alle alten Rollendaten löschen
				$query = 'DELETE FROM `role_to_page` WHERE `role_id` = '.esc(get_role_id(get_post('neue_rolle')));
				rquery($query);
				foreach (get_post('page') as $key => $this_page_id) {
					if(preg_match('/^\d+$/', $this_page_id)) {
						assign_page_to_role(get_role_id(get_post('neue_rolle')), $this_page_id);
					}
				}
			}
		}
	}

	if($GLOBALS['setup_mode']) {
		if(get_post('import_datenbank')) {
			rquery('USE `'.$GLOBALS['dbname'].'`');
			if(array_key_exists('sql_file', $_FILES) && array_key_exists('tmp_name', $_FILES['sql_file'])) {
				SplitSQL($_FILES['sql_file']['tmp_name']);
			}
		}
	}

	function string_to_number ($str, $show_error_ok = 0) {
		if(is_null($str)) {
			return null;
		}

		if(gettype($str) == "double" || gettype($str) == "integer") {
			return $str;
		}

		$original_string = $str;
		$str = preg_replace('/\s*(?:€|&euro;)/', '', $str);
		if(preg_match("/^-?\d+(?:[\.,]\d+)$/", $str)) {
			$str = preg_replace("/^-?(\d+),(\d+).*?/", "\\1.\\2", $str);
			return doubleval($str);
		} else if(preg_match("/^(-?\d+)[^\d]+$/", $str, $matches)) {
			return intval($matches[1]);
		} else if(preg_match("/^-?\d+$/", $str)) {
			return intval($str);
		} else if(preg_match("/^-?\d+(?:[\.,]\d+)?[^\d]+.*$/", $str)) {
			$str = preg_replace("/^-?(\d+),(\d+).*?/", "\\1.\\2", $str);
			return doubleval($str);
		} else if(preg_match("/^\s*$/", $str)) {
			return null;
		} else if(preg_match("/^(\d+)(.*?)$/", $str, $matches)) {
			warning("Der String ".fq($original_string)." konnte nicht so übernommen werden. Er wurde zu ".fq($matches[1])." gemacht.");
			return intval($matches[1]);
		} else {
			$error_str = "FEHLER: &raquo;$original_string&laquo; konnte nicht in eine Zahl konvertiert werden. Es wird stattdessen NULL genommen.";
			if($show_error_ok) {
				$error_str .= " (Im Testmodus ist dieser Fehler gewollt. Alles OK!)";
			}
			error($error_str);
			return null;
		}
	}

	function htmle ($str, $shy = 0) {
		if($shy) {
			if($str) {
				$str = htmlentities($str);
				return $str;
			} else {
				return '&mdash;';
			}
		} else {
			if($str) {
				return htmlentities($str);
			} else {
				return '&mdash;';
			}
		}
	}

	function compare_db ($file, $session_ids = 0) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		if(file_exists($file)) {
			$skip = array();
			if(!$session_ids) {
				$skip = array('session_ids');
			}
			$now = backup_tables('*', $skip);
			$then = file_get_contents($file);

			if(strlen($then)) {
				require_once dirname(__FILE__).'/Classes/Diff.php';

				$file_a = explode("\n", $then);
				$file_b = explode("\n", $now);

				$options = array();

				$diff = new Diff($file_a, $file_b, $options);
				require_once dirname(__FILE__).'/Classes/Diff/Renderer/Html/SideBySide.php';
				$renderer = new Diff_Renderer_Html_SideBySide;
				$tdiff = $diff->Render($renderer);
				if($tdiff) {
					return $tdiff;
				} else {
					error('Das Diff konnte nicht erzeugt werden oder war leer. ');
				}
			} else if (!$now) {
				error('Das Image der aktuellen Datenbank konnte nicht erstellt werden. ');
			} else {
				error('Die Vergleichsdatei darf nicht leer sein. ');
			}
		} else {
			error('Die Datei konnte nach dem Hochladen nicht gefunden werden. Bitte die Apache-Konfiguration überprüfen! ');
		}
	}

	// https://stackoverflow.com/questions/1883079/best-practice-import-mysql-file-in-php-split-queries
	function SplitSQL($file, $delimiter = ';') {
		if(!$GLOBALS['setup_mode']) {
			if(!check_function_rights(__FUNCTION__)) { return; }
		}

		$GLOBALS['slurped_sql_file'] = 1;
		set_time_limit(0);

		if (is_file($file) === true) {
			$file = fopen($file, 'r');
			$GLOBALS['install_counter'] = 1;

			if (is_resource($file) === true) {
				$query = array();

				while (feof($file) === false) {
					$query[] = fgets($file);

					if(preg_match('~' . preg_quote($delimiter, '~') . '\s*$~iS', end($query)) === 1) {
						$query = trim(implode('', $query));

						stderrw(">>> ".($GLOBALS['install_counter']++).": $query\n");

						if (rquery($query) === false) {
							print '<h3>ERROR: '.htmlentities($query).'</h3>'."\n";
						}

						while (ob_get_level() > 0) {
							ob_end_flush();
						}

						flush();
					}

					if (is_string($query) === true) {
						$query = array();
					}
				}

				return fclose($file);
			}
		}

		return false;
	}

	/* https://davidwalsh.name/backup-mysql-database-php */
	function backup_tables ($tables = '*', $skip = null, $anonymize = null, $get_array = 0) {
		if(!$GLOBALS['setup_mode']) {
			if(!check_function_rights(__FUNCTION__)) { return; }
		}

		rquery('USE `'.$GLOBALS['dbname'].'`');
		//get all of the tables
		if($tables == '*') {
			$tables = array();
			$result = rquery('SHOW TABLES');
			while($row = mysqli_fetch_row($result)) {
				if(!((is_array($skip) && array_search($row[0], $skip)) || (!is_array($skip) && $row[0] == $skip))) {
					$tables[] = $row[0];
				}
			}
		} else {
			$tables = is_array($tables) ? $tables : explode(',', $tables);
		}

		$return = "SET FOREIGN_KEY_CHECKS=0;\n";
		if(!$get_array) {
			$return .= "DROP DATABASE `".$GLOBALS['dbname']."`;\n";
			$return .= "CREATE DATABASE `".$GLOBALS['dbname']."`;\n";
			$return .= "USE `".$GLOBALS['dbname']."`;\n";
		}

		foreach(sort_tables($tables) as $table) {
			$result = rquery('SELECT * FROM '.$table);
			$num_fields = mysqli_field_count($GLOBALS['dbh']);

			$this_return = '';

			$row2 = mysqli_fetch_row(rquery('SHOW CREATE TABLE '.$table));
			$row2 = preg_replace('/CHARSET=latin1/', 'CHARSET=utf8', $row2);
			if(!$get_array) {
				if(preg_match('/^CREATE TABLE/i', $row2[1])) {
					$this_return .= 'DROP TABLE IF EXISTS '.$table.';';
				} else {
					$this_return .= 'DROP VIEW IF EXISTS '.$table.';';
				}
			}

			$this_return.= "\n\n".$row2[1].";\n\n";

			if(preg_match('/^CREATE TABLE/i', $row2[1])) {
				for ($i = 0; $i < $num_fields; $i++) {
					while($row = mysqli_fetch_row($result)) {
						if(!$get_array) {
							$this_return.= 'INSERT INTO `'.$table.'` VALUES(';
							for($j = 0; $j < $num_fields; $j++) {
								if($anonymize && !preg_match('/\d/', $row[$j])) {
									$row[$j] = generate_random_string(strlen($row[$j]));
								}
								$row[$j] = esc($row[$j]);
								if (isset($row[$j])) {
									$this_return .= $row[$j];
								} else {
									$this_return .= 'NULL';
								}
								if ($j < ($num_fields - 1)) {
									$this_return .= ', ';
								}
							}
							$this_return .= ");\n";
						}
					}
				}
			}

			$return .= "$this_return\n";
		}

		$return .= "\n\n\nSET FOREIGN_KEY_CHECKS=1;\n";
		if($get_array) {
			return preg_split("/\n*;\n*/", $return);
		} else {
			return $return;
		}
	}

	function database_exists ($name) {
		if(!array_key_exists($name, $GLOBALS['db_exists_cache'])) {
			$query = 'SELECT count(SCHEMA_NAME) FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '.esc($name);
			$GLOBALS['db_exists_cache'][$name] = !!get_single_value_from_query($query);	
		}
		return $GLOBALS['db_exists_cache'][$name];
	}

	function table_exists_nocache ($name, $db = null) {
		if(is_null($db)) {
			$db = $GLOBALS['dbname'];
		}
		$query = 'select count(*) from information_schema.tables where table_schema = '.esc($db).' and table_name = '.esc($name);
		return !!get_single_value_from_query($query);
	}

	function table_exists ($name, $db = null, $renew_cache = 0) {
		if(is_null($db)) {
			$db = $GLOBALS['dbname'];
		}

		if(!array_key_exists($db, $GLOBALS['table_exists_cache'])) {
			$GLOBALS['table_exists_cache'][$db] = array();
		}

		if(!array_key_exists($name, $GLOBALS['table_exists_cache'][$db])) {
			$query = 'select table_name, count(*) from information_schema.tables where table_schema = '.esc($db).' group by table_name';
			$result = rquery($query);

			while ($row = mysqli_fetch_row($result)) {
				$name = $row[0];
				$GLOBALS['table_exists_cache'][$db][$name] = !!$row[1];
			}
		}

		$this_result = 0;
		if(array_key_exists($db, $GLOBALS['table_exists_cache'])) {
			if(array_key_exists($name, $GLOBALS['table_exists_cache'][$db])) {
				$this_result = $GLOBALS['table_exists_cache'][$db][$name];
			}
		}

		if($renew_cache) {
			$GLOBALS['table_exists_cache'] = array();
		}

		return $this_result;
	}


	function sort_tables ($tables) {
		$create_views = array();
		$create_tables = array();

		foreach ($tables as $table) {
			if(preg_match('/^view_|^ua_overview$/', $table)) {
				$create_views[] = $table;
			} else {
				$create_tables[] = $table;
			}
		}

		$tables_sorted_tmp = array();

		foreach ($create_tables as $table) {
			$foreign_keys = get_foreign_key_tables($GLOBALS['dbname'], $table);
			$foreign_keys_counter = 0;
			if(array_key_exists(0, $foreign_keys)) {
				$foreign_keys_counter = count($foreign_keys[0]);
			}
			$tables_sorted_tmp[] = array('name' => $table, 'foreign_keys_counter' => $foreign_keys_counter);
		}

		usort($tables_sorted_tmp, 'foreignKeyAscSort');

		foreach ($tables_sorted_tmp as $table) {
			$tables_sorted[] = $table['name'];
		}

		foreach ($create_views as $view) {
			$tables_sorted[] = $view;
		}

		return $tables_sorted;
	}

	function foreignKeyAscSort($item1, $item2) {
		if ($item1['foreign_keys_counter'] == $item2['foreign_keys_counter']) {
			return 0;
		} else {
			return ($item1['foreign_keys_counter'] < $item2['foreign_keys_counter']) ? -1 : 1;
		}
	}

	function get_referencing_foreign_keys ($database, $table) {
		$query = 'SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, REFERENCED_COLUMN_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE REFERENCED_TABLE_SCHEMA = "'.$database.'" AND REFERENCED_TABLE_NAME = '.esc($table);
		$result = rquery($query);
		$foreign_keys = array();
		while ($row = mysqli_fetch_row($result)) {
			$foreign_keys[] = array('database' => $row[0], 'table' => $row[1], 'column' => $row[2], 'reference_column' => $row[3]);
		}
		$result->free();

		return $foreign_keys;
	}

	function get_foreign_key_deleted_data_html ($database, $table, $where) {
		$data = get_foreign_key_deleted_data ($database, $table, $where);

		$html = '';
		$j = 0;
		foreach ($data as $key => $this_data) {
			$html .= "<h2>$key</h2>\n";

			$html .= "<table>\n";
			$i = 0;
			foreach ($this_data as $value) {
				if($i == 0) {
					$html .= "\t<tr>\n";
					foreach ($value as $column => $column_value) {
						$html .= "\t\t<th>".htmlentities($column)."</th>\n";
					}
					$html .= "\t</tr>\n";
				}
				$html .= "\t<tr>\n";
				foreach ($value as $column => $column_value) {
					if(preg_match('/password|session_id|salt/', $column)) {
						$html .= "\t\t<td><i>Aus Sicherheitsgründen wird diese Spalte nicht angezeigt.</i></td>\n";
					} else {
						if($column_value) {
							$html .= "\t\t<td>".htmlentities($column_value)."</td>\n";
						} else {
							$html .= "\t\t<td><i style='color: orange;'>NULL</i></td>\n";
						}
					}
				}
				$html .= "\t</tr>\n";
				$i++;
			}
			$html .= "</table>\n";

			if($i == 1) {
				$html .= "<h3>$i Zeile</h3><br />\n";
			} else {
				$html .= "<h3>$i Zeilen</h3><br />\n";
			}
			$j += $i;
		}

		$html .= "<h4>Insgesamt $j Datensätze</h4>\n";;

		return $html;
	}

	function get_primary_keys ($database, $table) {
		$query = "SELECT k.column_name FROM information_schema.table_constraints t JOIN information_schema.key_column_usage k USING(constraint_name,table_schema,table_name) WHERE t.constraint_type='PRIMARY KEY' AND t.table_schema = ".esc($database)." AND t.table_name = ".esc($table);
		$result = rquery($query);

		$data = array();

		while ($row = mysqli_fetch_row($result)) {
			$data[] = $row;
		}
		$result->free();

		return $data;
	}

	function get_foreign_key_tables ($database, $table) {
		$query = "SELECT TABLE_NAME, COLUMN_NAME, ' -> ', REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE REFERENCED_COLUMN_NAME IS NOT NULL AND CONSTRAINT_SCHEMA = ".esc($database)." AND TABLE_NAME = ".esc($table);
		$result = rquery($query);

		$data = array();

		while ($row = mysqli_fetch_row($result)) {
			$data[] = $row;
		}
		$result->free();

		return $data;
	}

	function get_foreign_key_deleted_data ($database, $table, $where) {
		$GLOBALS['get_data_that_would_be_deleted'] = array();
		$data = get_data_that_would_be_deleted($database, $table, $where);
		$GLOBALS['get_data_that_would_be_deleted'] = array();
		return $data;
	}

	function get_data_that_would_be_deleted ($database, $table, $where, $recursion = 100) {
		if($recursion <= 0) {
			error("get_data_that_would_be_deleted: Tiefenrekursionsfehler. ");
			return;
		}

		if($recursion == 100) {
			$GLOBALS['get_data_that_would_be_deleted'] = array();
		}

		if($table) {
			if(preg_match('/^[a-z0-9A-Z_]+$/', $table)) {
				if(is_array($where)) {
					$foreign_keys = get_referencing_foreign_keys($database, $table);
					$data = array();

					$query = 'SELECT * FROM `'.$table.'`';
					if(count($where)) {
						$query .= ' WHERE 1';
						foreach ($where as $name => $value) {
							$query .= " AND `$name` IN (".esc($value).')';
						}
					}
					$result = rquery($query);

					$to_check = array();

					while ($row = mysqli_fetch_row($result)) {
						$new_row = array();
						$i = 0;
						foreach ($row as $this_row) {
							$field_info = mysqli_fetch_field_direct($result, $i);
							$new_row[$field_info->name] = $this_row;
							foreach ($foreign_keys as $this_foreign_key) {
								if($this_foreign_key['reference_column'] == $field_info->name) {
									$to_check[] = array('value' => $this_row, 'foreign_key' => array('table' => $this_foreign_key['table'], 'column' => $this_foreign_key['column'], 'database' => $this_foreign_key['database']));
								}
							}
							$i++;
						}
						$GLOBALS['get_data_that_would_be_deleted'][$table][] = $new_row;
					}
					$result->free();
					foreach ($to_check as $this_to_check) {
						if(isset($this_to_check['value']) && !is_null($this_to_check['value'])) {
							get_data_that_would_be_deleted($database, $this_to_check['foreign_key']['table'], array($this_to_check['foreign_key']['column'] => $this_to_check['value']), $recursion - 1);;
						}
					}

					$data = $GLOBALS['get_data_that_would_be_deleted'];

					return $data;
				} else {
					die("\$where needs to be an array with column_name => value pairs");
				}
			} else {
				die('`'.htmlentities($table).'` is not a valid table name');
			}
		} else {
			die("\$table was not defined!");
		}
	}

	function check_page_rights ($page, $log = 1) {
		$log = 0;
		if( (array_key_exists('user_role_id', $GLOBALS) && isset($GLOBALS['user_role_id'])) ) {
			$role_id = $GLOBALS['user_role_id'];
			return check_page_rights_role_id($page, $role_id, $log);
		} else {
			return 0;
		}
	}

	function check_page_rights_role_id ($page_id, $role_id, $log = 1) {
		if( (isset($role_id) || is_null($role_id) ) && (array_key_exists('user_role_id', $GLOBALS) && isset($GLOBALS['user_role_id'])) ) {
			$role_id = $GLOBALS['user_role_id'];
		}

		if(!$role_id) {
			return 0;
		}

		if(is_array($page_id)) {
			$query = 'SELECT `page_id` FROM `role_to_page` WHERE `page_id` IN ('.multiple_esc_join($page_id).') AND `role_id` = '.esc($role_id);
			$result = rquery($query);

			$rights_id = array();
			while ($row = mysqli_fetch_row($result)) {
				$rights_id[] = $row[0];
			}
			$result->free();

			return $rights_id;
		} else {
			if(!preg_match('/^\d+$/', $page_id)) {
				$page_id = get_page_id_by_filename($page_id);
			}
			$return = 0;
			$key = "$page_id----$role_id";
			if(array_key_exists($key, $GLOBALS['user_role_cache'])) {
				$return = $GLOBALS['user_role_cache'][$key];
			} else {
				if(isset($GLOBALS['logged_in_user_id'])) {
					$query = 'SELECT `page_id` FROM `role_to_page` WHERE `page_id` = '.esc($page_id).' AND `role_id` = '.esc($role_id);
					$result = rquery($query);

					$rights_id = null;
					while ($row = mysqli_fetch_row($result)) {
						$rights_id = $row[0];
					}
					$result->free();

					if(!is_null($rights_id)) {
						$return = 1;
					}
				}
			}
			$GLOBALS['user_role_cache'][$key] = $return;

			if($log) {
				if(!$return) {
					right_issue("Die Seite mit der ID `$page_id` darf mit den aktuellen Rechten nicht ausgeführt werden. ");
					$query = 'INSERT IGNORE INTO `right_issues_pages` (`user_id`, `page_id`, `date`) VALUES ('.esc($GLOBALS['logged_in_user_id']).', '.esc($page_id).', now())';
					rquery($query);
					right_issue("Der Vorfall wird gespeichert und der Administrator informiert. ");
				}
			}

			return $return;
		}
	}

	function check_function_rights ($function, $log = 1) {
		if(array_key_exists('ignore_function_rights', $GLOBALS)) {
			return 1;
		} else {
			if(array_key_exists('user_role_id', $GLOBALS)) {
				$role_id = $GLOBALS['user_role_id'];
				return check_function_rights_role_id($function, $role_id, $log);
			} else {
				return 0;
			}
		}
	}

	function check_function_rights_role_id ($function, $role_id, $log = 1) {
		return 1;
		if(!$role_id || is_null($role_id)) {
			$role_id = $GLOBALS['user_role_id'];
		}

		$return = 0;
		if(isset($GLOBALS['logged_in_user_id'])) {
			$query = 'SELECT `id` FROM `function_rights` WHERE `name` = '.esc($function).' AND `role_id` = '.esc($role_id);
			$result = rquery($query);

			$rights_id = null;
			while ($row = mysqli_fetch_row($result)) {
				$rights_id = $row[0];
			}
			$result->free();

			if(!is_null($rights_id)) {
				$return = 1;
			}
		}

		if($log) {
			if(!$return) {
				right_issue("Die Funktion $function darf mit den aktuellen Rechten nicht ausgeführt werden. ");
				$query = 'INSERT IGNORE INTO `right_issues` (`user_id`, `function`, `date`) VALUES ('.esc($GLOBALS['logged_in_user_id']).', '.esc($function).', now())';
				rquery($query);
				right_issue("Der Vorfall wird gespeichert und der Administrator informiert. ");
			}
		}

		return $return;
	}

	function get_func_argNames($funcName) {
		if($funcName == 'include_once' || $funcName == 'include' || $funcName == 'require_once') {
			return array('filename');
		}

		$f = new ReflectionFunction($funcName);
		$result = array();
		foreach ($f->getParameters() as $param) {
			$result[] = $param->name;
		}
		return $result;
	}

	function getExceptionTraceAsString($exception) {
		$rtn = "";
		$count = 0;
		foreach ($exception->getTrace() as $frame) {
			$args = "";
			if (isset($frame['args'])) {
				$args = array();
				foreach ($frame['args'] as $arg) {
					if (is_string($arg)) {
						$args[] = "'" . $arg . "'";
					} elseif (is_array($arg)) {
						$args[] = "Array";
					} elseif (is_null($arg)) {
						$args[] = 'NULL';
					} elseif (is_bool($arg)) {
						$args[] = ($arg) ? "true" : "false";
					} elseif (is_object($arg)) {
						$args[] = get_class($arg);
					} elseif (is_resource($arg)) {
						$args[] = get_resource_type($arg);
					} else {
						$args[] = $arg;
					}
				}
				$args = join(", ", $args);
			}
			$rtn .= sprintf( "#%s %s(%s): %s(%s)\n",
				$count,
				$frame['file'],
				$frame['line'],
				$frame['function'],
				$args );
			$count++;
		}
		return $rtn;
	}

	// Idee: über diese Wrapperfunktion kann man einfach Queries mitloggen etc., falls notwendig.
	function rquery ($internalquery, $die = 1, $throw = 0, $show_warnings = 1) {
		$caller_args = '';
		$caller_function_without_extras = '';

		$query_addition = "";

		if($GLOBALS['show_backtrace']) {
			$backtrace = debug_backtrace();
			if(array_key_exists(1, $backtrace) && array_key_exists('args', $backtrace[1])) {
				$caller_file = $backtrace[0]['file'];
				$caller_line = $backtrace[0]['line'];
				if(array_key_exists(1, $backtrace) && array_key_exists('function', $backtrace[1])) {
					$caller_function_without_extras = $backtrace[1]['function'];
				}
				$caller_function = $caller_function_without_extras;

				$query_addition = "/* \n$caller_file, $caller_line".($caller_function ? "\n$caller_function\n" : '')." */";

				$args = get_func_argNames($caller_function_without_extras);
				$caller_args = '';
				$caller_args_array = array();
				foreach ($args as $id => $name) {
					$this_arg = '';
					if(
						array_key_exists(1, $backtrace) && 
						array_key_exists('args', $backtrace[1]) && 
						array_key_exists($id, $backtrace[1]['args'])
					) {
						if(is_null($backtrace[1]['args'][$id])) {
							$this_arg = 'null';
						} else if (is_array($backtrace[1]['args'][$id])) {
							$this_arg = 'array('.multiple_esc_join($backtrace[1]['args'][$id]).')';
						} else {
							$this_arg = esc($backtrace[1]['args'][$id]);
						}
					}
					$caller_args_array[] = "\$$name = ".$this_arg;
				}

				$e = new \Exception;
				$stack = getExceptionTraceAsString($e);

				$caller_args = implode(', ', $caller_args_array);
				$caller_function = "$caller_function($caller_args)\nFull Stack: \n $stack ";
			}
		}

		$start = microtime(true);
		$result = mysqli_query($GLOBALS['dbh'], $internalquery);
		$end = microtime(true);
		if($show_warnings && $GLOBALS['dbh']) {
			if(mysqli_connect_errno()) {
				mysql_error("MySQL-Error: ".mysqli_connect_error());
			}

			$count_warnings = mysqli_warning_count($GLOBALS['dbh']);
			if ($count_warnings > 0) {
				$e = mysqli_get_warnings($GLOBALS['dbh']);
				for ($i = 0; $i < $count_warnings; $i++) {
					mysql_warning("MySQL-Warning (".$e->errno."): <br><pre>".htmlentities($internalquery)."</pre>->&nbsp;<b>".$e->message."</b>");
					$e->next();
				}
			}
		}
		$used_time = $end - $start;
		$numrows = "&mdash;";
		if(!is_bool($result)) {
			$numrows = mysqli_num_rows($result);
		}

		$GLOBALS['queries'][] = array('query' => "$query_addition\n$internalquery", 'time' => $used_time, 'numrows' => $numrows);

		if($caller_function_without_extras) {
			if(array_key_exists($caller_function_without_extras, $GLOBALS['function_usage'])) {
				$GLOBALS['function_usage'][$caller_function_without_extras]['count']++;
				$GLOBALS['function_usage'][$caller_function_without_extras]['time'] += $used_time;
			} else {
				$GLOBALS['function_usage'][$caller_function_without_extras]['count'] = 1;
				$GLOBALS['function_usage'][$caller_function_without_extras]['time'] = $used_time;
				$GLOBALS['function_usage'][$caller_function_without_extras]['name'] = $caller_function_without_extras;
			}
		}

		if(!$result) {
			$msg = "Ung&uuml;ltige Anfrage: <p><pre>".$internalquery."</pre></p>".htmlentities(mysqli_error($GLOBALS['dbh']));
			if($die) {
				dier($msg, 1);
			} else if ($throw) {
				throw new Exception($msg);
			}
		}

		if($GLOBALS['rquery_print']) {
			print "<p>".htmlentities($internalquery)."</p>\n";
		}

		return $result;
	}

	function esc ($parameter) { // escape
		if(!is_array($parameter)) { // Kein array
			if(isset($parameter) && strlen($parameter)) {
				return '"'.mysqli_real_escape_string($GLOBALS['dbh'], $parameter).'"';
			} else {
				return 'NULL';
			}
		} else { // Array
			$str = join(', ', array_map('esc', array_map('my_mysqli_real_escape_string', $parameter)));
			return $str;
		}
	}

	function my_mysqli_real_escape_string ($arg) {
		return mysqli_real_escape_string($GLOBALS['dbh'], $arg);
	}

	function dier ($data, $enable_html = 0, $die = 1) {
		$debug_backtrace = debug_backtrace();
		$source_data = $debug_backtrace[0];

		$source = '';

		if(array_key_exists(1, $debug_backtrace) && array_key_exists('file', $debug_backtrace[1])) {
			@$source .= 'Aufgerufen von <b>'.$debug_backtrace[1]['file'].'</b>::<i>';
		}
		
		if(array_key_exists(1, $debug_backtrace) && array_key_exists('function', $debug_backtrace[1])) {
			@$source .= $debug_backtrace[1]['function'];
		}


		@$source .= '</i>, line '.htmlentities($source_data['line'])."<br />\n";

		if(array_key_exists("logged_in_user_id", $GLOBALS) && $GLOBALS['logged_in_user_id']) {
			print $source;
		}
		print "<pre>\n";
		ob_start();
		print_r($data);
		$buffer = ob_get_clean();
		if($enable_html) {
			print $buffer;
		} else {
			print htmlentities($buffer);
		}
		print "</pre>\n";
		if(array_key_exists('logged_in_user_id', $GLOBALS) && $GLOBALS['logged_in_user_id']) {
			print "Backtrace:\n";
			print "<pre>\n";
			foreach ($debug_backtrace as $trace) {
				print htmlentities(sprintf("\n%s:%s %s", $trace['file'], $trace['line'], $trace['function']));
			}
			print "</pre>\n";
		}
		if($die) {
			include_once("footer.php");
			exit();
		}
	}

	function multiple_esc_join ($data) {
		if(is_array($data)) {
			$data = array_map('esc', $data);
			$string = join(", ", $data);
			return $string;
		} else {
			return esc($data);
		}
	}

	function get_post_multiple_check ($names) {
		if(is_array($names)) {
			$return = 1;
			foreach ($names as $name) {
				if(!get_post($name)) {
					$return = 0;
					break;
				}
			}
			return $return;
		} else {
			return get_post($name);
		}
	}

	function get_cookie ($name) {
		if(array_key_exists($name, $_COOKIE)) {
			return $_COOKIE[$name];
		} else {
			return NULL;
		}
	}

	// Die get_-Funktionen sollen häßliche Konstrukte mit array_key_exists($bla, $_POST) vermeiden.
	function get_get ($name) {
		if(array_key_exists($name, $_GET)) {
			return $_GET[$name];
		} else {
			return NULL;
		}
	}

	function get_post ($name) {
		if(array_key_exists($name, $_POST)) {
			return $_POST[$name];
		} else {
			return NULL;
		}
	}

	function generate_random_string ($length = 50) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[mt_rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}

	function delete_old_session_ids ($user_id = null) {
		if($GLOBALS['already_deleted_old_session_ids']) {
			return;
		}

		if(table_exists_nocache('session_ids')) {
			$query = 'DELETE FROM `session_ids` WHERE `creation_time` <= now() - INTERVAL 1 DAY';
			rquery($query);
			if($user_id) {
				$query = 'DELETE FROM `session_ids` WHERE `user_id` = '.esc($user_id);
				rquery($query);
			}
			$GLOBALS['already_deleted_old_session_ids'] = 1;
		}
	}

	function print_subnavigation ($parent) {
		$query = 'SELECT `name`, `file`, `page_id`, `show_in_navigation`, `parent` FROM `view_account_to_role_pages` WHERE `user_id` = '.esc($GLOBALS['logged_in_user_id']).' AND `parent` = '.esc($parent).' AND `show_in_navigation` = "1" ORDER BY `name`';
		$result = rquery($query);

		$str = '';
		$subnav_selected = 0;

		if(mysqli_num_rows($result)) {
			$str .= "\t<ul>\n";
			while ($row = mysqli_fetch_row($result)) {
				if($row[2] == get_get('page')) {
					$str .= "\t\t<li style='font-weight: bold;'><a href='admin.php?page=".$row[2]."'>&rarr; $row[0]</a></li>\n";
					$subnav_selected = 1;
				} else {
					$str .= "\t\t<li><a href='admin.php?page=".$row[2]."'>$row[0]</a></li>\n";
				}
			}
			$result->free();
			$str .= "\t</ul>\n";
		}

		return array($subnav_selected, $str);
	}

	/* MySQL-get-Funktionen */

	/*
		Ich habe hier "auf Vorrat" gearbeitet. Fast alle dieser Funktionen sind irgendwie
		sinnvoll einsetzbar. Sobald das der Fall ist, will ich sie einfach benutzen können.
		Der Overhead ist vergleichsweise klein und wiegt den Aufwand im späteren Programmieren
		bei Weitem auf.
	 */

	function merge_data ($table, $from, $to) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		if(preg_match('/^[a-z0-9A-Z_]+$/', $table)) {
			foreach ($from as $this_from) {
				$where = array('id' => $from);
				$data = get_foreign_key_deleted_data($GLOBALS['dbname'], $table, $where);

				foreach ($data as $this_table => $this_table_val) {
					if($this_table != $table) {
						$where = '';
						$refkey = '';

						$this_where = array();

						$foreign_keys = get_foreign_key_tables($GLOBALS['dbname'], $this_table);
						foreach ($foreign_keys as $this_foreign_key) {
							if($this_foreign_key[3] == $table) {
								$refkey = $this_foreign_key[1];
							}
						}

						if($refkey) {
							$primary_keys = get_primary_keys($GLOBALS['dbname'], $this_table);
							$i = 0;
							foreach ($this_table_val as $this_table_val_2) {
								$this_where_str = '';
								foreach ($primary_keys as $this_primary_key) {
									$this_where_str .= ' (';
									$this_where_str .= "`$this_primary_key[0]` = ".esc($this_table_val_2[$this_primary_key[0]]);
									$this_where_str .= ') OR ';

									$i++;
								}
								$this_where[] = $this_where_str;
							}
							$where = join(' ', $this_where);
							$where = preg_replace('/\s+OR\s*$/', '', $where);

							if($where) {
								if(preg_match('/=/', $where)) {
									$query = "UPDATE `$this_table` SET `$refkey` = ".esc($to)." WHERE $where";
									stderrw($query);
									$result = rquery($query);
								} else {
									die("Es konnte kein valides `$where entwickelt werden`: $where.");
								}
							} else {
								die("Es konnte kein `$where entwickelt werden`.");
							}
						}
					}
				}
			}

			$wherea = array();
			foreach ($from as $this_from) {
				if($this_from != $to) {
					$wherea[] = $this_from;
				}
			}
			$where = '`id` IN ('.join(', ', array_map('esc', $wherea)).')';
			$query = "DELETE FROM `$table` WHERE $where";
			$result = rquery($query);

			if($result) {
				return success('Die Keys wurden erfolgreich gelöscht. ');
			} else {
				return error('Die Daten wurden nicht erfolgreich gemergt. ');
			}
		} else {
			return error('Die Tabelle `'.htmlentities($table).'` konnte ist nicht valide.');
		}
	}

	function get_page_file_by_id ($id) {
		$key = "get_page_file_by_id($id)";
		if(array_key_exists($key, $GLOBALS['memoize'])) {
			return $GLOBALS['memoize'][$key];
		}

		$query = 'SELECT `file` FROM `page` WHERE `id` = '.esc($id);
		$result = rquery($query);

		$id = NULL;

		while ($row = mysqli_fetch_row($result)) {
			$id = $row[0];
		}
		$result->free();

		$GLOBALS['memoize'][$key] = $id;

		return $id;
	}

	function get_page_info_by_id ($id) {
		$query = 'SELECT `page_id`, `info` FROM `page_info` WHERE `page_id` ';
		if(is_array($id)) {
			$query .= 'IN ('.join(', ', array_map('esc', $id)).')';
		} else {
			$query .= ' = '.esc($id);
		}
		$result = rquery($query);

		$data = array();

		while ($row = mysqli_fetch_row($result)) {
			if(is_array($id)) {
				$data[$row[0]] = $row[1];
			} else {
				$data = $row[1];
			}
		}
		$result->free();

		return $data;
	}

	function get_page_name_by_id ($id) {
		$query = 'SELECT `name` FROM `page` WHERE `id` = '.esc($id);
		$result = rquery($query);

		$id = NULL;

		while ($row = mysqli_fetch_row($result)) {
			$id = $row[0];
		}
		$result->free();

		return $id;
	}

	function create_page_id_by_name_array () {
		$query = 'SELECT `name`, `id` FROM `page`';
		$result = rquery($query);

		$id = array();

		while ($row = mysqli_fetch_row($result)) {
			$id[$row[1]] = $row[0];
		}
		$result->free();

		return $id;
	}

	function get_role_id_by_user ($name) {
		$key = "get_role_id_by_user($name)";
		if(array_key_exists($key, $GLOBALS['memoize'])) {
			$return = $GLOBALS['memoize'][$key];
		} else {
			$query = 'SELECT `role_id` FROM `role_to_user` `ru` LEFT JOIN `users` `u` ON `ru`.`user_id` = `u`.`id` WHERE `u`.`id` = '.esc($name);
			$result = rquery($query);

			$return = NULL;

			while ($row = mysqli_fetch_row($result)) {
				$return = $row[0];
			}
			$result->free();
			$GLOBALS['memoize'][$key] = $return;
		}

		return $return;
	}

	function get_account_enabled_by_id ($id) {
		$query = 'select enabled from users where id = '.esc($id);

		$result = rquery($query);

		$id = NULL;

		while ($row = mysqli_fetch_row($result)) {
			$id = $row[0];
		}
		$result->free();

		return $id;
	}

	function get_role_name ($id) {
		$query = 'SELECT `name` FROM `role` WHERE `id` = '.esc($id).' limit 1';
		$result = rquery($query);

		$id = NULL;

		while ($row = mysqli_fetch_row($result)) {
			$id = $row[0];
		}
		$result->free();

		return $id;
	}

	function get_role_id ($name) {
		$query = 'SELECT `id` FROM `role` WHERE `name` = '.esc($name).' limit 1';
		$result = rquery($query);

		$id = NULL;

		while ($row = mysqli_fetch_row($result)) {
			$id = $row[0];
		}
		$result->free();

		return $id;
	}

	function get_user_id ($name) {
		$query = 'SELECT `id` FROM `users` WHERE `username` = '.esc($name);
		$result = rquery($query);

		$id = NULL;

		while ($row = mysqli_fetch_row($result)) {
			$id = $row[0];
		}
		$result->free();

		return $id;
	}

	function get_user_name ($id) {
		$query = 'SELECT `username` FROM `users` WHERE `id` = '.esc($id);
		$result = rquery($query);

		$name = NULL;

		while ($row = mysqli_fetch_row($result)) {
			$name = $row[0];
		}
		$result->free();

		return $name;
	}

	function get_kunden_via_plz_array ($plz) {
		if(preg_match('/^\d+$/', $plz)) {
			$query = 'SELECT `id`, `kunde`, `plz`, `ort`, `strasse`, `hausnummern`, `phone`, `email` FROM `kunden` WHERE `plz` like '.esc("$plz%").' ORDER BY `ort` ASC, `kunde` ASC';
			$result = rquery($query);

			$kunden = array();

			while ($row = mysqli_fetch_assoc($result)) {
				$kunden[] = $row;
			}

			return $kunden;
		} else {
			return get_kunden_array();
		}
	}


	function get_kunden_array_ordered ($orderby, $anlage_id = null) {
		if(!$orderby) {
			$orderby = '`ort` ASC, `kunde` ASC';
		}
		$query = "SELECT `k`.`id`, `k`.`kunde`, `k`.`plz`, `k`.`ort`, `k`.`strasse`, `k`.`hausnummern`, `phone`, `email`, ifnull(k.ort, a.ort) as sort_ort, ifnull(k.plz, a.plz) as sort_plz FROM `kunden` k left join anlagen a on a.kunde_id = k.id WHERE 1 ";
		if(!is_null($anlage_id) && preg_match('/^\d+$/', $anlage_id)) {
			$query .= ' AND k.`id` IN (SELECT `kunde_id` FROM `anlagen` WHERE `id` = '.esc($anlage_id).') ';
		}
		$query .= 'GROUP BY id ORDER BY '.$orderby;
		$result = rquery($query);

		$kunden = array();

		while ($row = mysqli_fetch_assoc($result)) {
			$kunden[] = $row;
		}

		return $kunden;
	}


	function get_kunden_array ($kunde_id = null, $anlage_id = null) {
		if(array_key_exists($kunde_id, $GLOBALS['get_kunden_array_cache']) && array_key_exists($anlage_id, $GLOBALS['get_kunden_array_cache'][$kunde_id])) {
			return $GLOBALS['get_kunden_array_cache'][$kunde_id][$anlage_id];
		} else {
			$query = 'SELECT `id`, `kunde`, `plz`, `ort`, `strasse`, `hausnummern`, `phone`, `email` FROM `kunden` WHERE 1 ';
			if(!is_null($kunde_id)) {
				$query .= ' AND id = '.esc($kunde_id);
			}

			if(!is_null($anlage_id)) {
				$query .= ' AND id in (select kunde_id from anlagen where id = '.esc($anlage_id).')';
			}

			$query .= ' ORDER BY `ort` ASC, `kunde` ASC';
			$result = rquery($query);

			$kunden = array();

			while ($row = mysqli_fetch_assoc($result)) {
				$kunden[] = $row;
			}

			$GLOBALS['get_kunden_array_cache'][$kunde_id][$anlage_id] = $kunden;
			return $kunden;
		}
	}

	function get_get_int ($key) {
		$data = get_get($key);
		if(preg_match('/^\d+$/', $data)) {
			return $data;
		} else {
			return '';
		}
	}

	function get_ersatzteil_array ($show_price = false, $kunde_id = null, $termin_id = null) {
		$query = 'SELECT `id`, `name` from `ersatzteil`';
		$result = rquery($query);

		$array = array();

		while ($row = mysqli_fetch_row($result)) {
			$ersatzteil_id = $row[0];
			$ersatzteil_name = $row[1];
			if($show_price) {
				$price_string = "Kein Std./Kundenpreis eingetragen";
				$price_data = get_ersatzteil_price($ersatzteil_id, $termin_id);
				if($price_data) {
					$price_string = $price_data;
				}
				$ersatzteil_name = "$ersatzteil_name (".$price_string.")";
			}
			$array[] = array(0 => $ersatzteil_id, 1 => $ersatzteil_name);
		}
		$result->free();

		return $array;
	}

	function get_seitentext () {
		$tpnr = '';
		if(array_key_exists('this_page_number', $GLOBALS) && !is_null($GLOBALS['this_page_number'])) {
			$tpnr = $GLOBALS['this_page_number'];
		} else {
			$tpnr = get_page_id_by_filename('welcome.php');
		}

		$query = 'SELECT `text` FROM `seitentext` WHERE `page_id` = '.esc($tpnr);
		$result = rquery($query);

		$id = NULL;

		while ($row = mysqli_fetch_row($result)) {
			if($row[0]) {
				$id = $row[0];
			}
		}
		$result->free();

		return $id;
	}

	/* MySQL-create-Funktionen */

	/*
		Trägt die verschiedenen Datensatztypen ein.
	 */

	function create_role($role, $id = null) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'INSERT IGNORE INTO `role` (`name`) VALUES ('.esc($role).')';
		if(!is_null($id)) {
			$query = 'INSERT IGNORE INTO `role` (`id`, `name`) VALUES ('.esc($id).', '.esc($role).')';
		}
		$result = rquery($query);
		if($result) {
			return success('Die Rolle wurde erfolgreich eingetragen.');
		} else {
			return error('Die Rolle konnte nicht eingetragen werden.');
		}
	}

	function shorten ($variable, $max_length, $varname) {
		if(strlen($variable) < $max_length) {
			return $variable;
		} else {
			$variable = substr($variable, 0, $max_length);
			warning(sprintf("$varname war zu lang und wurde auf %d Zeichen gekürzt", $max_length));
			return $variable;
		}
	}

	#			1	2   3	   4		5	     	9	10		11		12	13	14
	function create_kunde($name, $plz, $ort, $strasse, $hausnummern, $erinnerung, $pruefung, $pruefung_abgelehnt, $phone, $email, $land) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$erinnerung = convert_anything_to_boolean($erinnerung);
		$pruefung = convert_anything_to_boolean($pruefung);

		$name = shorten($name, 100, "Der Name");
		$plz = shorten($plz, 10, "Die PLZ");
		$strasse = shorten($strasse, 10, "Die Strasse");

		$query = 'INSERT IGNORE INTO `kunden` (`kunde`, `plz`, `ort`, `strasse`, `hausnummern`, `erinnerung`, `pruefung`, `pruefung_abgelehnt`, `phone`, `email`, `land`) VALUES ('.
			esc($name).', '.esc($plz).', '.esc($ort).', '.esc($strasse).', '.esc($hausnummern).', '.esc($erinnerung).', '.esc($pruefung).', '.esc($pruefung_abgelehnt).', '.esc($phone).', '.esc($email).', '.esc($land).') on duplicate key update plz = values(plz), strasse = values(strasse), hausnummern = values(hausnummern), erinnerung = values(erinnerung), pruefung = values(pruefung), pruefung_abgelehnt = values(pruefung_abgelehnt), phone = values(phone), email = values(email), land = values (land)';
		$result = rquery($query);
		if($result) {
			$last_id = $GLOBALS['dbh']->insert_id;
			success('Der Kunde mit dem Namen '.get_kunde_link_name_by_id($last_id).' konnte erfolgreich eingefügt werden. ');
			$id_query = 'select id from kunden where kunde = '.esc($name);;
			return get_single_value_from_query($id_query);
		} else {
			error('Der Kunde konnte nicht eingetragen werden. ');
		}
	}

	function create_user($name, $password, $role) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$salt = generate_random_string(100);
		$query = 'INSERT IGNORE INTO `users` (`username`, `password_sha256`, `salt`) VALUES ('.esc($name).', '.esc(hash('sha256', $password.$salt)).', '.esc($salt).')';
		$result = rquery($query);
		if($result) {
			$id = get_user_id($name);
			$query = 'INSERT IGNORE INTO `role_to_user` (`role_id`, `user_id`) VALUES ('.esc($role).', '.esc($id).')';
			$result = rquery($query);

			if($result) {
				return success('Der User wurde mit seiner Rolle erfolgreich eingetragen.');
			} else {
				return error('Der User konnte eingefügt, aber nicht seiner Rolle zugeordnet werden. ');
			}
		} else {
			return error('Der User konnte nicht eingetragen werden. ');
		}
	}

	function delete_status ($id) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$status_id_ok = get_setting("status_ok");
		$status_default = get_setting("status_default");
		$status_geplant = get_setting("status_geplant");
		if($id == $status_id_ok || $id == $status_default || $status_geplant) {
			error("Die Status-IDs $status_id_ok (Config-Name: status_id_ok), $status_default (Config-Name: status_default) und $status_geplant (status_geplant) können nicht gelöscht werden!");
			return null;
		}
		$query = 'DELETE FROM `status` WHERE `id` = '.esc($id);
		$result = rquery($query);
		if($result) {
			return success('Der Status wurde erfolgreich gelöscht.');
		} else {
			return error('Der Status konnte nicht gelöscht werden.');
		}
	}

	function delete_turnus ($id) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'DELETE FROM `turnus` WHERE `id` = '.esc($id);
		$result = rquery($query);

		$GLOBALS['get_turnus_name_by_id_cache'] = array();

		if($result) {
			return success('Der Turnus wurde erfolgreich gelöscht.');
		} else {
			return error('Der Turnus konnte nicht gelöscht werden.');
		}
	}

	function create_turnus ($name, $anzahl_monate, $wartungen_pro_monat = 1) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		if(preg_match('/^\d+$/', $anzahl_monate)) {
			if(!preg_match('/^\d+$/', $wartungen_pro_monat)) {
				warning("Der Wert ".fq($wartungen_pro_monat)." ist nicht valide. Er wird auf 1 gesetzt.");
				$wartungen_pro_monat = 1;
			}

			if($wartungen_pro_monat < 1) {
				warning("Der Wert für die Anzahl Wartungen pro Monat war unter 1. Er wird auf 1 gesetzt.");
				$wartungen_pro_monat = 1;
			}

			$query = 'INSERT IGNORE INTO `turnus` (`name`, `anzahl_monate`, `wartungen_pro_monat`) VALUES ('.esc(array($name, $anzahl_monate, $wartungen_pro_monat)).')';
			$result = rquery($query);
			if($result) {
				return success('Der Turnus wurde erfolgreich eingetragen.');
			} else {
				return error('Der Turnus konnte nicht eingetragen werden.');
			}
		} else {
			return error('Die Anzahl der Monate muss eine Zahl sein!');
		}
	}

	function create_select_for_kunden ($this_name = "show_kunde_id", $selected_id = null, $alle = 1) {
		if(!count($GLOBALS['create_select_for_kunden_cache'])) {
			$status_query = 'select id, concat(kunde, " (", ifnull(plz, "keine PLZ"), ", ", ifnull(ort, "kein Ort"), ")") as name from kunden';
			$result = rquery($status_query);
			while ($row = mysqli_fetch_row($result)) {
				$GLOBALS['create_select_for_kunden_cache'][] = $row;
			}
			$result->free();
		}

		if(is_null($selected_id)) {
			$selected_id = get_get('show_kunde_id');
		}

		$html = '<select style="width: 100%;" name="'.$this_name.'">'."\n";

		$chosen_alle = 'selected';
		if(!is_null($selected_id)) {
			$chosen_alle = '';
		}

		if($alle) {
			$html .= "\t<option $chosen_alle>Alle</option>\n";
		}

		foreach ($GLOBALS['create_select_for_kunden_cache'] as $row) {
			$id = $row[0];
			if(get_anzahl_anlagen_pro_kunde($id)) {
				$name = $row[1];
				$selected_this = '';
				if($id == $selected_id) {
					$selected_this = ' selected ';
				}
				$html .= "\t<option $selected_this value='$id'>$name</option>\n";
			}

		}
		$html .= "</select>\n";

		return($html);
	}

	function create_select_for_anlagen () {
		$status_query = 'select a.id as anlage_id, concat(a.name, " (", k.kunde, ")") as name from anlagen a join kunden k on a.kunde_id = k.id';
		$result = rquery($status_query);

		$selected_status_id = get_get('show_anlage_id');

		$html = '<select style="width: 100%;" name="show_anlage_id">'."\n";

		$chosen_alle = 'selected';
		if(!is_null($selected_status_id)) {
			$chosen_alle = '';
		}

		$html .= "\t<option $chosen_alle>Alle</option>\n";

		while ($row = mysqli_fetch_row($result)) {
			$id = $row[0];
			$name = $row[1];
			$selected_this = '';
			if($id == $selected_status_id) {
				$selected_this = ' selected ';
			}
			$html .= "\t<option $selected_this value='$id'>$name</option>\n";

		}
		$result->free();
		$html .= "</select>\n";

		return($html);
	}

	function cache_anlage_geodata ($anlage_id, $geostring) {
		$query = 'insert ignore into coordinate_data_cache (anlage_id, latlon) values ('.esc($anlage_id).', '.esc($geostring).')';
		rquery($query);
	}

	function create_select_for_status ($show_alle = 1, $name = 'show_status_id', $i = 0, $selected_status_id = null, $width = "100%", $class = '', $noautosubmit = 0) {
		if($noautosubmit) {
			$noautosubmit = " noautosubmit='1' ";
		} else {
			$noautosubmit = "";
		}

		$colors = array();
		if(empty($GLOBALS['create_select_for_status_array'])) {
			$status_query = 'select id, name, color from status';
			$result = rquery($status_query);
			while ($row = mysqli_fetch_row($result)) {
				$colors[] = $row;
			}
			$result->free();
			$GLOBALS['create_select_for_status_array'] = $colors;
		} else {
			$colors = $GLOBALS['create_select_for_status_array'];
		}

		if(is_null($selected_status_id)) {
			$selected_status_id = get_get($name);
		}

		$html = "<select $noautosubmit class='".$class."' style='width: ".$width."' name='$name'>\n";

		$chosen_alle = 'selected';
		if(!is_null($selected_status_id)) {
			$chosen_alle = '';
		}

		if($show_alle) {
			$html .= "\t<option $chosen_alle>Alle</option>\n";
		}

		foreach ($colors as $row) {
			$id = $row[0];
			$name = $row[1];
			$color = $row[2];
			$selected_this = '';
			if($id == $selected_status_id) {
				$selected_this = ' selected ';
			}
			$html .= "\t<option class='class_$color' $selected_this value='$id'>$name</option>\n";
		}
		$html .= "</select>\n";

		return($html);
	}

	function create_status ($name, $color) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'INSERT IGNORE INTO `status` (`name`, `color`) VALUES ('.esc(array($name, $color)).')';
		$result = rquery($query);
		if($result) {
			return success('Der Status wurde erfolgreich eingetragen.');
		} else {
			return error('Der Status konnte nicht eingetragen werden.');
		}
	}

	function create_function_right ($role_id, $name) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'INSERT IGNORE INTO `function_rights` (`name`, `role_id`) VALUES ('.esc($name).', '.esc($role_id).')';
		$result = rquery($query);
		if($result) {
			success('Das Funktionsrecht wurde erfolgreich eingetragen.');
		} else {
			error('Das Funktionsrecht konnte nicht eingetragen werden.');
		}
	}

	/* MySQL-delete-Funktionen */

	function delete_role ($id) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'DELETE FROM `role` WHERE `id` = '.esc($id);
		$result = rquery($query);
		if($result) {
			success('Die Rolle wurde erfolgreich gelöscht.');
		} else {
			error('Die Rolle konnte nicht gelöscht werden.');
		}
	}

	function delete_page ($id) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'DELETE FROM `page` WHERE `id` = '.esc($id);
		$result = rquery($query);
		if($result) {
			success('Die Seite wurde erfolgreich gelöscht.');
		} else {
			error('Die Seite konnte nicht gelöscht werden.');
		}
	}

	function delete_kunde ($id) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'DELETE FROM `kunden` WHERE `id` = '.esc($id);
		$result = rquery($query);

		$GLOBALS['get_kunden_array_cache'] = array();
		$GLOBALS['create_select_for_kunden_cache'] = array();
		$GLOBALS['get_anzahl_anlagen_pro_kunde_cache'] = array();

		if($result) {
			success('Der Kunde wurde erfolgreich gelöscht.');
		} else {
			error('Der Kunde konnte nicht gelöscht werden.');
		}
	}

	function delete_user ($id) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'DELETE FROM `users` WHERE `id` = '.esc($id);
		$result = rquery($query);
		if($result) {
			success('Der Benutzer wurde erfolgreich gelöscht.');
		} else {
			error('Der Benutzer konnte nicht gelöscht werden.');
		}
	}

	function delete_funktion_rights ($id) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'DELETE FROM `function_rights` WHERE `id` = '.esc($id);
		$result = rquery($query);
		if($result) {
			success('Das Funktionsrecht wurde erfolgreich gelöscht.');
		} else {
			error('Das Funktionsrecht konnte nicht gelöscht werden.');
		}
	}

	/* MySQL-update-Funktionen */

	function get_salt ($id) {
		$query = 'SELECT `salt` FROM `users` WHERE `id` = '.esc($id);
		$result = rquery($query);

		$id = NULL;

		while ($row = mysqli_fetch_row($result)) {
			$id = $row[0];
		}
		$result->free();

		return $id;

	}

	function get_and_create_salt ($id) {
		if(!check_function_rights(__FUNCTION__)) { return; }

		$result = get_salt($id);

		if($result) {
			return $result;
		} else {
			$salt = generate_random_string(100);
			$query = 'UPDATE `users` SET `salt` = '.esc($salt).' WHERE `id` = '.esc($id);
			$results = rquery($query);

			if($results) {
				$id = get_salt($id);
				if($id) {
					message('Salt eingefügt. ');
					return $id;
				} else {
					message('Salt konnte nicht eingefügt werden. ');
					return null;
				}
			} else {
				die(mysqli_error());
			}
		}
	}

	function update_own_data ($password) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$salt = get_and_create_salt($GLOBALS['logged_in_user_id']);
		$query = 'UPDATE `users` SET `password_sha256` = '.esc(hash('sha256', $password.$salt)).' WHERE `id` = '.esc($GLOBALS['logged_in_user_id']);
		$result = rquery($query);
		if($result) {
			success('Ihr Passwort wurde erfolgreich geändert. ');
		} else {
			message('Die Benutzerdaten konnten nicht geändert werden oder es waren keine Änderungen notwendig.');
		}
	}

	function convert_anything_to_boolean ($anything) {
		if($anything) {
			return 1;
		} else {
			return 0;
		}
	}

	function update_kunde($id, $name, $plz, $ort, $strasse, $hausnummern, $erinnerung, $pruefung, $pruefung_abgelehnt, $phone, $email, $land) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$erinnerung = convert_anything_to_boolean($erinnerung);
		$pruefung = convert_anything_to_boolean($pruefung);

		if(strlen($plz) > 10) {
			warning("Die PLZ ist zu lang und wurde auf 10 Zeichen gekürzt");
			$plz = substr($plz, 0, 10);
		}

		$query = 'UPDATE kunden SET kunde = '.esc($name).', plz = '.esc($plz).', ort = '.esc($ort).', strasse = '.esc($strasse).', hausnummern = '.esc($hausnummern).', erinnerung = '.esc($erinnerung).', pruefung = '.esc($pruefung).', pruefung_abgelehnt = '.esc($pruefung_abgelehnt).', phone = '.esc($phone).', email = '.esc($email).', land = '.esc($land).' WHERE id = '.esc($id);
		$result = rquery($query);

		$GLOBALS['get_kunden_array_cache'] = array();
		$GLOBALS['create_select_for_kunden_cache'] = array();

		if($result) {
			success('Die Kundendaten wurden erfolgreich geändert.');
		} else {
			message('Die Kundendaten konnten nicht geändert werden oder es waren keine Änderungen notwendig.');
		}
	}

	function update_user ($name, $id, $password, $role, $enable, $accpubdata) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$salt = get_and_create_salt($id);
		$enabled = 1;
		if(!$enable) {
			$enabled = 0;
		}
		$query = '';
		if($password) {
			$query = 'UPDATE `users` SET `username` = '.esc($name).', `password_sha256` = '.esc(hash('sha256', $password.$salt)).', `enabled` = '.esc($enabled).', `accepted_public_data` = '.esc($accpubdata).' WHERE `id` = '.esc($id);
		} else {
			$query = 'UPDATE `users` SET `username` = '.esc($name).', `enabled` = '.esc($enabled).', `accepted_public_data` = '.esc($accpubdata).' WHERE `id` = '.esc($id);
		}
		$result = rquery($query);
		if($result) {
			$query = 'INSERT INTO `role_to_user` (`role_id`, `user_id`) VALUES ('.esc($role).', '.esc($id).') ON DUPLICATE KEY UPDATE `role_id` = '.esc($role);
			$result = rquery($query);
			if($result) {
				success('Die Benutzerdaten und Rollenzuordnungen wurden erfolgreich geändert. ');
			} else {
				success('Die Benutzerdaten wurden erfolgreich geändert, aber die Rollenänderung hat nicht geklappt. ');
			}
		} else {
			message('Die Benutzerdaten konnten nicht geändert werden oder es waren keine Änderungen notwendig.');
		}
		$GLOBALS['reload_page'] = 1;
	}

	function update_startseitentext ($startseitentext) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = '';
		if(get_startseitentext()) {
			$query = 'UPDATE `startseite` SET `text` = '.esc($startseitentext);;
		} else {
			$query = 'INSERT INTO `startseite` (`text`) VALUES ('.esc($startseitentext).');';
		}
		$result = rquery($query);

		if($result) {
			success('Startseitentext erfolgreich editiert. ');
		} else {
			success('Startseitentext konnte nicht editiert werden. ');
		}
	}

	function update_funktion_rights ($id, $name) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'UPDATE `function_rights` SET `name` = '.esc($name).' WHERE `id` = '.esc($id);
		$result = rquery($query);
		if($result) {
			success('Das Funktionsrecht wurde erfolgreich geändert.');
		} else {
			message('Das Funktionsrecht konnte nicht geändert werden oder es waren keine Änderungen notwendig.');
		}
	}

	function get_turnus_id_by_anlage_id ($anlage_id) {
		$query = "select wv_turnus_id from anlagen where id = ".esc($anlage_id);
		return get_single_value_from_query($query);
	}

	function get_wartungen_pro_monat_from_turnus_id ($turnus_id) {
		$query = 'select wartungen_pro_monat from turnus where id = '.esc($turnus_id);
		return get_single_value_from_query($query);
	}

	function get_wartungen_pro_monat_from_anlage_id($anlage_id) {
		$query = 'select a.id as id, t.wartungen_pro_monat from anlagen a join turnus t on a.wv_turnus_id = t.id';
		return get_cached_result($anlage_id, $query, 'get_wartungen_pro_monat_from_anlage_id_cache');
	}

	function get_turnus ($id) {
		if(array_key_exists($id, $GLOBALS['get_turnus_cache'])) {
			return $GLOBALS['get_turnus_cache'][$id];
		} else {
			$query = 'select t.id, t.name, t.anzahl_monate, k.id as k_id from anlagen k join turnus t on t.id = k.wv_turnus_id';
			$result = rquery($query);

			while ($row = mysqli_fetch_assoc($result)) {
				$k_id = $row['k_id'];
				unset($row['k_id']);
				$GLOBALS['get_turnus_cache'][$k_id] = $row;
			}

			if(array_key_exists($id, $GLOBALS['get_turnus_cache'])) {
				return $GLOBALS['get_turnus_cache'][$id];
			} else {
				return array();
			}
		}
	}

	function get_ende_gewaehrleistung ($id, $mysql_format = 0, $month_only = 0) {
		if(!array_key_exists($id, $GLOBALS['get_ende_gewaehrleistung_cache'][$mysql_format][$month_only])) {
			$query = 'select year(ende_gewaehrleistung) as jahr, month(ende_gewaehrleistung) as monat, id from anlagen';
			if($mysql_format) {
				$query = 'select ende_gewaehrleistung, id from anlagen';
			}
			if($mysql_format && $month_only) {
				$query = 'select concat(year(ende_gewaehrleistung), "-", lpad(month(ende_gewaehrleistung), 2, "0")) as ende_gewaehrleistung, id from anlagen';
			}
			$result = rquery($query);

			$name = array();

			while ($row = mysqli_fetch_assoc($result)) {
				$this_id = $row['id'];
				if($mysql_format) {
					$name[$this_id] = $row['ende_gewaehrleistung'];
				} else {
					$name[$this_id] = $row;
				}
			}

			$GLOBALS['get_ende_gewaehrleistung_cache'][$mysql_format][$month_only] = $name;
		}

		return $GLOBALS['get_ende_gewaehrleistung_cache'][$mysql_format][$month_only][$id];
	}

	function get_ibn_beendet ($id, $mysql_format = 0, $month_only = 0) {
		if(array_key_exists($id, $GLOBALS['ibn_beendet_cache']) && array_key_exists($mysql_format, $GLOBALS['ibn_beendet_cache'][$id])) {
			return $GLOBALS['ibn_beendet_cache'][$id][$mysql_format];
		} else {
			$query = 'select year(ibn_beendet) as jahr, month(ibn_beendet) as monat, id from anlagen'; # where id = '.esc($id);
			if($mysql_format) {
				$query = 'select ibn_beendet, id from anlagen'; # where id = '.esc($id);
			}
			if($month_only && $mysql_format) {
				$query = 'select concat(year(ibn_beendet), "-", lpad(month(ibn_beendet), 2, "0")) as ibn_beendet, id from anlagen'; # where id = '.esc($id);
			}
			$result = rquery($query);

			$name = array();

			while ($row = mysqli_fetch_assoc($result)) {
				$thisid = $row['id'];
				unset($row['id']);
				if($mysql_format) {
					$name = $row['ibn_beendet'];
				} else {
					$name = $row;
				}
				$GLOBALS['ibn_beendet_cache'][$thisid][$mysql_format] = $name;
			}

			if(array_key_exists($id, $GLOBALS['ibn_beendet_cache']) && array_key_exists($mysql_format, $GLOBALS['ibn_beendet_cache'][$id])) {
				return $GLOBALS['ibn_beendet_cache'][$id][$mysql_format];
			} else {
				return array();
			}
		}
	}

	function get_eintrag_datum ($id) {
		$better_query = 'select jahr, lpad(monat, 2, "0") as monat from wartungen where id = '.esc($id);

		$result = rquery($better_query);

		$name = array();

		while ($row = mysqli_fetch_assoc($result)) {
			$name = $row;
		}

		return $name;
	}


	function get_letzter_eintrag ($id, $mysql_format = 0) {
		$better_query = 'select anlage_id as id, jahr, lpad(monat, 2, "0") as monat from wartungen where anlage_id = '.esc($id).' order by jahr desc, monat desc limit 1';
		if($mysql_format) {
			$better_query = 'select anlage_id as id, concat(jahr, "-", lpad(monat, 2, "0"), "-01") as letzter_eintrag from wartungen where and anlage_id = '.esc($id).' order by jahr desc, monat desc limit 1';
		}

		$result = rquery($better_query);

		$name = array();

		while ($row = mysqli_fetch_assoc($result)) {
			if($mysql_format) {
				$name = $row['letzter_eintrag'];
			} else {
				$name = $row;
			}
		}

		return $name;
	}

	function get_letzte_wartung ($id, $mysql_format = 0, $month_only = 0, $old_functionality = 1) {
		$ok_id = get_setting("status_ok");

		$query = 'select anlage_id as id, jahr, lpad(monat, 2, "0") as monat from wartungen where status_id = '.$ok_id.' and anlage_id = '.esc($id).' order by jahr desc, monat desc limit 1';
		
		if($mysql_format) {
			$query = 'select anlage_id as id, concat(jahr, "-", lpad(monat, 2, "0"), "-01") as letzte_wartung from wartungen where status_id = '.$ok_id.' and anlage_id = '.esc($id).' order by jahr desc, monat desc limit 1';
		}
		if($mysql_format && $month_only) {
			$query = 'select anlage_id as id, concat(jahr, "-", lpad(monat, 2, "0")) as letzte_wartung from wartungen where status_id = '.$ok_id.' and anlage_id = '.esc($id).' order by jahr desc, monat desc limit 1';
		}

		$result = rquery($query);

		$name = array();

		while ($row = mysqli_fetch_assoc($result)) {
			if($mysql_format) {
				$name = $row['letzte_wartung'];
			} else {
				$name = $row;
			}
		}

		if(!$name) {
			$query = 'select year(letzte_wartung) as jahr, lpad(month(letzte_wartung), 2, "0") as monat, id from anlagen';
			if($mysql_format) {
				$query = 'select letzte_wartung, id from anlagen';
			}
			$query .= ' where id = '.esc($id);
			$result = rquery($query);

			while ($row = mysqli_fetch_assoc($result)) {
				if($mysql_format) {
					$name = $row['letzte_wartung'];
				} else {
					$name = $row;
				}
			}
		}

		return $name;
	}

	function termin_already_exists($anlage_id, $this_year, $this_month) {
		if(is_null($anlage_id)) {
			return 0;
		}
		if(
			!(
				array_key_exists($anlage_id, $GLOBALS['termin_already_exists_cache']) &&
				array_key_exists($this_year, $GLOBALS['termin_already_exists_cache'][$anlage_id]) &&
				array_key_exists($this_month, $GLOBALS['termin_already_exists_cache'][$anlage_id][$this_year])
			)
		) {
			$query = 'select anlage_id from wartungen where jahr = '.esc($this_year).' and monat = '.esc($this_month);
			$res = rquery($query);
			$GLOBALS['termin_already_exists_cache'][$anlage_id][$this_year][$this_month] = 0;

			while ($row = mysqli_fetch_row($res)) {
				$this_anlage_id = $row[0];
				$GLOBALS['termin_already_exists_cache'][$this_anlage_id][$this_year][$this_month] = 1;
			}
			$res->free();
		}

		return $GLOBALS['termin_already_exists_cache'][$anlage_id][$this_year][$this_month];
	}

	function get_eintrag_nach_eintrag_datum ($id, $anlage_id) {
		$jahr = null;
		$monat = null;

		$query1 = 'select jahr, monat from wartungen where id = '.esc($id);
		$this_row = get_single_row_from_query($query1);
		$jahr = $this_row[0];
		$monat = $this_row[1];

		$query2 = 'select id from wartungen where anlage_id = '.esc($anlage_id).' and jahr >= '.esc($jahr).' and monat >= '.esc($monat).' and id != '.esc($id).' order by jahr asc, monat asc limit 1';
		$eintrag_danach_id = get_single_value_from_query($query2);

		return get_eintrag_datum($eintrag_danach_id);
	}

	function get_eintrag_nach_eintrag ($anlage_id, $jahr, $monat, $id) {
		$query = 'select id from wartungen where anlage_id = '.esc($anlage_id).' and jahr >= '.esc($jahr).' and monat >= '.esc($monat).' and id != '.esc($id).' order by jahr asc, monat asc limit 1';
		return get_single_value_from_query($query);
	}

	function date_is_on_or_after_ibn ($ibn_jahr, $ibn_monat, $jahr, $monat) {
		if($jahr > $ibn_jahr) {
			return 1;
		} else if($ibn_jahr == $jahr && $ibn_monat <= $monat) {
			return 1;
		}
		return 0;
	}

	function date_is_on_or_after_relevanter_eintrag ($letzter_relevanter_eintrag, $jahr, $monat) {
		$letzter_relevanter_eintrag_jahr = $letzter_relevanter_eintrag["jahr"];
		$letzter_relevanter_eintrag_monat = $letzter_relevanter_eintrag["monat"];

		if($letzter_relevanter_eintrag_jahr < $jahr) {
			return 1;
		} else if ($letzter_relevanter_eintrag_jahr == $jahr && $letzter_relevanter_eintrag_monat <= $monat) {
			return 1;
		}
		return 0;
	}

	function get_diff_monat ($date1, $date2) {
		$diff = $date1->diff($date2);

		$months = $diff->y * 12 + $diff->m + $diff->d / 30;

		return (int) round($months);
	}

	function is_letzte_wartung ($anlage_id, $jahr, $monat) {
		$letzte_wartung = get_letzte_wartung($anlage_id);
		if($jahr == $letzte_wartung["jahr"] && $monat == $letzte_wartung["monat"]) {
			return 1;
		}
		return 0;
	}

	function get_or_create_wartungstermine($anlage_id, $jahrstart, $jahreplus, $jahrauswahl, $monatauswahl, $kunde_id, $show_status_id, $from_last_entry = 0, $last_termin_id = null, $first_wartung_status = null, $plzbeginswith = null) {
		if(!isset($jahreplus)) {
			$jahreplus = 1;
		}

		$jahrend = $jahrstart + $jahreplus;

		$turnus = get_turnus($anlage_id);
		if(!count($turnus)) {
			warning("Die Termine der Anlage ".get_anlagen_link_name_by_id($anlage_id)." konnte nicht erstellt werden, weil der Turnus <b>leer</b> ist");
			return array(0, array());
		}
		$wartungen_pro_monat = get_wartungen_pro_monat_from_anlage_id($anlage_id);

		$letzter_relevanter_eintrag = null;
		if(!is_null($last_termin_id)) {
			$letzter_relevanter_eintrag_tmp = get_eintrag_datum($last_termin_id);
			$letzter_relevanter_eintrag = get_eintrag_nach_eintrag($anlage_id, $letzter_relevanter_eintrag_tmp["jahr"], $letzter_relevanter_eintrag_tmp["monat"], $last_termin_id);
			$letzter_relevanter_eintrag = get_eintrag_datum($letzter_relevanter_eintrag);
		} else {
			$letzter_relevanter_eintrag = get_letzter_eintrag($anlage_id);
		}

		if(!$letzter_relevanter_eintrag) {
			$letzter_relevanter_eintrag = get_letzte_wartung($anlage_id);
		}

		if(!(array_key_exists('jahr', $letzter_relevanter_eintrag) && array_key_exists('monat', $letzter_relevanter_eintrag) && $letzter_relevanter_eintrag['jahr'] && $letzter_relevanter_eintrag['monat'])) {
			#dier($letzter_relevanter_eintrag);
			warning("Die Termine der Anlage ".get_anlagen_link_name_by_id($anlage_id)." ($anlage_id) konnte nicht erstellt werden, weil irgendwas mit dem letzten relevanten Eintrag nicht stimmt");
			return array(0, array());
		}

		$ibn_beendet_am = get_ibn_beendet($anlage_id);

		$letzter_relevanter_eintrag_jahr = $letzter_relevanter_eintrag['jahr'];
		$letzter_relevanter_eintrag_monat = $letzter_relevanter_eintrag['monat'];

		$jahrstartgen = $jahrstart;
		if($letzter_relevanter_eintrag_jahr <= $jahrstart) {
			$jahrstartgen = $letzter_relevanter_eintrag_jahr;
		}

		$letzter_relevanter_eintrag_date = new DateTime("$letzter_relevanter_eintrag_jahr-$letzter_relevanter_eintrag_monat-01");

		$failed = 0;

		$i = 0;
		$values = array();

		foreach (range(1, $wartungen_pro_monat) as $n_te_wartung_pro_monat) {
			$j = 0;
			foreach (range($jahrstartgen, $jahrend) as $this_year) {
				foreach (range(1, 12) as $this_month) {
					if(
						(
							date_is_on_or_after_ibn($ibn_beendet_am['jahr'], $ibn_beendet_am['monat'], $this_year, $this_month) ||
							!$from_last_entry
						) && 
						date_is_on_or_after_relevanter_eintrag($letzter_relevanter_eintrag, $this_year, $this_month)
					) {
						$this_eintrag_date = new DateTime("$this_year-$this_month-01");
						$monat_diff = get_diff_monat($letzter_relevanter_eintrag_date, $this_eintrag_date);
						if($monat_diff % $turnus['anzahl_monate'] == 0) {
							if(!termin_already_exists($anlage_id, $this_year, $this_month)) {
								$status_id = get_setting("status_default");
								if($j == 0 && !is_null($first_wartung_status)) {
									$status_id = $first_wartung_status;
								}
								if(is_null($status_id)) {
									$status_id = get_setting("status_default");
								}
								if(is_null($first_wartung_status) && is_letzte_wartung($anlage_id, $this_year, $this_month)) {
									$status_id = get_setting("status_ok");
								}
								$this_part_query = '('.multiple_esc_join(array($this_month, $this_year, $status_id, "1", '', '', $anlage_id)).')';
								$values[] = $this_part_query;
								$j = $j + 1;
							}
						}
					}
					$i = $i + 1;
				}
			}
		}

		if(count($values)) {
			$query = 'INSERT INTO wartungen (monat, jahr, status_id, enabled, comment, comment2, anlage_id) VALUES '.
				join(', ', $values).
				' ON DUPLICATE KEY UPDATE enabled = if(inserted_manually = "0", "1", enabled)';

			if(!rquery($query)) {
				$failed = 1;
			}
		}

		if(!count($GLOBALS['anlagendaten_cache'])) {
			$query = 'SELECT
	`w`.`jahr`,
	`w`.`monat`,
	`s`.`id` as `status_id`,
	`s`.`name`,
	`w`.`comment`,
	`w`.`comment2`,
	`w`.`anlage_id`,
	`a`.`kunde_id` as `kunden_id`,
	`w`.`jahr`,
	`w`.`monat`,
	`w`.`id`,
	ifnull(`a`.`plz`, `k`.`plz`) as chosenplz
FROM 
	`wartungen` `w`
	RIGHT JOIN 
		`status` `s` ON `w`.`status_id` = `s`.`id`
	LEFT JOIN 
		`anlagen` as `a` ON `a`.`id` = `w`.`anlage_id` 
	LEFT JOIN
		`kunden` as `k` ON `a`.`kunde_id` = `k`.`id`
WHERE enabled = "1"';
			if(preg_match('/^\d+$/', $jahrstart) && preg_match('/^\d+$/', $jahrend)) {
				$query .= ' AND `jahr` >= '.esc($jahrstart).' AND `jahr` <= '.esc($jahrend);
			} else if(preg_match('/^\d+$/', $jahrauswahl)) {
				$query .= ' AND `w`.`jahr` = '.esc($jahrauswahl);
			}

			if(preg_match('/^\d+$/', $show_status_id)) {
				$query .= ' AND `status_id` = '.esc($show_status_id);
			}
			if(preg_match('/^\d+$/', $monatauswahl)) {
				$query .= ' AND `w`.`monat` = '.esc($monatauswahl);
			}

			if(preg_match('/^\d+$/', $plzbeginswith)) {
				$query .= ' HAVING `chosenplz` LIKE '.esc("$plzbeginswith%");
			}

			$result = rquery($query);

			while ($row = mysqli_fetch_assoc($result)) {
				$GLOBALS['anlagendaten_cache'][$row['kunden_id']][$row['anlage_id']][$row['jahr']][$row['monat']][$row['anlage_id']][] = $row;
			}
		}

		$data = null;
		if(array_key_exists($kunde_id, $GLOBALS['anlagendaten_cache']) && array_key_exists($anlage_id, $GLOBALS['anlagendaten_cache'][$kunde_id])) {
			$data = $GLOBALS['anlagendaten_cache'][$kunde_id][$anlage_id];
		}

		return array($failed, $data);
	}

	function get_monate_array () {
		$monate = array(
			array('1', 'Januar'),
			array('2', 'Februar'),
			array('3', 'März'),
			array('4', 'April'),
			array('5', 'Mai'),
			array('6', 'Juni'),
			array('7', 'Juli'),
			array('8', 'August'),
			array('9', 'September'),
			array('10', 'Oktober'),
			array('11', 'November'),
			array('12', 'Dezember')
		);

		return $monate;
	}

	function get_monate () {
		$monate = array(
			'1' => 'Januar',
			'2' => 'Februar',
			'3' => 'März',
			'4' => 'April',
			'5' => 'Mai',
			'6' => 'Juni',
			'7' => 'Juli',
			'8' => 'August',
			'9' => 'September',
			'10' => 'Oktober',
			'11' => 'November',
			'12' => 'Dezember'
		);

		return $monate;
	}

	function monat_zahl_nach_string ($zahl) {
		$zahl = ltrim($zahl, '0');;
		$monate = get_monate();

		if(array_key_exists($zahl, $monate)) {
			return $monate[$zahl];
		} else {
			dier("ERROR: >$zahl< cannot be converted to a month!");
		}
	}

	function email_link ($email, $mdash = 0) {
		if(empty($email)) {
			if($mdash) {
				return "&mdash;";
			} else {
				return null;
			}
		} else {
			return "<a href='mailto:".htmlentities($email)."'>".htmlentities($email)."</a>";
		}
	}

	function start_transaction () {
		rquery('SET autocommit = 0');
		rquery('START TRANSACTION');
	}

	function commit () {
		rquery('COMMIT');
		rquery('SET autocommit = 1');
	}

	function rollback () {
		rquery('ROLLBACK');
		rquery('SET autocommit = 1');
	}

	/*
	+-------+--------------+------+-----+---------+-------+
	| Field | Type         | Null | Key | Default | Extra |
	+-------+--------------+------+-----+---------+-------+
	| id    | int(11)      | NO   | PRI | NULL    |       |
	| name  | varchar(100) | YES  | MUL | NULL    |       |
	| telnr | varchar(200) | YES  |     | NULL    |       |
	| email | varchar(200) | YES  |     | NULL    |       |
	+-------+--------------+------+-----+---------+-------+
	 */
	function get_or_create_ansprechpartner ($ansprechpartner_email, $ansprechpartner_telnr, $ansprechpartner_name, $recursion = 0) {
		if($recursion > 1) {
			return null;
		}
		if(empty($ansprechpartner_email) && empty($ansprechpartner_telnr) && empty($ansprechpartner_name)) {
			return null;
		}
		$equals_email = "=";
		$equals_telnr = "=";

		if(empty($ansprechpartner_email)) {
			$equals_email = "is";
		}

		if(empty($ansprechpartner_telnr)) {
			$equals_telnr = "is";
		}

		$query = "select id from ansprechpartner where email $equals_email ".esc($ansprechpartner_email)." and telnr $equals_telnr ".esc($ansprechpartner_telnr)." and name = ".esc($ansprechpartner_name);
		$result = get_single_value_from_query($query);
		if((is_null($ansprechpartner_email) || !is_null($ansprechpartner_telnr) || !is_null($ansprechpartner_name)) && $result) {
			return $result;
		} else {
			$query = 'insert into ansprechpartner (name, telnr, email) values ('.multiple_esc_join(array($ansprechpartner_name, $ansprechpartner_telnr, $ansprechpartner_email)).')';
			if(rquery($query)) {
				success("Der Ansprechpartner wurde angelegt");
				return get_or_create_ansprechpartner($ansprechpartner_email, $ansprechpartner_telnr, $ansprechpartner_name, $recursion + 1);
			} else {
				error("Der Ansprechpartner konnte nicht angelegt werden");
				return null;
			}
		}
	}

	function get_ansprechpartner_by_anlage_id ($anlage_id) {
		$query = 'select id, ansprechpartner_id from anlagen';
		return get_cached_result($anlage_id, $query, 'get_ansprechpartner_by_anlage_id_cache');
	}

	function get_ansprechpartner_daten ($id) {
		if(is_null($id)) {
			return array(
				"name" => null,
				"telnr" => null,
				"email" => null
			);
		}

		if(array_key_exists($id, $GLOBALS['get_ansprechpartner_daten_cache'])) {
			return $GLOBALS['get_ansprechpartner_daten_cache'][$id];
		} else {
			$query = 'select id, name, telnr, email from ansprechpartner';

			$result = rquery($query);
			while ($row = mysqli_fetch_row($result)) {
				$this_id = $row[0];

				$daten = array();
				$daten["name"] = $row[1];
				$daten["telnr"] = $row[2];
				$daten["email"] = $row[3];

				$GLOBALS['get_ansprechpartner_daten_cache'][$this_id] = $daten;
			}
		}

		if(array_key_exists($id, $GLOBALS['get_ansprechpartner_daten_cache'])) {
			return $GLOBALS['get_ansprechpartner_daten_cache'][$id];
		} else {
			return array(
				"name" => null,
				"telnr" => null,
				"email" => null
			);
		}
	}

	function fill_ansprechpartner_cache () {
		$query = "select id, telnr, email, name from ansprechpartner";
		$result = rquery($query);
		while ($row = mysqli_fetch_row($result)) {
			$t_id = $row[0];
			$GLOBALS['get_ansprechpartner_telnr_cache'][$t_id] = $row[1];
			$GLOBALS['get_ansprechpartner_email_cache'][$t_id] = $row[2];
			$GLOBALS['get_ansprechpartner_name_cache'][$t_id] = $row[3];
		}
	}

	function get_ansprechpartner_telnr ($id) {
		if(is_null($id)) {
			return null;
		}
		if(!array_key_exists($id, $GLOBALS['get_ansprechpartner_telnr_cache'])) {
			fill_ansprechpartner_cache();
		}
		return $GLOBALS['get_ansprechpartner_telnr_cache'][$id];
	}

	function get_ansprechpartner_email ($id) {
		if(is_null($id)) {
			return null;
		}
		if(!array_key_exists($id, $GLOBALS['get_ansprechpartner_email_cache'])) {
			fill_ansprechpartner_cache();
		}
		return $GLOBALS['get_ansprechpartner_email_cache'][$id];
	}

	function get_ansprechpartner_name ($id) {
		if(is_null($id)) {
			return null;
		}
		if(!array_key_exists($id, $GLOBALS['get_ansprechpartner_name_cache'])) {
			fill_ansprechpartner_cache();
		}
		return $GLOBALS['get_ansprechpartner_name_cache'][$id];
	}


	function get_or_create_anlage ($kunde_id, $name, $turnus_id, $ibn_beendet_am, $letzte_wartung, $ende_gewaehrleistung, $this_anlage_comment, $status_default_id, $wartungspauschale, $ansprechpartner_id, $zeit_pro_wartung, $plz = null, $ort = null, $strasse = null, $hausnummer = null, $land = null, $material_wartung = null) {
		$id_query = 'select id from anlagen where kunde_id = '.esc($kunde_id).' and name = '.esc($name).' and this_anlage_comment = '.esc($this_anlage_comment).
			' and ansprechpartner_id = '.esc($ansprechpartner_id).' and wv_turnus_id = '.esc($turnus_id);
		$id = get_single_value_from_query($id_query);
		if(empty($id)) {
			return create_anlage($kunde_id, $name, $turnus_id, $ibn_beendet_am, $letzte_wartung, $ende_gewaehrleistung, $this_anlage_comment, $status_default_id, $wartungspauschale, $ansprechpartner_id, $zeit_pro_wartung, $plz, $ort, $strasse, $hausnummer, $land, $material_wartung);
		} else {
			return $id;
		}
	}

	function create_anlage ($kunde_id, $name, $turnus_id, $ibn_beendet_am, $letzte_wartung, $ende_gewaehrleistung, $this_anlage_comment, $status_default_id, $wartungspauschale, $ansprechpartner_id, $zeit_pro_wartung, $plz = null, $ort = null, $strasse = null, $hausnummer = null, $land = null, $material_wartung = null) {
		if(!check_function_rights(__FUNCTION__)) { return; }

		$name = preg_replace('/^\s*/', '', $name);
		$name = preg_replace('/\s*$/', '', $name);
		$name = shorten($name, 100, "Der Name");

		$plz = shorten($plz, 10, "Die PLZ");

		if(!$name) {
			warning("Jede Anlage muss einen Namen haben!");
			$GLOBALS['insert_anlage_failed'] = 1;
			return null;
		}

		if($letzte_wartung && !$ibn_beendet_am) {
			warning("Keine IBN für die Anlage &raquo;".htmle($name)."&laquo; eingegeben, es wird das Datum der letzten Wartung genommen!");
			$ibn_beendet_am = $letzte_wartung;
		}

		if(!$ibn_beendet_am) {
			error("Keine beendete Inbetriebnahne eingegeben!");
			$GLOBALS['insert_anlage_failed'] = 1;
			if($GLOBALS['return_null_if_anlage_creation_failed']) {
				return null;
			}
		}

		if(!$letzte_wartung) {
			warning("Keine letzte Wartung eingegeben, es wird das Datum der Inbetriebnahme genommen!");
			$letzte_wartung = $ibn_beendet_am;
		}

		if(!$ende_gewaehrleistung) {
			warning("Kein Ende der Gewährleistung für die Anlage &raquo;".htmle($name)."&laquo; eingegeben!");
		}

		$ibn_unix_time = strtotime(european_data_to_us_date($ibn_beendet_am).' 00:00:00');
		$letzte_wartung_unix = strtotime(european_data_to_us_date($letzte_wartung).' 00:00:00');
		if($letzte_wartung_unix < $ibn_unix_time) {
			warning("Die Letzte Wartung war vor der Inbetriebnahme. Irgendwas stimmt hier vielleicht nicht.");
		}
		$query = 'insert into anlagen (kunde_id, name, wv_turnus_id, ibn_beendet, letzte_wartung, ende_gewaehrleistung, this_anlage_comment, wartungspauschale, ansprechpartner_id, zeit_pro_wartung, plz, ort, strasse, hausnummer, land, material_wartung) values ('.multiple_esc_join(array($kunde_id, $name, $turnus_id, european_data_to_us_date($ibn_beendet_am), european_data_to_us_date($letzte_wartung), european_data_to_us_date($ende_gewaehrleistung), $this_anlage_comment, string_to_number($wartungspauschale), $ansprechpartner_id, string_to_number($zeit_pro_wartung), $plz, $ort, $strasse, $hausnummer, $land, $material_wartung)).')';
		$res = rquery($query, 1, 0, 0);

		if($res) {
			$last_id = $GLOBALS['dbh']->insert_id;
			prepare_wartungstermine_nach_anlegen_von_anlage($last_id, $status_default_id);
			success('Die Anlage mit dem Namen '.get_anlagen_link_name_by_id($last_id).' wurde erfolgreich eingefügt. ');
			return $last_id;

		} else {
			error('Die Anlage konnte nicht eingefügt werden. ');
		}
		return null;
	}

	function prepare_wartungstermine_nach_anlegen_von_anlage ($anlage_id = null, $first_wartung_status = null) {
		if(is_null($first_wartung_status)) {
			$first_wartung_status = get_setting('status_default');
		}
		$jahrstart = date("Y") - get_setting("jahre_minus_nach_erstellen_anlage");
		$jahrauswahl = date("Y");
		$jahreplus = get_setting("jahre_plus_nach_erstellen_anlage") + 1;

		prepare_wartungstermine(
			$jahrstart,	# 1
			$jahreplus,	# 2
			$jahrauswahl,	# 3
			null,		# 4
			null,		# 5
			$anlage_id,	# 6
			null,		# 8
			null,		# 9
			null,		# 10
			null,		# 11
			$first_wartung_status # 12
		);
	}

	function delete_ersatzteil ($ersatzteil_id) {
		$query = 'delete from ersatzteil where id = '.esc($ersatzteil_id);
		$res = rquery($query);

		if($res) {
			return success('Das Ersatzteil wurde erfolgreich gelöscht. ');
		} else {
			return error('Das Ersatzteil konnte nicht gelöscht werden. ');
		}
	}

	function delete_anlage ($anlage_id) {
		if(!check_function_rights(__FUNCTION__)) { return; }

		$query = 'delete from anlagen where id = '.esc($anlage_id);
		$res = rquery($query);

		$GLOBALS['get_anzahl_anlagen_pro_kunde_cache'] = array();
		$GLOBALS['get_addressdaten_cache'] = array();

		if($res) {
			success('Die Anlage wurde erfolgreich gelöscht. ');
		} else {
			error('Die Anlage konnte nicht gelöscht werden. ');
		}
	}

	function update_anlage ($anlage_id, $name, $turnus_id, $ibn_beendet_am, $letzte_wartung, $ende_gewaehrleistung, $this_anlage_comment, $wartungspauschale, $ansprechpartner_id = null, $zeit_pro_wartung = null, $plz = null, $ort = null, $strasse = null, $hausnummer = null, $land = null, $material_wartung = null) {
		if(!check_function_rights(__FUNCTION__)) { return; }

		$name = preg_replace('/^\s*/', '', $name);
		$name = preg_replace('/\s*$/', '', $name);

		if(!$ibn_beendet_am) {
			error("Keine beendete Inbetriebnahme eingegeben!");
			return 0;
		}

		if(!$letzte_wartung) {
			warning("Keine letzte Wartung eingegeben, es wird das Datum der Inbetriebnahme genommen!");
			$letzte_wartung = $ibn_beendet_am;
		}

		if(!$ende_gewaehrleistung) {
			warning("Kein Ende der Gewährleistung für die Anlage ".get_anlagen_link_name_by_id($anlage_id)." eingegeben!");
		}

		$ibn_unix_time = strtotime(european_data_to_us_date($ibn_beendet_am).' 00:00:00');
		$letzte_wartung_unix = strtotime(european_data_to_us_date($letzte_wartung).' 00:00:00');
		if($letzte_wartung_unix < $ibn_unix_time) {
			warning("Die Letzte Wartung war vor der Inbetriebnahme. Irgendwas stimmt hier vielleicht nicht.");
		}

		$query = 'update anlagen set name = '.esc($name).
			', ibn_beendet = '.esc(european_data_to_us_date($ibn_beendet_am)).
			', letzte_wartung = '.esc(european_data_to_us_date($letzte_wartung)).
			', wartungspauschale = '.esc(string_to_number($wartungspauschale)).
			', `ende_gewaehrleistung` = '.esc(european_data_to_us_date($ende_gewaehrleistung)).
			', this_anlage_comment = '.esc($this_anlage_comment).
			', ansprechpartner_id = '.esc($ansprechpartner_id).
			', zeit_pro_wartung = '.esc(string_to_number($zeit_pro_wartung)).
			', plz = '.esc($plz).
			', ort = '.esc($ort).
			', strasse = '.esc($strasse).
			', hausnummer = '.esc($hausnummer).
			', land = '.esc($land).
			', material_wartung = '.esc($material_wartung).
			' where id = '.esc($anlage_id);
		$res = rquery($query);

		if($res) {
			if($turnus_id != get_turnus_id_by_anlage_id($anlage_id)) {
				update_turnus_update_tabelle($anlage_id, $turnus_id);
			}
			prepare_wartungstermine_nach_anlegen_von_anlage();
			$GLOBALS['get_addressdaten_cache'] = array();
			success('Die Anlage wurde erfolgreich geändert. ');
		} else {
			error('Die Anlage konnte nicht geändert werden. ');
		}
	}

	function fill_front_zeroes ($str, $len, $pre = '0') {
		while (strlen($str) < $len) {
			$str = "$pre$str";
		}
		return $str;
	}

	function update_letzte_wartung ($anlage_id, $year, $month, $day) {
		$query = 'UPDATE anlagen SET letzte_wartung = '.esc(fill_front_zeroes($year, 2)."-".fill_front_zeroes($month, 2).'-'.fill_front_zeroes($day, 2)).' WHERE id = '.esc($anlage_id);
		$result = rquery($query);
		if($result) {
			return 1;
		} else {
			error("Neuerer Wartungstermin konnte nicht eingetragen werden: $month.$year. ");
			return 0;
		}
	}

	function get_anlage_id_by_termin_id ($termin_id) {
		$query = 'select w.anlage_id from wartungen w where id = '.esc($termin_id);

		$anlage_id = null;

		$res = rquery($query);

		while ($row = mysqli_fetch_row($res)) {
			$anlage_id = $row[0];
		}
		$res->free();

		return $anlage_id;
	}

	function update_wartungstermine($termine, $kommentare, $kommentare2) {
		if(!check_function_rights(__FUNCTION__)) { return; }

		$error = 0;

		foreach ($termine as $termin_id => $status) {
			$letzte_wartung = null;
			$kommentar = null;
			$kommentar2 = null;
			if(isset($kommentare[$termin_id])) {
				$kommentar = $kommentare[$termin_id];
			} else {
				debug("Für $termin_id ist kein Kommentar 1 gesetzt.");
			}
			if(isset($kommentare2[$termin_id])) {
				$kommentar2 = $kommentare2[$termin_id];
			} else {
				debug("Für $termin_id ist kein Kommentar 2 gesetzt.");
			}

			$query = 'UPDATE `wartungen` SET `comment` = '.esc($kommentar).', `comment2` = '.esc($kommentar2).', `status_id` = '.esc($status).' WHERE `id`= '.esc($termin_id);
			$result = rquery($query);
			if(!$result) {
				$error = 1;
				debug("Query\n$query\nist fehlgeschlagen!");
			}

			if(!isset($letzte_wartung)) {
				$letzte_wartung = get_letzte_wartung(get_anlage_id_by_termin_id($termin_id));
				if(!$letzte_wartung) {
					debug("Letzte Wartung ist leer!");
				}
			}
		}

		if($error) {
			error("Irgendwas ist schiefgegangen");
		} else {
			success("Eintragen hat geklappt!");
		}
	}

	function get_last_update_tabelle ($tabelle) {
		$query = "SELECT unix_timestamp(UPDATE_TIME) as last_update FROM information_schema.tables WHERE TABLE_SCHEMA = ".esc($GLOBALS['dbname'])." AND TABLE_NAME = ".esc($tabelle);

		$result = rquery($query);

		$last_updated = null;

		while ($row = mysqli_fetch_row($result)) {
			$last_updated = $row[0];
		}
		$result->free();

		return $last_updated;
	}

	/*
		id ist die page-id
		role_to_page muss ein array sein mit ids von rollen, die der seite
		zugeordnet werden sollen
	 */
	function update_or_create_role_to_page ($id, $role_to_page) {
		if(!check_function_rights(__FUNCTION__)) { return; }

		if(isset($role_to_page) && !is_array($role_to_page)) {
			$temp = array();
			$temp[] = $role_to_page;
		}

		if(is_array($role_to_page) && count($role_to_page)) {
			$at_least_one_role_set = 0;
			foreach ($role_to_page as $trole) {
				$rname = get_role_name($trole);
				if($rname) {
					$at_least_one_role_set = 1;
				}
			}

			$roles_cleared = 0;
			if($at_least_one_role_set) {
				$query = 'DELETE FROM `'.$GLOBALS['dbname'].'`.`role_to_page` WHERE `page_id` = '.esc($id);
				$result = rquery($query);
				if($result) {
					success("Die Rollen wurden erfolgreich geklärt. ");
					$roles_cleared = 1;
				} else {
					error("Die Rollen wurden NICHT erfolgreich geklärt. ");
				}
			}

			if($roles_cleared) {
				foreach ($role_to_page as $trole) {
					$rname = get_role_name($trole);
					if($rname) {
						$query = 'INSERT IGNORE INTO `'.$GLOBALS['dbname'].'`.`role_to_page` (`role_id`, `page_id`) VALUES ('.esc($trole).', '.esc($id).')';
						$result = rquery($query);
						if($result) {
							success("Die Rolle $rname wurde erfolgreich hinzugefügt. ");
						} else {
							error("Die Rolle $rname konnte nicht eingefügt werden. ");
						}
					} else {
						error("Die Rolle mit der ID $trole existiert nicht. ");
					}
				}
			}
		}
	}

	function create_new_page ($name, $file, $show_in_navigation, $parent, $role_to_page, $beschreibung, $hinweis) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		if($parent == "") {
			$parent = null;
		}
		$query = 'INSERT IGNORE INTO `'.$GLOBALS['dbname'].'`.`page` (`name`, `file`, `show_in_navigation`, `parent` ) VALUES ('.esc(array($name, $file, $show_in_navigation, $parent)).')';
		$result = rquery($query);
		if($result) {
			$id = get_page_id_by_filename($file);

			if($id) {
				if(isset($role_to_page)) {
					update_or_create_role_to_page($id, $role_to_page);
				}

				if(isset($beschreibung)) {
					update_page_info($id, $beschreibung);
				}

				if(isset($hinweis)) {
					update_hinweis($id, $hinweis);
				}

				success('Die Seite wurde erfolgreich hinzugefügt. ');
			} else {
				error('Die letzte insert-id konnte nicht ermittelt werden, aber die Seite wurde erstellt. ');
			}
		} else {
			message('Die Seite konnte nicht erfolgreich hinzugefügt werden. ');
		}
	}

	function update_page_full($id, $name, $file, $show_in_navigation, $parent, $role_to_page, $beschreibung, $hinweis) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		if($parent == "") {
			$parent = null;
		}
		$query = 'UPDATE `page` SET `name` = '.esc($name).', `file` = '.esc($file).', `show_in_navigation` = '.esc($show_in_navigation).', `parent` = '.esc($parent).' WHERE `id` = '.esc($id);
		$result = rquery($query);
		if($result) {
			if(isset($role_to_page)) {
				update_or_create_role_to_page($id, $role_to_page);
			}

			if(isset($beschreibung)) {
				update_page_info($id, $beschreibung);
			}

			if(isset($hinweis)) {
				update_hinweis($id, $hinweis);
			}

			success('Die Seite wurde erfolgreich geändert. ');
		} else {
			message('Die Seite konnte nicht geändert werden oder es waren keine Änderungen notwendig. ');
		}
	}

	function update_role ($id, $name) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'UPDATE `role` SET `name` = '.esc($name).' WHERE `id` = '.esc($id);;
		$result = rquery($query);
		if($result) {
			success('Die Rolle wurde erfolgreich geändert. ');
		} else {
			message('Die Rolle konnte nicht geändert werden oder es waren keine Änderungen notwendig. ');
		}
	}

	function update_text ($page_id, $text) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'INSERT INTO `seitentext` (`page_id`, `text`) VALUES ('.esc($page_id).', '.esc($text).') ON DUPLICATE KEY UPDATE `text` = '.esc($text);
		$result = rquery($query);
		if($result) {
			success('Der Seitentext wurde erfolgreich geändert.');
		} else {
			message('Der Seitentext konnte nicht geändert werden oder es waren keine Änderungen notwendig.');
		}
	}

	function update_status ($id, $name, $color) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		if(isset($id)) {
			if(isset($name)) {
				if(isset($color)){
					$query = 'UPDATE `status` SET `name` = '.esc($name).', `color` = '.esc($color).' WHERE `id` = '.esc($id);
					$result = rquery($query);
					if($result) {
						$GLOBALS['status_color_cache'] = array();
						return success('Der Status wurde erfolgreich geändert.');
					} else {
						return message('Der Status konnte nicht geändert werden oder es waren keine Änderungen notwendig.');
					}
				} else {
					return error("Es muss eine Farbe definiert werden. ");
				}
			} else {
				return error("Leerer Name. ");
			}
		} else {
			return error("Falsche Status-ID. ");
		}
	}

	function update_anlagenturnus ($anlage_id, $turnus_id) {
		# TODO!!! Alle nachfolgenden EInträge löschen?!?!
		$query = 'update anlagen set wv_turnus_id = '.esc($turnus_id).' where id = '.esc($anlage_id);
		$res = rquery($query);
		if($res) {
			success("Der Turnus der Anlage ".htmle(get_anlagen_name_by_id($anlage_id))." wurde auf ".htmle(get_turnus_name_by_id($turnus_id))." gesetzt.");
			return true;
		} else {
			error("Der Turnus der Anlage ".htmle(get_anlagen_name_by_id($anlage_id))." konnte nicht auf ".htmle(get_turnus_name_by_id($turnus_id))." gesetzt werden.");
			return false;
		}
	}

	function delete_tabelle_data_from_now_on ($anlage_id) {
		$jahr = date('Y');
		$monat = date('m');
		$query = 'delete from wartungen where anlage_id = '.esc($anlage_id).' and ((jahr = '.esc($jahr).' and monat > '.esc($monat).') or jahr > '.esc($jahr).')';
		$res = rquery($query);
		if($res) {
			success("Die alten Daten der Anlage ".htmle(get_anlagen_name_by_id($anlage_id))." wurden von $jahr-$monat an gelöscht.");
			return true;
		} else {
			error("Die alten Daten Anlage ".htmle(get_anlagen_name_by_id($anlage_id))." konnte nicht auf gelöscht werden.");
			return false;
		}
	}

	function update_turnus_update_tabelle ($anlage_id, $turnus_id) {
		# Update die Turnus ID der Anlage
		# Lösche alle Tabelledaten vom aktuellen Datum
		# prepare_wartungstermine_nach_anlegen_von_anlage()

		start_transaction();

		if(update_anlagenturnus($anlage_id, $turnus_id)) {
			if(delete_tabelle_data_from_now_on($anlage_id)) {
				prepare_wartungstermine_nach_anlegen_von_anlage($anlage_id);
				commit();
			} else {
				warning("Die bisher gemachten Aktionen werden rückgängig gemacht");
				rollback();
			}
		} else {
			warning("Die bisher gemachten Aktionen werden rückgängig gemacht");
			rollback();
		}
	}

	function update_turnus ($id, $name, $anzahl_monate, $wartungen_pro_monat = 1) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		if(isset($id)) {
			if(isset($name)) {
				if(isset($anzahl_monate)){
					if(!preg_match('/^\d+$/', $wartungen_pro_monat)) {
						warning("Der Wert ".fq($wartungen_pro_monat)." ist nicht valide. Er wird auf 1 gesetzt.");
						$wartungen_pro_monat = 1;
					}

					if($wartungen_pro_monat < 1) {
						warning("Der Wert für die Anzahl Wartungen pro Monat war unter 1. Er wird auf 1 gesetzt.");
						$wartungen_pro_monat = 1;
					}

					if(preg_match('/^\d+$/', $anzahl_monate)) {
						$query = 'UPDATE `turnus` SET `name` = '.esc($name).', `anzahl_monate` = '.esc($anzahl_monate).', wartungen_pro_monat = '.esc($wartungen_pro_monat).' WHERE `id` = '.esc($id);
						$result = rquery($query);
						if($result) {
							success('Der Turnus wurde erfolgreich geändert.');
						} else {
							message('Der Turnus konnte nicht geändert werden oder es waren keine Änderungen notwendig.');
						}
					} else {
						error("Die Anzahl von Monaten muss eine Zahl sein! ");
					}
				} else {
					error("Es muss eine Anzahl von Tagen definiert werden. ");
				}
			} else {
				error("Leerer Name. ");
			}
		} else {
			error("Falsche Turnus-ID. ");
		}
	}

	function get_or_create_turnus_by_anzahl_monate ($anzahl_monate, $wartungen_pro_monat = 1, $recursion = 0) {
		if($recursion > 1) {
			die("deep recursion $recursion for $anzahl_monate!");
		}
		if($anzahl_monate <= 0) {
			return null;
		}

		$anzahl_monate_fixed = $anzahl_monate;
		if(preg_match('/^\d+\.\d+$/', $anzahl_monate)) {
			$anzahl_monate_fixed = floor($anzahl_monate);
		}

		$query = 'select id from turnus where anzahl_monate = '.esc($anzahl_monate_fixed).' and wartungen_pro_monat = '.esc($wartungen_pro_monat);
		$id = get_single_value_from_query($query);
		if($id) {
			return $id;
		} else {
			$name = "$anzahl_monate_fixed Monate";
			if($anzahl_monate_fixed == 1) {
				$name = "$anzahl_monate_fixed Monat";
			}

			if($wartungen_pro_monat != 1) {
				if($anzahl_monate_fixed == 1) {
					$name = $wartungen_pro_monat."x pro Monat";
				} else {
					$name .= " (".$wartungen_pro_monat."x pro Monat)";
				}
			}

			$query = 'insert into turnus (name, anzahl_monate, wartungen_pro_monat) values ('.esc($name).', '.esc($anzahl_monate_fixed).', '.esc($wartungen_pro_monat).')';
			if(rquery($query)) {
				return get_or_create_turnus_by_anzahl_monate($anzahl_monate_fixed, $wartungen_pro_monat, ++$recursion);
			} else {
				die("ERROR");
			}
		}
	}

	function get_turnus_name_by_id ($id) {
		if(!array_key_exists($id, $GLOBALS['get_turnus_name_by_id_cache'])) {
			$query = 'select name from turnus where id = '.esc($id);
			$GLOBALS['get_turnus_name_by_id_cache'][$id] = get_single_value_from_query($query);
		}
		return $GLOBALS['get_turnus_name_by_id_cache'][$id];
	}

	function update_hinweis ($page_id, $hinweis) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		if(get_page_name_by_id($page_id)) {
			if(isset($hinweis)) {
				$query = 'INSERT INTO `hinweise` (`page_id`, `hinweis`) VALUES ('.esc($page_id).', '.esc($hinweis).') ON DUPLICATE KEY UPDATE `hinweis` = '.esc($hinweis);
				$result = rquery($query);
				if($result) {
					success('Der neue Hinweis wurde erfolgreich geändert.');
				} else {
					warning('Der Hinweis konnte nicht geändert werden oder es waren keine Änderungen notwendig.');
				}
			} else {
				warning("Leerer Hinweis. ");
			}
		} else {
			error("Falsche Page-ID. ");
		}
	}

	function update_page_info ($id, $info) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'INSERT INTO `page_info` (`page_id`, `info`) VALUES ('.esc($id).', '.esc($info).') ON DUPLICATE KEY UPDATE `info` = '.esc($info);
		$result = rquery($query);
		if($result) {
			success('Die Seiteninfo wurde erfolgreich geändert.');
		} else {
			message('Die Seiteninfo konnte nicht geändert werden oder es waren keine Änderungen notwendig.');
		}
	}

	/* Darstellungsfunktionen */

	function simple_edit ($columnnames, $table, $columns, $datanames, $block_user_id, $htmlentities = 1, $special_input = array(), $order_by = null, $classes = array()) {
		$query = 'SELECT `id`, `'.join('`, `', $columnnames).'` FROM `'.$table.'`';
		if($order_by) {
			$query .= ' ORDER BY `'.join('`, `', $order_by).'`';
		}
		$result = rquery($query);

?>
			<table>
				<tr>
<?php
		foreach ($columns as $c) {
?>
					<th><?php print $c ?></th>
<?php
		}
?>
				</tr>
<?php
		while($row = mysqli_fetch_row($result)) {
?>
			<tr>
				<form class="form" method="post" action="admin.php?page=<?php print htmlentities($GLOBALS['this_page_number']); ?>">
					<input type="hidden" name="update_<?php print $table; ?>" value="1" />
<?php
			$i = 0;
			foreach ($datanames as $c) {
				if(!is_null($special_input) && is_array($special_input) && array_key_exists($i, $special_input)) {
					print $special_input[$i];
				} else {
					if($i == 0) {
?>
								<input type="hidden" value="<?php print htmlentities($row[0]); ?>" name="<?php print htmlentities($datanames[0]); ?>" />
<?php
					} else {
						$class = '';
						if(array_key_exists($i, $classes)) {
							$class = " class='".$classes[$i]."'";
						}
?>
								<td><input <?php print $class; ?> type="<?php print $c == 'password' ? 'password' : 'text'; ?>" name="<?php print $c; ?>" placeholder="<?php print $c; ?>" value="<?php print $c == 'password' ? '' : ($htmlentities ? htmlentities($row[$i]) : $row[$i]); ?>" /></td>
<?php
					}
				}
				$i++;
			}
?>
					<td><input type="submit" value="Speichern" /></td>
<?php
			if($block_user_id && $GLOBALS['logged_in_data'][0] == $row[0]) {
?>
						<td><button name="delete" value="1" disabled>Löschen</button></td>
<?php
			} else {
?>
						<td><input type="submit" name="delete" value="Löschen" /></td>
<?php
			}
?>
				</form>
			</tr>
<?php
		}
?>
			<tr>
				<form class="form" method="post" action="admin.php?page=<?php print htmlentities($GLOBALS['this_page_number']); ?>">
					<input type="hidden" name="create_<?php print $table; ?>" value="1" />
<?php
		$i = 0;
		foreach ($datanames as $c) {
			if($i != 0) {
				$class = '';
				if(array_key_exists($i, $classes)) {
					$class = " class='".$classes[$i]."'";
				}
?>
							<td><input <?php print $class; ?> type="<?php print $c == 'password' ? 'password' : 'text'; ?>" name="new_<?php print $c; ?>" placeholder="<?php print $c; ?>" /></td>
<?php
			}
			$i++;
		}
?>
					<td><input type="submit" class="submit" value="Speichern" /></td>
					<td>&mdash;</td>
				</form>
			</tr>
		</table>
<?php
	}

	function create_select_str ($data, $chosen, $name, $allow_empty = 0, $class = '', $attr = array(), $onchange = null, $width = null) {
		$attr_str = '';
		if(count($attr)) {
			foreach ($attr as $this_name => $value) {
				$attr_str .= " data-$this_name=".json_encode($value);
			}
		}
		$changestr = '';
		if(!is_null($onchange)) {
			$changestr = " onchange='$onchange' ";
		}
		$style = '';
		if(!is_null($width)) {
			$style = ' style="width: '.$width.'px;" ';
		}
		$str = '<select '.$style.' '.$changestr.' name="'.htmlentities($name).'"'.($class ? " class='$class'" : '').$attr_str.'>'."\n";
		if($allow_empty) {
			$str .= '<option value="">&mdash;</option>'."\n";
		}
		foreach ($data as $datum) {
			if(is_array($datum)) {
				$str .= '<option value="'.$datum[0].'"'.(($chosen && $datum[0] == $chosen) ? ' selected' : '').'>'.htmlentities($datum[1]).'</option>'."\n";
			} else {
				$str .= '<option value="'.$datum.'" '.(($chosen && $datum == $chosen) ? ' selected' : '').'>'.htmlentities($datum).'</option>'."\n";
			}
		}
		$str .= '</select>';
		return $str;
	}

	function create_select ($data, $chosen, $name, $allow_empty = 0, $autosubmit_warning_yesno = null, $resetdefault = null, $noautosubmit = 0) {
		if(!is_null($autosubmit_warning_yesno)) {
			$autosubmit_warning_yesno = " autosubmitwarning='$autosubmit_warning_yesno' ";
		} else {
			$autosubmit_warning_yesno = "";
		}

		if(!is_null($resetdefault)) {
			$resetdefault = " resetdefault='$resetdefault' ";
		} else {
			$resetdefault = "";
		}

		if($noautosubmit) {
			$noautosubmit = " noautosubmit='1' ";
		}
?>
		<select <?php print $autosubmit_warning_yesno; print " "; print $resetdefault; print " "; print $noautosubmit; ?> name="<?php print htmlentities($name); ?>">
<?php
		if($allow_empty) {
?>
				<option value="">&mdash;</option>
<?php
		}
		foreach ($data as $datum) {
			if(is_array($datum)) {
?>
					<option value="<?php print $datum[0]; ?>" <?php print ($chosen && $datum[0] == $chosen) ? 'selected' : ''; ?>><?php print htmlentities($datum[1]); ?></option>
<?php
			} else {
?>
					<option value="<?php print $datum; ?>" <?php print ($chosen && $datum == $chosen) ? 'selected' : ''; ?>><?php print htmlentities($datum); ?></option>
<?php
			}
		}
?>
		</select>
<?php
	}

	/* Datenfunktionen */

	function create_page_info_parent ($parent, $user_role_id_data = null) {
		$page_infos = array();
		$query = 'SELECT `p`.`id`, `p`.`name`, `p`.`file`, `pi`.`info`, `p`.`parent` FROM `page` `p` LEFT JOIN `page_info` `pi` ON `pi`.`page_id` = `p`.`id` WHERE `p`.`show_in_navigation` = "1" AND `parent` = '.esc($parent);
		if(isset($user_role_id_data)) {
			$query .= ' AND `p`.`id` IN (SELECT `page_id` FROM `role_to_page` WHERE `role_id` = '.esc($user_role_id_data).')';
		}
		$query .= ' ORDER BY p.name';
		$result = rquery($query);
		while ($row = mysqli_fetch_row($result)) {
			$page_infos[$row[0]] = array($row[0], $row[1], $row[2], $row[3], $row[4]);
		}
		$result->free();
		return $page_infos;
	}

	function get_father_page ($id) {
		$query = 'SELECT `parent` FROM `page` WHERE `id` = '.esc($id);
		$result = rquery($query);

		if(mysqli_num_rows($result)) {
			$father = null;
			while ($row = mysqli_fetch_row($result)) {
				$father = $row[0];
			}
			$result->free();
			return $father;
		} else {
			return null;
		}
	}

	function create_page_info () {
		$page_infos = array();
		$query = 'select p.id, p.name, p.file, pi.info, p.parent from page p left join page_info pi on pi.page_id = p.id where p.show_in_navigation = "1" ORDER BY p.name';
		$result = rquery($query);
		while ($row = mysqli_fetch_row($result)) {
			$page_infos[$row[0]] = array($row[0], $row[1], $row[2], $row[3], $row[4]);
		}
		$result->free();
		return $page_infos;
	}

	function create_seiten_array () {
		$seiten = array();
		$query = 'SELECT `id`, `name`, `file` FROM `page`';
		$result = rquery($query);
		while ($row = mysqli_fetch_row($result)) {
			$seiten[$row[0]] = array($row[0], $row[1], $row[2]);
		}
		$result->free();
		return $seiten;
	}

	function print_hinweis_for_page ($chosen_page) {
		$hinweis = get_hinweis_for_page($chosen_page);
		if($hinweis) {
			hint("Hinweis: <span class='blue_text'>".htmlentities($hinweis)."</span>");
		}
	}

	function get_hinweis_for_page ($chosen_page) {
		$query = 'SELECT `hinweis` FROM `hinweise` WHERE `page_id` = '.esc($chosen_page);
		$result = rquery($query);
		$hinweis = '';
		while ($row = mysqli_fetch_row($result)) {
			if(strlen($row[0]) && !preg_match('/^\s*$/', $row[0])) {
				$hinweis = $row[0];
			}
		}
		$result->free();
		return $hinweis;
	}

	function get_roles_for_page ($pageid) {
		$rollen = array();
		$query = 'SELECT `role_id` FROM `role_to_page` WHERE `page_id` = '.esc($pageid);
		$result = rquery($query);
		while ($row = mysqli_fetch_row($result)) {
			$rollen[] = $row[0];
		}
		$result->free();
		return $rollen;
	}

	function create_page_parent_array () {
		$rollen = array();
		$query = 'SELECT `id`, `name` FROM `page` WHERE `parent` IS NULL AND `file` IS NULL';
		$result = rquery($query);
		while ($row = mysqli_fetch_row($result)) {
			$rollen[$row[0]] = array($row[0], $row[1]);
		}
		$result->free();
		return $rollen;
	}

	function create_turnus_array () {
		$rollen = array();
		$query = 'SELECT `id`, `name`, `anzahl_monate` FROM `turnus` order by `anzahl_monate` asc';
		$result = rquery($query);
		while ($row = mysqli_fetch_row($result)) {
			$rollen[$row[0]] = array($row[0], $row[1], $row[2]);
		}
		$result->free();
		return $rollen;
	}

	function create_rollen_array () {
		$rollen = array();
		$query = 'SELECT `id`, `name` FROM `role`';
		$result = rquery($query);
		while ($row = mysqli_fetch_row($result)) {
			$rollen[$row[0]] = array($row[0], $row[1]);
		}
		$result->free();
		return $rollen;
	}

	function create_user_array ($role = 0, $specific_role = null) {
		$user = array();
		if($role) {
			$query = 'SELECT `u`.`id`, `u`.`username`, `r`.`role_id` FROM `users` `u` JOIN `role_to_user` `r` ON `r`.`user_id` = `u`.`id`';
			if(isset($specific_role)) {
				$query .= ' WHERE `role_id` = '.esc($specific_role);
			}
			$result = rquery($query);
			while ($row = mysqli_fetch_row($result)) {
				$user[$row[0]] = array($row[0], $row[1], $row[2]);
			}
			$result->free();
			return $user;
		} else {
			$query = 'SELECT `id`, `username` FROM `users`';
			$result = rquery($query);
			while ($row = mysqli_fetch_row($result)) {
				$user[$row[0]] = array($row[0], $row[1]);
			}
			$result->free();
			return $user;
		}
	}

	/* Hilfsfunktionen */

	function global_exists ($name) {
		if(array_key_exists($name, $GLOBALS) && !empty($GLOBALS[$name])) {
			return 1;
		} else {
			return 0;
		}
	}

	function show_output ($name, $color) {
		if(global_exists($name)) {
			print "<div class='square'>\n";
			print "<div class='one'>\n";
			if(file_exists("./i/$name.svg")) {
				print "<img style='min-height: 30px; height: auto; max-height: 60px; top: 0px; bottom: 0px; margin: auto;' src='./i/$name.svg' />\n";
			}
			print "</div>\n";
			print "<div class='two'>\n";
			$this_output = $GLOBALS[$name];
			if(is_array($this_output)) {
				$this_output = array_unique($this_output);
			} else {

				$this_output = array($this_output);
			}
			if($color) {
				if(count($this_output) > 1) {
					print "<ul>\n";
				}
				foreach ($this_output as $this_output_item) {
					if(count($this_output) > 1) {
						print "<li>\n";
					}
					print "<span class='message_text'>".$this_output_item."</span>\n";
					if(count($this_output) > 1) {
						print "</li>\n";
					}
				}
				if(count($this_output) > 1) {
					print "</ul>\n";
				}
			}
			print "</div>\n";
			print "</div>\n";
			print "<div class='clear_both' /><br />\n";
			$GLOBALS[$name] = array();
			print "</div>\n";
		}
	}

	function get_page_id_by_name ($file) {
		if(is_null($file) || !$file) {
			return null;
		}

		$key = "get_page_id_by_name($file)";
		if(array_key_exists($key, $GLOBALS['memoize'])) {
			return $GLOBALS['memoize'][$key];
		}

		$return = null;

		$query = 'SELECT `id` FROM `page` WHERE `name` = '.esc($file);
		$result = rquery($query);

		$return = '';

		while ($row = mysqli_fetch_row($result)) {
			$return = $row[0];
		}
		$result->free();

		$GLOBALS['memoize'][$key] = $return;

		return $return;
	}


	function get_page_id_by_filename ($file) {
		if(is_null($file) || !$file) {
			return null;
		}

		$key = "get_page_id_by_filename($file)";
		if(array_key_exists($key, $GLOBALS['memoize'])) {
			return $GLOBALS['memoize'][$key];
		}

		$return = null;

		// Falls $file = aktuelle Seite, dann einfach &page=... zurückgeben
		if(get_get('page') && get_page_file_by_id(get_get('page')) == $file) {
			$return = get_get('page');
		} else {
			$query = 'SELECT `id` FROM `page` WHERE `file` = '.esc($file);
			$result = rquery($query);

			$return = '';

			while ($row = mysqli_fetch_row($result)) {
				$return = $row[0];
			}
			$result->free();
		}

		$GLOBALS['memoize'][$key] = $return;

		return $return;
	}

	/* Zuordnungsfunktionen */

	function assign_page_to_role ($role_id, $page_id) {
		if(!check_function_rights(__FUNCTION__)) { return; }
		$query = 'INSERT IGNORE INTO `role_to_page` (`role_id`, `page_id`) VALUES ('.esc($role_id).', '.esc($page_id).')';
		$result = rquery($query);
		if($result) {
			success("Die Seite wurde erfolgreich zur Rolle hinzugefügt. ");
			if($GLOBALS['user_role_id'] == $role_id) {
				$GLOBALS['reload_page'] = 1;
			}
		} else {
			error("Die Seite konnte nicht zur Rolle hinzugefügt werden. ");
		}
	}

	/* Systemfunktionen */

	function stderrw ($str) {
		trigger_error($str, E_USER_WARNING);
	}

	function sanitize_data ($data, $recursion = 0) {
		if($recursion == 300) {
			die("ERROR: Deep-Recursion! Bitte melden Sie dies dem Administrator.");
		}

		if(is_array($data)) {
			foreach ($data as $te => $val) {
				$data[$te] = sanitize_data($val, $recursion + 1);
			}

			return $data;
		} else {
			return htmlentities($data);
		}
	}

	function us_date_to_european_date ($date) {
		if(preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $date, $founds)) {
			return $founds[3].'.'.$founds[2].'.'.$founds[1];
		} else {
			return $date;
		}
	}

	function european_data_to_us_date ($date) {
		if(preg_match('/^\d{4}\.\d{2}\.\d{2}$/', $date)) {
			return $date;
		} else {
			if(preg_match('/^(\d{2})\.(\d{2})\.(\d{4})$/', $date, $founds)) {
				$str = $founds[3].'-'.$founds[2].'-'.$founds[1];
				return $str;
			} else if(preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
				return $date;
			}
		}
		warning("Das Datum ".fq($date)." konnte nicht in das MySQL-Datumsformat (YYYY-MM-DD) konvertiert werden. Es wird stattdessen NULL genommen");
		return null;
	}

	function get_anzahl_anlagen_pro_kunde ($kunde_id) {
		if(array_key_exists($kunde_id, $GLOBALS['get_anzahl_anlagen_pro_kunde_cache'])) {
			return $GLOBALS['get_anzahl_anlagen_pro_kunde_cache'][$kunde_id];
		} else {
			$query = "select count(*), kunde_id from anlagen group by kunde_id";
			$result = rquery($query);

			$anzahl = 0;
			while ($row = mysqli_fetch_row($result)) {
				$anzahl = $row[0];
				$this_kunde_id = $row[1];
				$GLOBALS['get_anzahl_anlagen_pro_kunde_cache'][$this_kunde_id] = $anzahl;
			}
			$result->free();

			if(array_key_exists($kunde_id, $GLOBALS['get_anzahl_anlagen_pro_kunde_cache'])) {
				return $GLOBALS['get_anzahl_anlagen_pro_kunde_cache'][$kunde_id];
			} else {
				return 0;
			}
		}
	}

	function get_naechste_wartung ($id, $show_months_as_numbers) {
		if(array_key_exists($id, $GLOBALS['get_naechste_wartung_cache'][$show_months_as_numbers])) {
			return $GLOBALS['get_naechste_wartung_cache'][$show_months_as_numbers][$id];
		} else {
			$ok_id = get_setting("status_ok");
			$query = "select
				anlage_id,
				min(floor(unix_timestamp(concat(jahr, '-', lpad(monat, 2, '0'), '-01 23:00:00')))) as timestamp
				from wartungen
where
enabled = '1' and
status_id != $ok_id and
year(concat(jahr, '-', lpad(monat, 2, '0'), '-01 00:00:00')) > year(curdate()) or (year(curdate()) = year(concat(jahr, '-', lpad(monat, 2, '0'), '-01 00:00:00')) and month(curdate()) <= month(concat(jahr, '-', lpad(monat, 2, '0'), '-01 00:00:00')))
group by anlage_id
order by anlage_id, jahr asc, monat asc";
			$naechste_wartung_result = rquery($query);
			while ($row = mysqli_fetch_assoc($naechste_wartung_result)) {
				$timestamp = $row['timestamp'];
				$monat = date('m', $timestamp);
				$jahr = date('Y', $timestamp);
				if($show_months_as_numbers) {
					$GLOBALS['get_naechste_wartung_cache'][$show_months_as_numbers][$row['anlage_id']] = $monat.'.'.$jahr;
				} else {
					$GLOBALS['get_naechste_wartung_cache'][$show_months_as_numbers][$row['anlage_id']] = monat_zahl_nach_string($monat).' '.$jahr;
				}
			}
			if(array_key_exists($show_months_as_numbers, $GLOBALS['get_naechste_wartung_cache'])) {
				if(array_key_exists($id, $GLOBALS['get_naechste_wartung_cache'][$show_months_as_numbers])) {
					return $GLOBALS['get_naechste_wartung_cache'][$show_months_as_numbers][$id];
				}
			}
			return null;
		}
	}

	function get_anlagen ($kunde_id = null, $only_valid_for_table = 0, $sort_by = null) {
		if(array_key_exists($kunde_id, $GLOBALS['get_anlagen_cache'])) {
			return $GLOBALS['get_anlagen_cache'][$kunde_id];
		} else {
			$query = 'select a.id, a.kunde_id, a.name, ifnull(ifnull(a.plz, k.plz), "") as plz, ifnull(ifnull(a.ort, k.ort), "") as ort from anlagen a left join kunden k on a.kunde_id = k.id where 1 ';
			if(isset($kunde_id)) {
				$query .= ' and kunde_id = '.esc($kunde_id);
			}
			if($only_valid_for_table) {
				$query .= ' and wv_turnus_id is not null';
			}
			if($sort_by) {
				$query .= ' order by '.$sort_by.' asc';
			}
			$result = rquery($query);

			$data = array();

			while ($row = mysqli_fetch_row($result)) {
				$this_data = array();
				$this_data['id'] = $row[0];
				$this_data['kunde_id'] = $row[1];
				$this_data['name'] = $row[2];
				$data[] = $this_data;
			}
			$result->free();

			if(!is_null($kunde_id)) {
				$GLOBALS['get_anlagen_cache'][$kunde_id] = $data;
			}
			return $data;
		}
	}

	function get_anlagen_data ($id) {
		if(array_key_exists($id, $GLOBALS['get_anlagen_data_cache'])) {
			return $GLOBALS['get_anlagen_data_cache'][$id];
		} else {
			$query = 'select id, kunde_id, name from anlagen';
			$result = rquery($query);

			$data = array();

			while ($row = mysqli_fetch_row($result)) {
				$this_data = array();
				$this_data['id'] = $row[0];
				$this_data['kunde_id'] = $row[1];
				$this_data['name'] = $row[2];
				$data = $this_data;
				$GLOBALS['get_anlagen_data_cache'][$this_data['id']] = $data;
			}
			$result->free();

			return $GLOBALS['get_anlagen_data_cache'][$id];
		}
	}

	function add_to_output ($name, $msg) {
		if($name) {
			if($msg) {
				$GLOBALS[$name][] = $msg;
			}
		} else {
			die(htmlentities($name)." existiert nicht!");
		}
	}

	function mysql_error ($message) {
		add_to_output("mysql_error", $message);
	}

	function error ($message) {
		add_to_output("error", $message);
		return 0;
	}

	function hint ($message) {
		add_to_output("hint", $message);
		show_output("hint", $message);
	}

	function success ($message) {
		add_to_output("success", $message);
		return 1;
	}

	function trash ($message) {
		add_to_output("trash", $message);
	}

	function mysql_warning ($message) {
		add_to_output("mysql_warning", $message);
	}

	function warning ($message) {
		add_to_output("warning", $message);
		return 1;
	}

	function debug ($message) {
		add_to_output("debug", $message);
	}

	function right_issue ($message) {
		add_to_output("right_issue", $message);
	}

	function message ($message) {
		add_to_output("message", $message);
		return 1;
	}

	function get_erinnerung_pruefung_and_pruefung_ortsfester_anlagen ($kunde_id) {
		if(!array_key_exists($kunde_id, $GLOBALS['get_erinnerung_pruefung_and_pruefung_ortsfester_anlagen_cache'])) {
			$query = 'select id, erinnerung, pruefung, pruefung_abgelehnt from kunden';
			$result = rquery($query);

			while ($row = mysqli_fetch_row($result)) {
				$t_id = $row[0];
				$GLOBALS['get_erinnerung_pruefung_and_pruefung_ortsfester_anlagen_cache'][$t_id] = array($row[1], $row[2], $row[3]);
			}
			$result->free();
		}

		$data = array(0, 0, 0);
		if($GLOBALS['get_erinnerung_pruefung_and_pruefung_ortsfester_anlagen_cache'][$kunde_id]) {
			$data = $GLOBALS['get_erinnerung_pruefung_and_pruefung_ortsfester_anlagen_cache'][$kunde_id];
		}

		return return_checked_or_not($data);
	}

	function return_checked_or_not ($value) {
		if(is_array($value)) {
			$data = array();
			foreach ($value as $this_value) {
				$data[] = return_checked_or_not($this_value);
			}
			return $data;
		} else {
			if($value) {
				return '&#9989;';
			} else {
				return '&#10060;';
			}
		}
	}

	function get_kunde_folder_icon ($kunde) {
		if(get_setting("show_folder_icon")) {
			$base_folder = get_setting("base_folder");
			if(!array_key_exists('ort', $kunde) || !array_key_exists('kunde', $kunde)) {
				return '';
			} else {
				$folder_string = $base_folder.urlencode($kunde['ort'].' - '.$kunde['kunde']);
				$link = '<a href="'.$folder_string.'"><img alt="Kundenordner öffnen" src="i/folder.svg" width="'.get_setting("icon_size").'"/></a>';
				return $link;
			}
		}
		return '';
	}

	function replace_newlines_htmlentities ($str) {
		$str = preg_replace("/[\n\r]/", "<br>", $str);

		return htmlentities($str);
	}

	function nbsp_every_n ($name, $n) {
		$str = wordwrap($name, $n, "NBSPNBSPNBSPNBSPNBSP", true);
		$str = preg_replace("/NBSPNBSPNBSPNBSPNBSP/", '&nbsp;', $str); 
		return $str;
	}

	function shy_every_n ($name, $n) {
		$str = wordwrap($name, $n, "SHYSHYSHYSHYSHY", true);
		$str = preg_replace("/SHYSHYSHYSHYSHY/", '&shy;', $str); 
		return $str;
	}

	function prepare_print_anlage_name ($name) {
		$str = htmlentities(wordwrap($name, get_setting('shy_inserter'), "SHYSHYSHYSHYSHY", true));
		$str = preg_replace("/SHYSHYSHYSHYSHY/", '&shy;', $str); 
		return $str;
	}

	function get_termin_color ($id) {
		if(!array_key_exists($id, $GLOBALS['status_color_cache'])) {
			$query = 'select color from status where id = '.esc($id);
			$GLOBALS['status_color_cache'][$id] = get_single_value_from_query($query);
		}
		return $GLOBALS['status_color_cache'][$id];
	}

	function create_string_for_wartungstabelle_td ($this_year, $this_month, $anlage_id, $this_termine, $status_array, $revealed) {
		$this_str = '';
		$i = 0;
		foreach ($this_termine[$anlage_id] as $this_termin) {
			if($this_str) {
				$this_str .= "<hr>";
			}

			$this_str .= '<div style="background-color: #'.get_termin_color($this_termin['status_id']).';">';
			$style_string = '';

			if($revealed) {
				$style_string .= 'display: block !important; ';
			}

			$str_actions = 'style="'.$style_string.'min-width: 99%" onfocusout="reset_comment_box_size(this)" onclick="resize_comment_box(this)" onkeyup="resize_comment_box(this)"';
			$this_anlage = get_anlagen_data($anlage_id);
			$id_name = $anlage_id.'_'.$this_year.'_'.$this_month;
			$comment_name = $this_termin['id'];

			$anlage_id = $this_anlage['id'];

			$kommentar = '';

			if(array_key_exists($anlage_id, $this_termin)) {
				$this_termin = $this_termin[$anlage_id];
			}

			if(isset($this_termin['comment'])) {
				$kommentar = $this_termin['comment'];
			}

			$kommentar2 = '';
			if(isset($this_termin['comment2'])) {
				$kommentar2 = $this_termin['comment2'];
			}

			$draggable_icon = '';

			if(get_setting("show_double_left_right_icons")) {
				$draggable_icon .= "<img style='cursor: w-resize;' class='moveleftrighthandle' src='data/double_left.svg' data-anlageid='".$anlage_id."' data-terminid='".$this_termin['id']."' data-monatdiff='-2' alt='Verschiebe zwei Monate nach links' width='".get_setting("icon_size")."' />&nbsp;\n";
			}

			if(get_setting("show_left_right_icons")) {
				$draggable_icon .= "<img style='cursor: w-resize;' class='moveleftrighthandle' src='data/left.svg' data-anlageid='".$anlage_id."' data-terminid='".$this_termin['id']."' data-monatdiff='-1' alt='Verschiebe einen Monat nach links' width='".get_setting("icon_size")."' />&nbsp;\n";
			}

			if(get_setting("enable_droppable") && get_setting("show_draggable_icon")) {
				$draggable_icon .= "<img src='data/drag.svg' alt='Handler zum Ziehen' width='".get_setting("icon_size")."' />&nbsp;\n";
			}

			if(get_setting("show_left_right_icons")) {
				$draggable_icon .= "<img style='cursor: e-resize;' class='moveleftrighthandle' src='data/right.svg' data-anlageid='".$anlage_id."' data-terminid='".$this_termin['id']."' data-monatdiff='1' alt='Verschiebe einen Monat nach rechts' width='".get_setting("icon_size")."' />&nbsp;\n";
			}

			if(get_setting("show_double_left_right_icons")) {
				$draggable_icon .= "<img style='cursor: e-resize;' class='moveleftrighthandle' src='data/double_right.svg' data-anlageid='".$anlage_id."' data-terminid='".$this_termin['id']."' data-monatdiff='2' alt='Verschiebe zwei Monate nach rechts' width='".get_setting("icon_size")."' />&nbsp;\n";
			}

			if($draggable_icon) {
				$draggable_icon .= '<br>';
			}

			$move_data = ' data-terminid="'.$this_termin['id'].'" data-jahr="'.$this_year.'" data-monat="'.$this_month.'"';

			$this_str .= $draggable_icon.'<h3 style="margin: 0px;"><span data-anlageid="'.$anlage_id.'" class="reveal" onclick="reveal_data(this)"><img style="cursor: pointer;" src="data/comments.svg" width="'.get_setting("icon_size").'" alt="Menü aufklappen" />&nbsp;</span>'.prepare_print_anlage_name($this_anlage['name']).'</h3>'."\n";
			$this_str .= create_select_str($status_array, $this_termin['status_id'], 'termin_'.$comment_name, 0, 'selectboxstatus', array("anlageid" => $anlage_id), "update_data(this)", get_setting("min_width_column"))."\n";

			$style = "";
			$data = ' data-anlageid='.json_encode($anlage_id).' ';

			$this_str .= '<textarea '.$data.' onchange="update_data(this)" class="commentbox" '.$str_actions.' name="kommentar_'.$comment_name.'" id="kommentar_'.$id_name.'" placeholder="Kommentar">'.htmlentities($kommentar).'</textarea>'."\n";
			$this_str .= '<textarea '.$data.' onchange="update_data(this)" class="commentbox" '.$str_actions.' name="kommentar2_'.$comment_name.'" id="kommentar2_'.$id_name.'" placeholder="Kommentar 2">'.htmlentities($kommentar2).'</textarea>'."\n";

			$target = " target='_blank' ";
			if(!get_setting("open_stuff_in_blank_page") || get_setting("x11_debugging_mode")) {
				$target = '';
			}

			if(get_setting("enable_ersatzteile")) {
				$ersatzteillink = "admin.php?page=".get_page_id_by_filename("ersatzteilewartung.php");
				$this_str .= "<br><a $target href='".$ersatzteillink."&terminid=".$this_termin['id']."'>&euro;/&#8986;/Ersatzteil</a>, ".sum_of_ersatzteile_prices($this_termin['id'], get_setting("full_price_in_wartungstabelle"))."&euro;";
			}

			if(get_setting("enable_delete")) {
				$this_str .= "<span class='commentbox' onclick='disable_termin(".$this_termin['id'].", ".$anlage_id.")'>".
					"<img alt='Diesen Termin löschen' width=20 style='cursor: pointer;' src='i/remove.svg' />".
					"</span>\n";
			}

			if(get_setting("show_print")) {
				$this_str .= '<a '.$target.' href="print_termin.php?terminid='.$this_termin['id'].'"><img width="'.get_setting('icon_size').'" alt="Datenblatt drucken" src="i/print.svg" /></a>';
			}

			$this_str .= '</div>';
		}

		return array($this_str, $move_data);
	}

	function str_array_to_str_wartungstabelle ($str_array) {
		$str = '';
		foreach ($str_array as $this_str_data) {
			$color = $this_str_data['color'];
			$color_str = "";
			if($color) {
				$color_str = "background-color: #".$color.'; ';
			}
			$metadata = $this_str_data["metadata"];
			$this_str_line = $this_str_data['data'];
			$this_class = "box_around_termin collapsable";
			if(get_setting("enable_droppable")) {
				$this_class = "draggable $this_class";
			}
			$this_str_line = "<div $metadata class='$this_class' style='".$color_str."'>$this_str_line</div>";
			$str = $this_str_line;
		}
		return $str;
	}

	function get_addressdaten ($id) {
		if(!array_key_exists($id, $GLOBALS['get_addressdaten_cache'])) {
			$query = 'select anlage_id, kunde_id, plz, ort, strasse, hausnummern from view_anlage_kunde_addressdaten';
			$result = rquery($query);

			while ($row = mysqli_fetch_assoc($result)) {
				$this_id = $row['anlage_id'];
				$GLOBALS['get_addressdaten_cache'][$this_id] = $row;
			}
		}
		return $GLOBALS['get_addressdaten_cache'][$id];
	}

	function get_get_e($name) {
		return htmlentities(get_get($name));
	}

	function add_wartungstabelle_header_str ($this_year, $last_year, $this_month) {
		$yearstr = '';
		if($this_year != $last_year) {
			$yearstr = "$this_year: ";
			$last_year = $this_year;
		}
		$linkparam = "jahreplus=".get_get_e("jahreplus")."&show_status_id=".get_get_e("show_status_id")."&show_kunde_id=".get_get_e("show_kunde_id")."&show_anlage_id=".get_get_e("show_anlage_id")."&plzbeginswith=".get_get_e("plzbeginswith")."&search=".get_get_e("search");
		$headerstr = "<a class='no_decoration' href='admin.php?page=".get_page_id_by_filename("wartungstermine2.php")."&jahrstart=".$this_year."&monatauswahl=".$this_month."&".$linkparam."'>$yearstr$this_month</a>";
		if($this_year == date('Y') && $this_month == date('m')) {
			$headerstr = array("color" => "1", "str" => $headerstr);
		}

		return $headerstr;
	}

	function get_material_wartung ($anlage_id) {
		$query = 'select id, material_wartung from anlagen';
		return get_cached_result($anlage_id, $query, 'get_material_wartung_cache');
	}

	function wartungstabelle_str_array ($this_year, $this_month, $this_termin, $status_array, $anlage_id, $revealed = 0) {
		if(!$this_termin) {
			return array();
		}

		$str_array = array();
		$this_data = create_string_for_wartungstabelle_td($this_year, $this_month, $anlage_id, $this_termin, $status_array, $revealed);

		$this_str = $this_data[0];
		$data = $this_data[1];

		$str_array[] = array("color" => '', "data" => $this_str, "metadata" => $data, "anlage_id" => $anlage_id);

		return $str_array;
	}

	function default_headers_wartungstabelle () {
		$header = array();

		$headers_by_config_name_original = array(
			'plzort' => "Plz+Ort",
			'kunde' => "Kunde",
			'turnus' => "Turnus",
			'erinnerungprfg' => 'Eri. Prfg.',
			'prfganlagen' => 'Prfg. o.f. Anl.',
			'prfgabgelehnt' => 'Prfg. ab&shy;ge&shy;lehnt',
			'letztewartung' => 'Letzte War&shy;tung',
			'naechstewartung' => 'Nächste War&shy;tung'
		);

		$headers_by_config_name = $headers_by_config_name_original;
		$headerorder = get_setting("headerorder");

		if(!$headerorder) {
			dier("Die Einstellung 'headerorder' wurde nicht gefunden.");
		}

		foreach (explode(",", $headerorder) as $header_name) {
			if(array_key_exists($header_name, $headers_by_config_name)) {
				$header[] = $headers_by_config_name[$header_name];
				unset($headers_by_config_name[$header_name]);
			} else {
				dier("Unbekannter Header-Wert $header_name. Bitte entferne diesen Wert. Valide Werte sind:\n".join(",", array_keys($headers_by_config_name_original)));
			}
		}

		$header = array_merge($header, $headers_by_config_name);

		if(get_setting("show_anzahl_anlagen")) {
			$header[] = 'Anz. Anl.';
		}

		if(get_setting("show_zeit_pro_wartung_or_min_max_avg_wartungszeit")) {
			if(get_setting("show_min_max_avg_wartungszeit")) {
				$header[] = 'Min/max/avg gebrauchte Wartungszeit';
			} else {
				$header[] = 'h pro Wartung';
			}
		}

		if(get_setting("show_phone_number")) {
			$header[] = 'Te&shy;le&shy;fon';
		}

		if(get_setting("show_ansprechpartner")) {
			$header[] = 'An&shy;sprech&shy;partner';
		}

		if(get_setting("show_h_pro_wartung")) {
			$header[] = 'h pro War&shy;tung';
		}

		if(get_setting("show_plz")) {
			$header[] = 'An&shy;lage Plz';
		}

		if(get_setting("show_ort")) {
			$header[] = 'An&shy;lage Ort';
		}

		if(get_setting("show_strasse")) {
			$header[] = 'An&shy;lage Stras&shy;se';
		}

		if(get_setting("show_hausnummer")) {
			$header[] = 'An&shy;lage Haus&shy;num&shy;mer';
		}

		if(get_setting("show_anlage_comment")) {
			$header[] = 'Anl. Komm.';
		}

		if(get_setting("show_material_wartung")) {
			$header[] = 'Material/Wartung';
		}

		return $header;
	}

	function add_row_to_wartungstabelle ($row, $this_year, $this_month, $line, $status_array, $anlage_id, $revealed = 0) {
		$has_data = 0;
		if(array_key_exists($this_year, $line['data']) && array_key_exists($this_month, $line['data'][$this_year])) {
			$this_termine = $line['data'][$this_year][$this_month];
			$str_array = wartungstabelle_str_array($this_year, $this_month, $this_termine, $status_array, $anlage_id, $revealed);
			$id = $line['data'][$this_year][$this_month][$anlage_id][0]["id"]; // TODO statt 0 alle irgendwie beachten

			$has_data = 1;

			$row[] = array(
				'color' => '',
				'string' => str_array_to_str_wartungstabelle($str_array),
				"this_year" => $this_year,
				"this_month" => $this_month,
				"id" => $id
			);
		} else {
			$row[] = array(
				'color' => '',
				'string' => '',
				'this_year' => $this_year,
				'this_month' => $this_month,
				"id" => null 
			);
		}

		$return = array("has_data" => $has_data, "row" => $row);
		return $return;
	}

	function get_last_termin_by_anlage_id ($anlage_id) {
		$query = 'select concat(jahr, "-", lpad(monat, 2, "0"), "-01") as date from wartungen where anlage_id = '.esc($anlage_id).' order by jahr desc, monat desc limit 1;';
		$date_value = get_single_value_from_query($query);
		$date = new Datetime($date_value);
		return $date;
	}

	function add_wartungstermine ($max_jahr, $anlage_id = null) {
		start_transaction();
		$kunden = get_kunden_array(null, $anlage_id);
		$data = array();

		$failed = 0;

		$sql_values = array();

		foreach ($kunden as $this_kunde) {
			$anlagen = get_anlagen($this_kunde['id']);
			foreach ($anlagen as $this_anlage) {
				$this_anlage_id = $this_anlage['id'];
				$this_turnus = get_turnus($this_anlage_id);
				if(!is_null($this_turnus)) {
					if(array_key_exists('anzahl_monate', $this_turnus)) {
						$this_turnus = $this_turnus['anzahl_monate'];
						$last_termin = get_last_termin_by_anlage_id($this_anlage_id);
						while ($last_termin->format('Y') <= $max_jahr) {
							$next_termin = $last_termin->modify("+$this_turnus month");
							$next_year = $next_termin->format('Y');
							$next_month = $next_termin->format('m');
							$values = array(
								$next_month,
								$next_year,
								get_setting('status_default'),
								1,
								'',
								'',
								$this_anlage_id
							);
							$sql_values[] = "(".multiple_esc_join($values).')';
							$last_termin = $next_termin; #get_last_termin_by_anlage_id($this_anlage_id);
						}
					}
				} else {
					dier("Turnus ist kaputt");
				}
			}
		}

		if(count($sql_values)) {
			$query = 'INSERT INTO wartungen (monat, jahr, status_id, enabled, comment, comment2, anlage_id) VALUES '.join(', ', $sql_values);
			$query .= ' ON DUPLICATE KEY UPDATE enabled = if(inserted_manually = "0", "1", enabled)';
			if(!rquery($query)) {
				$failed = 1;
			}
		}

		if($failed) {
			dier("Es gab einen Fehler bei der Erstellung der Wartungstermine 1. Die Aktion wurde daher rückgängig gemacht.");
			rollback();
		} else {
			commit();
		}

		return $data;
	}

	function prepare_wartungstermine_group_by_kunde ($jahrstart, $jahreplus, $jahrauswahl, $monatauswahl, $show_status_id, $show_anlage_id = null, $from_last_entry = 1, $last_termin_id = null, $show_kunde_id = null, $plzbeginswith = null, $first_wartung_status = null) {
		start_transaction();
		$kunden = get_kunden_array();
		$data = array();

		$failed = 0;
		foreach ($kunden as $this_kunde) {
			if(($show_kunde_id && $show_kunde_id == $this_kunde['id']) || !$show_kunde_id) {
				$anlagen = get_anlagen($this_kunde['id'], 1, 'plz');

				foreach ($anlagen as $this_anlage) {
					$this_anlage_id = $this_anlage['id'];

					if(($show_anlage_id && $show_anlage_id == $this_anlage_id) || !$show_anlage_id) {
						$this_data_and_failure = get_or_create_wartungstermine($this_anlage_id, $jahrstart, $jahreplus, $jahrauswahl, $monatauswahl, $this_kunde['id'], $show_status_id, $from_last_entry, $last_termin_id, $first_wartung_status, $plzbeginswith);

						if(!$failed) {
							$failed = $this_data_and_failure[0];
						}

						if(!$failed) {
							$this_data = $this_data_and_failure[1];

							if(!is_null($this_data) && count($this_data)) {
								$this_anlage_comment = get_anlage_comment($this_anlage_id);
								$h_pro_wartung = null;
								if(get_setting("show_h_pro_wartung")) {
									$h_pro_wartung = get_h_pro_wartung($this_anlage_id);
								}
								$data[] = array(
									'kunde' => $this_kunde,
									'anlage_id' => $this_anlage_id,
									'data' => $this_data,
									'anlage_comment' => $this_anlage_comment,
									'h_pro_wartung' => $h_pro_wartung
								);
							}
						}
					}
				}
			}
		}

		if($failed) {
			dier("Es gab einen Fehler bei der Erstellung der Wartungstermine 2. Die Aktion wurde daher rückgängig gemacht.");
			rollback();
		} else {
			commit();
		}

		return $data;
	}

	function prepare_wartungstermine ($jahrstart, $jahreplus, $jahrauswahl, $monatauswahl, $show_status_id, $show_anlage_id = null, $from_last_entry = 1, $last_termin_id = null, $show_kunde_id = null, $plzbeginswith = null, $first_wartung_status = null) {
		start_transaction();
		$data = array();

		$failed = 0;

		// function get_anlagen ($kunde_id = null, $only_valid_for_table = 0, $sort_by = null) {
		$anlagen = get_anlagen(null, 1, 'ort');

		foreach ($anlagen as $this_anlage) {
			$this_kunde = get_kunden_array(null, $this_anlage['id'])[0];

			if(($show_kunde_id && $show_kunde_id == $this_kunde['id']) || !$show_kunde_id) {
				$this_anlage_id = $this_anlage['id'];

				if(($show_anlage_id && $show_anlage_id == $this_anlage_id) || !$show_anlage_id) {
					$this_data_and_failure = get_or_create_wartungstermine($this_anlage_id, $jahrstart, $jahreplus, $jahrauswahl, $monatauswahl, $this_kunde['id'], $show_status_id, $from_last_entry, $last_termin_id, $first_wartung_status, $plzbeginswith);

					if(!$failed) {
						$failed = $this_data_and_failure[0];
					}

					if(!$failed) {
						$this_data = $this_data_and_failure[1];

						if(!is_null($this_data) && count($this_data)) {
							$this_anlage_comment = get_anlage_comment($this_anlage_id);
							$h_pro_wartung = null;
							if(get_setting("show_h_pro_wartung")) {
								$h_pro_wartung = get_h_pro_wartung($this_anlage_id);
							}
							$data[] = array(
								'kunde' => $this_kunde,
								'anlage_id' => $this_anlage_id,
								'data' => $this_data,
								'anlage_comment' => $this_anlage_comment,
								'h_pro_wartung' => $h_pro_wartung
							);
						}
					}
				}
			}
		}

		if($failed) {
			dier("Es gab einen Fehler bei der Erstellung der Wartungstermine 3. Die Aktion wurde daher rückgängig gemacht.");
			rollback();
		} else {
			commit();
		}

		return $data;
	}

	function get_cached_result ($id, $query, $cache_name, $full_row = 0, $remove_first_element = 0, $default = null) {
		# BEDINGUNG: $row[0] muss die ID sein!!!
		if(!array_key_exists($id, $GLOBALS[$cache_name])) {
			$result = rquery($query);

			while ($row = mysqli_fetch_row($result)) {
				$t_id = $row[0];

				if($remove_first_element) {
					unset($row[0]);
					\array_splice($row, 1, 0);
				}

				if($full_row) {
					$GLOBALS[$cache_name][$t_id] = $row;
				} else {
					$GLOBALS[$cache_name][$t_id] = $row[1 - $remove_first_element];
				}
			}
		}
		if(array_key_exists($id, $GLOBALS[$cache_name])) {
			return $GLOBALS[$cache_name][$id];
		} else {
			return $default;
		}
	}

	function get_anlage_comment_and_ansprechpartner_id_zeit_pro_wartung ($id) {
		$query = 'select id, this_anlage_comment, ansprechpartner_id, zeit_pro_wartung, plz, ort, strasse, hausnummer, land from anlagen';
		return get_cached_result($id, $query, 'get_anlage_comment_and_ansprechpartner_id_zeit_pro_wartung_cache', 1, 1);
	}

	function get_h_pro_wartung ($id) {
		return get_cached_result($id, 'select id, zeit_pro_wartung from anlagen', 'get_h_pro_wartung_cache');
	}

	function get_anlage_comment ($id) {
		return get_cached_result($id, 'select id, this_anlage_comment from anlagen', 'get_anlage_comment_cache');
	}

	function space_to_linebreak ($str) {
		$str = str_replace('/ /g', '<br>', $str);
		return $str;
	}

	function commentbox ($str) {
		return "<span style='background-color: ".get_setting("anlage_commentbox_color").";'>$str</span>\n";
	}

	function get_kunde_link_name_by_id ($id) {
		$name = get_kunde_name_by_id($id);
		return "<a href='admin.php?page=".get_page_id_by_filename("kunden.php")."&show_kunde=".htmlentities($id)."'>".fq($name)."</a>";
	}

	function get_anlagen_link_name_by_id ($id) {
		$name = get_anlage_name_by_id($id);
		return "<a href='admin.php?page=".get_page_id_by_filename("anlagen.php")."&show_only_this_anlage=".htmlentities($id)."'>".fq($name)."</a>";
	}

	function get_anlagen_name_by_id ($id) {
		$query = 'select id, name from anlagen';
		return get_cached_result($id, $query, "get_anlagen_name_by_id_cache");
	}

	function get_anlagen_name_by_termin_id ($id) {
		$anlage_id = get_anlage_id_by_termin_id($id);
		return get_anlagen_name_by_id($anlage_id);
	}

	function get_jahr_from_termin ($id) {
		$query = 'select jahr from wartungen where id = '.esc($id);

		$name = null;

		$res = rquery($query);

		while ($row = mysqli_fetch_row($res)) {
			$name = $row[0];
		}
		$res->free();

		return $name;
	}

	function get_monat_from_termin ($id) {
		$query = 'select monat from wartungen where id = '.esc($id);

		$name = null;

		$res = rquery($query);

		while ($row = mysqli_fetch_row($res)) {
			$name = $row[0];
		}
		$res->free();

		return $name;
	}

	function get_year_month_from_termin_id ($id) {
		if(!array_key_exists($id, $GLOBALS['get_year_month_from_termin_id_cache'])) {
			$year = NULL;
			$month = NULL;

			$query = 'select jahr, monat from wartungen where id = '.esc($id);
			$res = rquery($query);

			while ($row = mysqli_fetch_row($res)) {
				$year = $row[0];
				$month = $row[1];
			}
			$res->free();
			$GLOBALS['get_year_month_from_termin_id_cache'][$id] = array('year' => $year, 'month' => $month);
		}
		return $GLOBALS['get_year_month_from_termin_id_cache'][$id];
	}

	function verschiebe_spaetere_termine($id, $old_monat, $old_jahr, $new_monat, $new_jahr) {
		$old_date = new Datetime("$old_jahr-$old_monat-15");
		$new_date = new Datetime("$new_jahr-$new_monat-15");

		$diff = $old_date->diff($new_date);

		$monat_diff = 0;
		if($new_date >= $old_date) {
			$monat_diff = (($diff->format('%y') * 12) + $diff->format('%m'));
		} else {
			$monat_diff = -(($diff->format('%y') * 12) + $diff->format('%m'));
		}

		if($monat_diff != 0) {
			$get_affected_termine_query = "SELECT `id` FROM `wartungen` WHERE `anlage_id` = ".esc(get_anlage_id_by_termin_id($id))." and ((jahr >= ".esc($old_jahr)." AND `monat` > ".esc($old_monat).") OR `jahr` > ".esc($old_jahr)." ) AND `id` != ".esc($id);
			$get_affected_termine_result = rquery($get_affected_termine_query);
			$affected_termine = array();
			start_transaction();
			while ($row = mysqli_fetch_row($get_affected_termine_result)) {
				$affected_termine[$row[0]] = array(
					'original_date_data' => get_year_month_from_termin_id($row[0])
				);
			}

			$res = 1;

			foreach ($affected_termine as $termin_id => $data) {
				$ok_year = $data['original_date_data']['year'];
				$ok_month = $data['original_date_data']['month'];

				$date = new DateTime("$ok_year-$ok_month-01");
				if($monat_diff > 0) {
					$date->modify("+$monat_diff month");
				} else {
					$date->modify("$monat_diff month");
				}

				$ok_year = $date->format('Y');
				$ok_month = $date->format('m');
				$update_query = 'UPDATE `wartungen` SET `jahr` = '.esc($ok_year).', `monat` = '.esc($ok_month).' WHERE `id` = '.esc($termin_id);
				if($res == 0 || !rquery($update_query)) {
					$res = 0;
				}
			}

			if($res) {
				success("Nachfolgende Termine wurden entsprechend um $monat_diff Monat(e) verschoben");
				print("<!-- forcereload -->");
				commit();
			} else {
				error("Nachfolende Termine konnten nicht verschoben werden");
				rollback();
			}
		}
	}

	function verschiebe_termin_um_monat ($id, $monat_diff, $verschiebe_spaetere) {
		$old_monat = get_monat_from_termin($id);
		$old_jahr = get_jahr_from_termin($id);

		$new_monat = new Datetime("$old_jahr-$old_monat-15");
		$new_monat->modify("+$monat_diff month");
		$new_monat = $new_monat->format('m');
		$new_monat = ltrim($new_monat, "0");

		$new_jahr = new Datetime("$old_jahr-$old_monat-15");
		$new_jahr->modify("+$monat_diff month");
		$new_jahr = $new_jahr->format('Y');

		$query = 'UPDATE wartungen SET inserted_manually = "1", monat = '.esc($new_monat).', jahr = '.esc($new_jahr).' WHERE id = '.esc($id);
		$result = rquery($query);

		if($result) {
			success("Terminverschiebung um Monate hat geklappt (&raquo;<i>".get_anlagen_name_by_termin_id($id)."</i>&laquo; nach $new_monat.$new_jahr)");
			if($verschiebe_spaetere) {
				verschiebe_spaetere_termine($id, $old_monat, $old_jahr, $new_monat, $new_jahr);
			}
		} else {
			error("Irgendwas ist beim Verschieben schiefgelaufen");
		}
	}


	function verschiebe_termin ($id, $new_jahr, $new_monat, $verschiebe_spaetere) {
		$old_monat = get_monat_from_termin($id);
		$old_jahr = get_jahr_from_termin($id);

		$query = 'UPDATE wartungen SET inserted_manually = "1", monat = '.esc($new_monat).', jahr = '.esc($new_jahr).' WHERE id = '.esc($id);
		$result = rquery($query);

		if($result) {
			success("Terminverschiebung hat geklappt (&raquo;<i>".get_anlagen_name_by_termin_id($id)."</i>&laquo; nach $new_monat.$new_jahr)");
			if($verschiebe_spaetere) {
				verschiebe_spaetere_termine($id, $old_monat, $old_jahr, $new_monat, $new_jahr);
			}
		} else {
			error("Irgendwas ist beim Verschieben schiefgelaufen");
		}
	}

	function get_kunde_id_by_anlage_id ($anlage_id) {
		$query = 'select kunde_id from anlagen where id = '.esc($anlage_id);

		$id = null;

		$res = rquery($query);

		while ($row = mysqli_fetch_row($res)) {
			$id = $row[0];
		}
		$res->free();

		return $id;
	}

	function disable_termin ($termin_id) {
		$query = 'delete from wartungen where id = '.esc($termin_id);
		$res = rquery($query);

		if($res) {
			success("Löschen des Termins hat geklappt");
		} else {
			error("Löschen des Termins hat NICHT geklappt");
		}
	}

	function insert_wartungstermin ($anlage_id, $monat, $year) {
		# | kunden_id | monat | jahr | status_id | enabled | comment | comment2 | anlage_id | id |

		$query = "insert into wartungen (monat, jahr, status_id, enabled, anlage_id, inserted_manually) values (".multiple_esc_join(array($monat, $year, get_setting("status_default"), "1", $anlage_id, "1")).") on duplicate key update enabled=values(enabled), jahr=values(jahr), monat=values(monat), inserted_manually='1'";
		$res = rquery($query);

		if($res) {
			success("Eintragen des neuen Termins ($year:$monat) hat geklappt");
		} else {
			error("Eintragen des neuen Termins ($year:$monat) hat NICHT geklappt");
		}
	}

	function get_single_row_from_query ($query) {
		$id = array();

		$res = rquery($query);

		while ($row = mysqli_fetch_row($res)) {
			$id = $row;
		}
		$res->free();

		return $id;
	}


	function get_single_value_from_query ($query) {
		$id = null;

		$res = rquery($query);

		while ($row = mysqli_fetch_row($res)) {
			$id = $row[0];
		}
		$res->free();

		return $id;
	}

	function get_local_version () {
		$this_local_version = file_get_contents("version");
		$this_local_version = rtrim($this_local_version, "\n");
		return $this_local_version;
	}

	function has_updateable_version () {
		if($GLOBALS['logged_in']) {
			$this_local_version = file_get_contents("version");
			$this_local_version = rtrim($this_local_version, "\n");
			if(table_exists('version')) {
				$this_db_version = get_single_value_from_query('select git from version order by id desc limit 1');

				if($this_db_version == $this_local_version) {
					return 0;
				} else {
					$update_file = "version_updates/$this_local_version.sql";
					if(file_exists($update_file)) {
						return 1;
					} else {
						return 0;
					}
				}
			} else {
				return 1;
			}
		}
	}

	function get_single_tr ($jahrstart, $jahreplus, $jahrauswahl, $monatauswahl, $show_status_id, $this_anlage_id, $add_tr = 1, $add_form = 1, $add_hidden = 1, $revealed = 0) {
		$data = prepare_wartungstermine($jahrstart, $jahreplus, $jahrauswahl, $monatauswahl, $show_status_id, $this_anlage_id, 1);
		$table = array();

		$table_and_header = create_wartungstabelle_table_from_data($data, $jahrstart, $jahreplus, $monatauswahl, $jahrauswahl, $this_anlage_id, $revealed);
		$table = $table_and_header["table"];

		$this_tr = array();
		$tr_with_form = '';
		foreach ($table as $this_row) {
			$this_row_data = $this_row['data'];
			$anlage_id = $this_row['anlage_id'];
			if($anlage_id == $this_anlage_id) {
				$this_tr = get_tr_wartungstabelle($this_row_data, $anlage_id, $add_tr, $add_form);
				$tr_with_form = create_tr_form($anlage_id, $this_tr, $add_form, $add_tr, $add_hidden);
			}
		}


		return $tr_with_form;
	}

	function is_valid_anlage ($anlage_id) {
		$query = "select letzte_wartung, ibn_beendet, ende_gewaehrleistung from anlagen where id = ".esc($anlage_id);
		$row = get_single_row_from_query($query);

		$ret = 1;

		if (is_null($row[0]) && is_null($row[1]) && is_null($row[2])) {
			$name = get_anlagen_name_by_id($anlage_id);
			if(is_null($row[0])) {
				error("Die Anlage ".$name." hat keine letzte Wartung.");
				$ret = 0;
			}

			if(is_null($row[1])) {
				error("Die Anlage ".$name." hat keine IBN beendet.");
				$ret = 0;
			}

			if(is_null($row[2])) {
				error("Die Anlage ".$name." hat kein Ende Gewährleistung.");
				$ret = 0;
			}
		}

		return $ret;
	}

	function is_after_ende_gewaehrleistung ($anlage_id, $this_year, $this_monat) {
		$ende_gewaehrleistung = get_ende_gewaehrleistung($anlage_id);
		$eg_jahr = $ende_gewaehrleistung['jahr'];
		$eg_monat = $ende_gewaehrleistung['monat'];

		if("$eg_jahr" == '' || "$eg_monat" == '') {
			return 0;
		}

		$this_date = new DateTime("$this_year-$this_monat-01");
		$ende_gewaehrleistung_date = new Datetime("$eg_jahr-$eg_monat-01");

		if($this_date > $ende_gewaehrleistung_date) {
			return 1;
		}

		return 0;
	}

	function get_tr_wartungstabelle ($this_row_data, $anlage_id, $add_tr = 1, $add_form = 1, $add_hidden = 1) {
		$monat = 1;
		$string = '';
		foreach ($this_row_data as $this_item) {
			$tdid = null;
			$this_monat = $monat - $GLOBALS['number_of_non_month_columns'] - 1;
			$this_year = $this_item['this_year'];
			$this_monat_max_12 = $this_monat % 12;
			$tdstyle = '';
			if($this_monat_max_12 == 0) {
				$this_monat_max_12 = 12;
			}
			if($monat >= $GLOBALS['number_of_non_month_columns'] && array_key_exists("id", $this_item)) {
				$this_class = "";
				if(get_setting("enable_droppable")) {
					$this_class = " class='snap' ";
				}

				$this_data = ' data-monat="'.$this_monat.'" data-jahr="'.$this_year.'" ';
				if(get_setting("enable_droppable")) {
					$this_data .= ' data-monattrue="'.$this_monat_max_12.' ';
				}

				$tdid = $this_data.' '.$this_class.' id="td_'.$anlage_id.'_'.$this_monat.'" ';
			}

			if(get_setting("opaque_after_ende_gewaehrleistung")) {
				$is_after_ende_gewaehrleistung = 0;
				if($monat >= $GLOBALS['number_of_non_month_columns'] + 2) {
					$is_after_ende_gewaehrleistung = is_after_ende_gewaehrleistung($anlage_id, $this_item['this_year'], $this_item['this_month']);
				}
				if($is_after_ende_gewaehrleistung) {
					$tdstyle = ' style="opacity: 0.6;" ';
				}
			}

			$string .= "<td$tdstyle".(($monat >= $GLOBALS['number_of_non_month_columns']) ? $tdid : '').' data-anlageid="'.$anlage_id.'">'."\n";

			$show_small_icon = 1;
			if($this_item['string']) {
				$string .= $this_item['string'];
			} else {
				$show_small_icon = 0;
			}


			if(get_setting("enable_add") && $monat > $GLOBALS['number_of_non_month_columns']) {
				if(get_setting("always_show_small_add_icon")) {
					$show_small_icon = 1;
				}

				if(array_key_exists('id', $this_item)) {
					$termin_id = "data-terminid='".$this_item['id']."'";
					if($show_small_icon) {
						$icon = "<span style='cursor: pointer;'>+</span>";
					} else {
						$width = get_setting("add_icon_width");
						$icon = "<span style='cursor: pointer;'><img alt='Neuen Termin hinzufügen' width=$width src='i/add.svg' /></span>";
					}
					$string .= "\t<span onclick='add_termin($anlage_id, $this_monat, $this_year)'>$icon</span>\n";
				}
			}

			$string .= "</td>\n";
			$monat++;
		}

		return create_tr_form($anlage_id, $string, $add_form, $add_tr, $add_hidden);
	}

	function create_tr_form ($anlage_id, $string, $add_form, $add_tr, $add_hidden = 1) {
		$tr_with_form = '';
		if($add_tr) {
			$tr_with_form .= '<tr class="line_tr" id="tr_'.$anlage_id.'" data-anlageid="'.htmle($anlage_id).'">'."\n";
	       	}

		if($add_hidden) {
			$tr_with_form .= '<input type="hidden" name="update_wartungstermine" value="1" />'."\n";
			$tr_with_form .= '<input type="hidden" name="anlage_id" value='.json_encode($anlage_id).' />'."\n";
			$tr_with_form .= '<input type="hidden" name="json" value="1" />'."\n"; 
		}

		$tr_with_form .= $string;

		if($add_tr) {
			$tr_with_form .= "</tr>\n";
		}

		return $tr_with_form;
	}

	function get_config () {
		$query = 'select name, setting, category from config order by category, name';
		$result = rquery($query);
		$config = array();
		while ($row = mysqli_fetch_row($result)) {
			$config[$row[0]] = $row[1];
		}
		$result->free();
		return $config;
	}

	function get_setting ($name) {
		if(!array_key_exists($name, $GLOBALS['settings_cache'])) {
			if(table_exists("config")) {
				$query = 'select name, setting from config';
				$res = rquery($query);
				while ($row = mysqli_fetch_row($res)) {
					$GLOBALS['settings_cache'][$row[0]] = $row[1];
				}
				$res->free();
			} else {
				$GLOBALS['settings_cache'][$name] = array();
			}
		}

		if(array_key_exists($name, $GLOBALS['settings_cache'])) {
			return $GLOBALS['settings_cache'][$name];
		} else {
			error("Setting named `$name` could not be found!!!");
			return null;
		}
	}

	function reset_setting ($name) {
		$default_setting = get_setting_default($name);
		$description = get_setting_desc($name);
		$query = "insert into config (name, setting, description) values (".esc($name).", ".esc($default_setting).", ".esc($description).") on duplicate key update setting=values(setting), description=values(description);";
		if(rquery($query)) {
			$GLOBALS['settings_cache'] = array();
			return success("Die Einstellung $name wurde auf $default_setting resettet.");
		} else {
			return error("Die Einstellung $name konnte nicht resettet werden");
		}
	}

	function set_setting ($name, $setting, $description) {
		$query = "insert into config (name, setting, description) values (".esc($name).", ".esc($setting).", ".esc($description).") on duplicate key update setting=values(setting), description=values(description);";
		if(rquery($query)) {
			$GLOBALS['settings_cache'] = array();
			return success("Die Einstellung $name wurde auf $setting gesetzt.");
		} else {
			return error("Die Einstellung $name konnte nicht gesetzt werden.");
		}
	}

	function get_setting_default ($name) {
		$query = 'select default_value from config where name = '.esc($name);
		return get_single_value_from_query($query);
	}

	function get_setting_desc ($name) {
		$query = 'select description from config where name = '.esc($name);
		return get_single_value_from_query($query);
	}

	function get_setting_category ($name) {
		$query = 'select category from config where name = '.esc($name);
		return get_single_value_from_query($query);
	}

	function javascript_debugger ($name, $end = 0) {
		$string = '';
		if(get_setting("debug") && !$end) {
			$bt = debug_backtrace();
			$caller = array_shift($bt);

			$caller_text = $caller['file'].":".$caller['line'];

			$string .= "{\n";
			$string .= 'var thisfuncname = '.json_encode($name).';'."\n";
			$string .= 'var args = Array.prototype.slice.call(arguments);'."\n";
			$string .= "var argstring = '';\n";
			if(get_setting("debug_truncate")) {
				$string .= "args = args = args.map(x => truncate(x) );\n";
				$string .= "if (args.length >= 1) { argstring = '\"' + args.join('\", \"') + '\"'; }\n";
			} else {
				$string .= "if (args.length >= 1) { argstring = '\"' + args.join('\", \"') + '\"'; }\n";
			}
			$string .= 'console.log('.json_encode($caller_text).' + "->" + '.json_encode($name).');'."\n";
			$string .= 'console.log(thisfuncname + "(" + argstring + ")");'."\n";
			$string .= '}';
		}

		if(get_setting("debug_js_time")) {
			if($end) {
				$string .= "console.timeEnd('$name');\n";
			} else {
				$string .= "console.time('$name');\n";
			}
		}
		
		return $string;
	}

	function js_debug ($msg, $swal = 0) {
		$string = '';
		if(get_setting("debug")) {
			$bt = debug_backtrace();
			$caller = array_shift($bt);

			$caller_text = $caller['file'].":".$caller['line'];
			$this_string = "'$caller_text -> ' + ".$msg;

			if($swal) {
				$string .= 'swal('.$this_string.', { icon: "warning" }).then((value) => {alert("OK");});'."\n";
			} else {
				$string .= 'console.log('.$this_string.');'."\n";
			}
		}
		return $string;
	}

	function get_kunde_id_by_wartung_id($wartung_id) {
		$query = 'select a.kunde_id from wartungen w join anlagen a on w.anlage_id = a.id where w.id = '.esc($wartung_id);
		return get_single_value_from_query($query);
	}

	function get_ersatzteil_link_by_wartung_id ($ersatzteil_id, $wartung_id) {
		$kunde_id = get_kunde_id_by_wartung_id($wartung_id);
		$ersatzteil_page_id = get_page_id_by_filename("ersatzteile.php");
		$ersatzteil_name = get_ersatzteil_name($ersatzteil_id);

		return "<a href='admin.php?page=$ersatzteil_page_id&kunde=$kunde_id&show_ersatzteil=$ersatzteil_id'>".htmle($ersatzteil_name)."</a>";
	}

	# create table wartung_kosten (wartung_id int primary key references wartung(id) on delete cascade, kosten float(10, 2))

	function set_wartung_kosten ($wartung_id, $kosten) {
		$kosten = string_to_number($kosten);
		if(is_valid_number($kosten)) {
			$query = 'insert into wartung_kosten (wartung_id, kosten) values ('.esc($wartung_id).', '.esc($kosten).') on duplicate key update kosten = values(kosten)';
			if(rquery($query)) {
				success("Kosten ".htmle($kosten)."&euro; wurden erfolgreich eingetragen für die Wartung ".fq($wartung_id)." der Anlage ".get_anlagen_link_name_by_id(get_anlage_id_by_termin_id($wartung_id)));
			} else {
				error("Kosten ".fq($kosten)." wurden NICHT erfolgreich eingetragen für die Wartung ".fq($wartung_id)." der Anlage ".fq(get_anlagen_name_by_termin_id($wartung_id)));
			}
		} else {
			warning(fq($kosten)." ist kein valider Preis");
		}
	}

	function get_wartung_kosten ($wartung_id) {
		$query = 'select kosten from wartung_kosten where wartung_id = '.esc($wartung_id);
		$value = get_single_value_from_query($query);
		if(!is_null($value)) {
			return $value;
		} else {
			return 0;
		}

	}

	function get_ersatzteil_name ($id) {
		$query = 'select name from ersatzteil where id = '.esc($id);
		return get_single_value_from_query($query);
	}

	function get_ersatzteil_default_price ($id) {
		$query = 'select default_price from ersatzteil where id = '.esc($id);
		return doubleval(get_single_value_from_query($query));
	}

	function get_wartung_ersatzteil_price ($wartungs_id, $id) {
		$query = 'select price from wartung_ersatzteil where this_wartung_id = '.esc($wartungs_id).' and this_ersatzteil_id = '.esc($id);
		return get_single_value_from_query($query);
	}

	function get_kunde_ersatzteil_price ($kunde_id, $id) {
		$query = 'select price from kunde_ersatzteil where kunde_id = '.esc($kunde_id).' and ersatzteil_id = '.esc($id);
		return get_single_value_from_query($query);
	}

	function get_ersatzteil_price ($ersatzteil_id, $termin_id) {
		/*
		Suchreihenfolge: 
			- wartung_ersatzteil
			- kunde_ersatzteil
			- ersatzteil
		*/

		$value = get_wartung_ersatzteil_price($termin_id, $ersatzteil_id);
		if(!is_null($value)) {
			return $value;
		} else {
			$anlage_id = get_anlage_id_by_termin_id($termin_id);
			$kunde_id = get_kunde_id_by_anlage_id($anlage_id);
			$value = get_kunde_ersatzteil_price($kunde_id, $ersatzteil_id);
			if(!is_null($value)) {
				return $value;
			} else {
				$value = get_ersatzteil_default_price($ersatzteil_id);
				return $value;
			}
		}
	}

	function sum_of_ersatzteile_prices ($termin_id, $full = 0) {
		$ersatzteile_query = 'select amount, this_ersatzteil_id from wartung_ersatzteil where this_wartung_id = '.esc($termin_id);
		$result = rquery($ersatzteile_query);

		$sum = 0;
		if($full) {
			$sum = get_wartung_kosten($termin_id) + get_wartungspauschale(get_anlage_id_by_termin_id($termin_id));
		}

		while ($row = mysqli_fetch_row($result)) {
			$amount = $row[0];
			$this_ersatzteil_id = $row[1];
			$sum += ($amount * get_ersatzteil_price($this_ersatzteil_id, $termin_id));
		}

		return $sum;
	}

	function update_termin_ersatzteil_2($ersatzteil_id, $anzahl, $termin_id, $spezialpreis) {
		/*
+--------------------+-------------+------+-----+---------+-------+
| Field              | Type        | Null | Key | Default | Extra |
+--------------------+-------------+------+-----+---------+-------+
| amount             | int(11)     | YES  |     | 1       |       |
| this_wartung_id    | int(11)     | NO   | PRI | NULL    |       |
| this_ersatzteil_id | int(11)     | NO   | PRI | NULL    |       |
| price              | float(10,2) | YES  |     | NULL    |       |
+--------------------+-------------+------+-----+---------+-------+
		 */

		$spezialpreis = string_to_number($spezialpreis);
		$anzahl = string_to_number($anzahl);

		if($anzahl > 0) {
			$query = "insert into wartung_ersatzteil (amount, this_wartung_id, this_ersatzteil_id, price) values (".esc($anzahl).", ".esc($termin_id).", ".esc($ersatzteil_id).", ".esc($spezialpreis).") on duplicate key update price = values(price), amount = values(amount)";
			if(rquery($query)) {
				success("Das Ersatzteil ".fq(get_ersatzteil_name($ersatzteil_id))." konnte erfolgreich eingetragen werden");
			} else {
				error("Das Ersatzteil konnte leider nicht eingetragen werden");
			}
		} else {
			$query = "delete from wartung_ersatzteil where this_wartung_id = ".esc($termin_id)." and this_ersatzteil_id = ".esc($ersatzteil_id);
			if(rquery($query)) {
				success("Das Ersatzteil ".fq(get_ersatzteil_name($ersatzteil_id))." konnte erfolgreich entfernt werden");
			} else {
				error("Das Ersatzteil konnte leider nicht entfernt werden");
			}
		}
	}

	function update_termin_ersatzteil($ersatzteil_id, $anzahl, $termin_id, $spezialpreis) {
		/*
+--------------------+-------------+------+-----+---------+-------+
| Field              | Type        | Null | Key | Default | Extra |
+--------------------+-------------+------+-----+---------+-------+
| amount             | int(11)     | YES  |     | 1       |       |
| this_wartung_id    | int(11)     | NO   | PRI | NULL    |       |
| this_ersatzteil_id | int(11)     | NO   | PRI | NULL    |       |
| price              | float(10,2) | YES  |     | NULL    |       |
+--------------------+-------------+------+-----+---------+-------+
		 */

		$spezialpreis = string_to_number($spezialpreis);
		$anzahl = string_to_number($anzahl);

		$old_amount = get_amount_ersatzteile_from_termin_and_ersatzteil_id($termin_id, $ersatzteil_id);

		if($old_amount + $anzahl > 0) {
			$query = "insert into wartung_ersatzteil (amount, this_wartung_id, this_ersatzteil_id, price) values (".esc($anzahl).", ".esc($termin_id).", ".esc($ersatzteil_id).", ".esc($spezialpreis).") on duplicate key update price = values(price), amount = amount + values(amount)";
			if(rquery($query)) {
				success("Das Ersatzteil ".fq(get_ersatzteil_name($ersatzteil_id))." konnte erfolgreich eingetragen werden");
			} else {
				error("Das Ersatzteil konnte leider nicht eingetragen werden");
			}
		} else {
			$query = "delete from wartung_ersatzteil where this_wartung_id = ".esc($termin_id)." and this_ersatzteil_id = ".esc($ersatzteil_id);
			if(rquery($query)) {
				success("Das Ersatzteil ".fq(get_ersatzteil_name($ersatzteil_id))." konnte erfolgreich entfernt werden");
			} else {
				error("Das Ersatzteil konnte leider nicht entfernt werden");
			}
		}
	}

	function get_ersatzteil_id_by_name_and_price ($name, $price) {
		$query = 'select id from ersatzteil where name = '.esc($name);
		if(is_null($price)) {
			$query .= ' and default_price is null';
		} else {
			$query .= ' and default_price = '.esc($price);
		}
		return get_single_value_from_query($query);
	}

	function create_ersatzteil ($name, $default_price = null, $kundendaten = array()) {
		$default_price = string_to_number($default_price);
		if(!empty($name)) {
			$query = 'insert into ersatzteil (name, default_price) values ('.esc($name).', '.esc($default_price).') on duplicate key update default_price = values(default_price), name = values(name)';
			if(rquery($query)) {
				$last_id = get_ersatzteil_id_by_name_and_price($name, $default_price);
				if(array_key_exists('kunde_id', $kundendaten) && array_key_exists('kunde_price', $kundendaten)) {
					$kundendaten['kunde_price'] = string_to_number($kundendaten['kunde_price']);
					$query = 'insert into kunde_ersatzteil (kunde_id, ersatzteil_id, price) values ('.esc($kundendaten['kunde_id']).', '.esc($last_id).', '.esc($kundendaten['kunde_price']).') on duplicate key update price = values(price)';
					if(rquery($query)) {
						success("Ok, Ersatzteil &raquo;$name&laquo; erstellt");
						return $last_id;
					} else {
						error("Konnte Ersatzteil &raquo;$name&laquo; nicht erstellen, sorry...");
					}
				} else {
					success("Ok, Ersatzteil &raquo;$name&laquo; erstellt");
					return $last_id;
				}
			} else {
				error("Konnte Ersatzteil &raquo;$name&laquo; nicht erstellen, sorry...");
			}
		} else {
			error("Leere Ersatzteilnamen sind nicht erlaubt");
		}
	}

	function update_ersatzteil ($id, $name, $default_price, $kundendaten = array()) {
		$default_price = string_to_number($default_price);
		$query = 'update ersatzteil set name = '.esc($name).', default_price = '.esc($default_price).' where id = '.esc($id);
		if(rquery($query)) {
			if(array_key_exists('kunde_id', $kundendaten) && array_key_exists('kunde_price', $kundendaten)) {
				$kundendaten['kunde_price'] = string_to_number($kundendaten['kunde_price']);
				$query = 'insert into kunde_ersatzteil (kunde_id, ersatzteil_id, price) values ('.esc($kundendaten['kunde_id']).', '.esc($id).', '.esc($kundendaten['kunde_price']).') on duplicate key update price = values(price)';
				if(rquery($query)) {
					return success("Ok, Ersatzteil &raquo;$name&laquo; geändert");
				} else {
					return error("Konnte Ersatzteil &raquo;$name&laquo; nicht ändern, sorry...");
				}
			} else {
				return success("Ok, Ersatzteil &raquo;$name&laquo; geändert");
			}
		} else {
			return error("Konnte Ersatzteil &raquo;$name&laquo; nicht ändern, sorry...");
		}
	}

	function get_ersatzteile_ids_from_termin ($termin_id) {
		$query = 'select this_ersatzteil_id from wartung_ersatzteil where this_wartung_id = '.esc($termin_id);
		$result = rquery($query);
		$ersatzteile_ids = array();

		while ($row = mysqli_fetch_row($result)) {
			$ersatzteile_ids[] = $row[0];
		}
		return $ersatzteile_ids;
	}

	function fq ($str) {
		return "&raquo;".htmle($str)."&laquo;";
	}

	function get_wartungspauschale ($anlage_id) {
		$query = 'select id, wartungspauschale from anlagen';
		return get_cached_result($anlage_id, $query, 'get_wartungspauschale_cache', 0, 0, 0);
	}

	function get_amount_ersatzteile_from_termin_and_ersatzteil_id ($termin_id, $ersatzteil_id) {
		$query = 'select amount from wartung_ersatzteil where this_wartung_id = '.esc($termin_id).' and this_ersatzteil_id = '.esc($ersatzteil_id);
		return get_single_value_from_query($query);
	}

	function get_geo_coordinates_from_plz ($plz) {
		$query = 'select latitude, longitude from plz_coordinates where plz = '.esc($plz);
		return get_single_row_from_query($query);
	}

	function is_valid_number ($str) {
		if(preg_match('/^[+-]?\d+(\.\d+)?$/', $str)) {
			return true;
		} else {
			return false;
		}
	}

	function is_valid_date ($str) {
		if(preg_match('/^\d{4}-\d\d-\d\d$/', $str)) {
			return true;
		} else {
			return false;
		}
	}

	function months_between_two_dates ($date1, $date2) {
		if(is_valid_date($date1) && is_valid_date($date2)) {
			$d1 = new DateTime($date2); 
			$d2 = new DateTime($date1);
			$Months = $d2->diff($d1); 
			$howeverManyMonths = (($Months->y) * 12) + ($Months->m);
			return $howeverManyMonths;
		} else {
			return null;
		}
	}

	function fucked_up_date_to_real_date ($excel_date, $is_csv = 0) {
		$min_plausible_year = 1950;
		if($is_csv) {
			if(preg_match('/(\d{2})\s*[\/\.-]\s*(\d{4})/', $excel_date, $matches)) {
				if($matches[2] > $min_plausible_year) {
					return $matches[2].'-'.$matches[1].'-15';
				} else {
					return null;
				}
			} else if(preg_match('/(\d{4})\s*[\/\.-]\s*(\d{2})/', $excel_date, $matches)) {
				if($matches[2] > $min_plausible_year) {
					return $matches[1].'-'.$matches[2].'-15';
				} else {
					return null;
				}
			} else {
				return $excel_date;
			}
		} else {
			if(!preg_match('/^\d+(?:\.\d+)?$/', $excel_date) || $excel_date < 1000) {
				return $excel_date;
			} else {
				$unix_date = ($excel_date - 25569) * 86400;
				$excel_date = 25569 + ($unix_date / 86400);
				$unix_date = ($excel_date - 25569) * 86400;

				return gmdate("Y-m-d", $unix_date);
			}
		}
	}

	function update_wartung_via_map ($wartung_id, $status_id, $kommentar1, $kommentar2) {
		$query = 'update wartungen set status_id = '.esc($status_id).', comment = '.esc($kommentar1).', comment2 = '.esc($kommentar2).' where id = '.esc($wartung_id);
		if(rquery($query)) {
			success("Das Ändern hat geklappt");
		} else {
			error("Das Eintragen hat nicht geklappt");
		}
	}

	function array2Table($data, $status = array(), $error_lines = array()) {
		$str = "<table>\n";
		$line = 0;
		foreach($data as $row) {
			$column = 0;
			if($line == 0) {
				print '<thead style="z-index: 300" id="wartungstabelle_thead">';
			}

			$tr_class = '';
			if($line >= 1) {
				$tr_class = 'line_was_ok';
				if(array_key_exists("something_failed", $status[$line]) && $status[$line]['something_failed']) {
					$tr_class = 'line_was_not_ok';
				}
			}

			$str .= "\t<tr id='line_".$line."' class='".$tr_class."'>\n";

			if(count($status)) {
				if($line == 0 && $column == 0) {
					$str .= "\t\t<th>Line</th>\n";
					$str .= "\t\t<th>Import Kunde Ok?</th>\n";
					$str .= "\t\t<th>Import Anlage Ok?</th>\n";
				} else {
					if(array_key_exists($line, $status)) {
						$str .= "\t<td>".$line."</td>\n";
						$str .= "\t<td>".$status[$line]['kunde']."</td>\n";
						$str .= "\t<td>".$status[$line]['anlage']."</td>\n";
					}
				}
			}

			foreach($row as $cell) {
				if($line == 0) {
					$str .= "\t\t<th>".escape($cell)."</th>\n";
				} else {
					if($column + 1 == 7 || $column + 1 == 11) {
						$cell = fucked_up_date_to_real_date($cell);
					}
					$cell = escape($cell);
					if(array_key_exists($line, $error_lines) && array_key_exists($column, $error_lines[$line])) {
						if(empty($cell) || preg_match('/^\s*$/', $cell)) {
							$cell = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
						}
						$str .= "\t\t<td><div class='".$error_lines[$line][$column]."_td'>".$cell."</div></td>\n";
					} else {
						$str .= "\t\t<td>".escape($cell)."</td>\n";
					}
				}
				$column++;
			}
			$str .= "\t</tr>\n";

			if($line == 0) {
				print '<thead style="z-index: 300" id="wartungstabelle_thead">';
			}

			$line = $line + 1;
		}
		$str .= '</table><br />';

		$str .= '<span class="error_td">Fehlerhafter Eintrag</span>, wegen diesem Eintrag schlägt das Importieren fehl<br>';
		$str .= '<span class="warning_td">Eintrag mit Warnung</span>, dieser Eintrag sorgt nicht dafür, dass das Importieren fehlschlägt, aber er könnte falsche Daten beinhalten<br>';
		$str .= '<span class="corrected_td">Automatisch korrigiert</span>, hier sind Daten, die falsch waren oder fehlen, aber die aber automatisch korrigiert werden konnten<br>';
		$str .= '<span class="info_td">Info</span>, weitere Infos aus dem Importprozess<br>';

		$str .= '<br><br><span style="text-decoration: underline;" onclick="$(\'.line_was_ok\').toggle();">Nur Zeilen ausblenden/anzeigen, in denen etwas fehlgeschlagen ist</span><br><br>';
		return $str;
	}

	function escape($string) {
		return $string;
	}

	function get_spalte($name, $spaltennummern, $anlage, $alternative = null, $alternative_2 = null) {
		if(array_key_exists($name, $spaltennummern)) {
			$nr = $spaltennummern[$name]["nr"];
			$optional = $spaltennummern[$name]["optional"];
			if(is_null($nr)) {
				if(!$optional) {
					if($alternative) {
						return $alternative;
					} else {
						if($alternative_2) {
							return $alternative_2;
						} else {
							die("Missing non optional column $name");
						}
					}
				} else {
					return null;
				}
			} else {
				$value = $anlage[$nr];
				return $value;
			}
		} else {
			dier("Unknown column name: $name");
		}
	}

	function link_anlage($id) {
		$link = '<a href="admin.php?page='.get_page_id_by_filename("anlagen.php").'&show_only_this_anlage='.$id.'">'.$id."</a>";
		return $link;
	}

	function print_line_link ($line) {
		return '<a href="#line_'.$line.'">'.$line.'</a>';
	}

	if(get_post('start_import')) {
		$GLOBALS['return_null_if_anlage_creation_failed'] = 0;
		if(array_key_exists('excelfile', $_FILES) && array_key_exists('tmp_name', $_FILES['excelfile'])) {
			$filename = $_FILES['excelfile']['tmp_name'];
			$data = array();

			$is_csv = 1;
			$file = fopen($filename, 'r');
			$i = 0;

			$delimiter = ",";

			while (($line = fgetcsv($file, 0, $delimiter)) !== FALSE) {
				$data[$i] = $line;
				$i++;
			}

			fclose($file);

			$headlines = $data[0];
			$headlines = preg_replace("/\s+/", " ", $headlines);
			$headlines = preg_replace("/^\s+/", "", $headlines);
			$headlines = preg_replace("/\s+$/", "", $headlines);
			$headlines = preg_replace("/-\s+/", "-", $headlines);
			$headlines = preg_replace("/-([a-z])/", "$1", $headlines);

			$spaltennummern = array(
				"ort" => array ("nr" => null, "regex" => "/^\s*ort/i", "optional" => 0),
				"firma_name" => array ("nr" => null, "regex" => "/^\s*kunde\s*$/i", "optional" => 0),
				"anlage_kommentar" => array ("nr" => null, "regex" => "/kommentar/i", "optional" => 1),
				"ort_anlage" => array ("nr" => null, "regex" => "/^\s*ort/i", "optional" => 1),
				"anlage_name" => array ("nr" => null, "regex" => "/^\s*anlage\s*$/i", "optional" => 0),
				"zeit_pro_wartung" => array ("nr" => null, "regex" => "/zeit\s*pro\s*wartung/i", "optional" => 1),
				"wartungspauschale" => array ("nr" => null, "regex" => "/pauschale/i", "optional" => 1),
				"letzte_wartung" => array ("nr" => null, "regex" => "/letzte\s*wartung/i", "optional" => 0),
				"kein_vertrag" => array ("nr" => null, "regex" => "/vertrag/i", "optional" => 1),
				"anzahl_wartungen_pro_jahr" => array ("nr" => null, "regex" => "/Anz/i", "optional" => 1),
				"tage_zwischen_wartungen" => array ("nr" => null, "regex" => "/Tage/i", "optional" => 1),
				"naechste_wartung" => array ("nr" => null, "regex" => "/n.*chste.*wartung/i", "optional" => 0),
				"strasse" => array ("nr" => null, "regex" => "/stra.*e\s*$/i", "optional" => 1),
				"plz" => array ("nr" => null, "regex" => "/plz/i", "optional" => 1),
				"ansprechpartner_name" => array ("nr" => null, "regex" => "/sprechpartner/i", "optional" => 1),
				"ansprechpartner_telnr" => array ("nr" => null, "regex" => "/tele/i", "optional" => 1),
				"material_wartung" => array("nr" => null, "regex" => "/material.*wartung/i", "optional" => 1)
			);

			$used_columns = array();
			foreach ($spaltennummern as $this_spalte_name => $this_spalte_content) {
				$regex = $spaltennummern[$this_spalte_name]["regex"];

				$i = 0;
				$found = 0;
				foreach ($headlines as $this_headline) {
					if(!$found) {
						if(!array_key_exists($i, $used_columns)) {
							if(preg_match($regex, $this_headline)) {
								$spaltennummern[$this_spalte_name]["nr"] = $i;
								$used_columns[$i] = 1;
								$found = 1;
							}
						}

						$i = $i + 1;
					}
				}
			}

			$error_occured = 0;
			foreach ($spaltennummern as $this_spalte_name => $this_spalte_content) {
				if($this_spalte_content['optional'] == 0) {
					if(is_null($this_spalte_content['nr'])) {
						error("Die nicht-optionale Spalte $this_spalte_name konnte nicht gefunden werden (Regex: ".$this_spalte_content['regex'].").");
						$error_occured = 1;
					}
				}
			}

			if(!$error_occured) {
				$max_spalte = 0;
				foreach ($spaltennummern as $this_spalte_name => $this_spalte_content) {
					if($this_spalte_content['nr'] > $max_spalte) {
						$max_spalte = $this_spalte_content['nr'];
					}
				}

				$ersatzteile = array_slice($headlines, $max_spalte);

				foreach ($ersatzteile as $name) {
					create_ersatzteil($name);
				}

				$status = array();
				$error_lines = array();
				$line = 1;

				$failed_kunden = 0;
				$failed_anlagen = 0;
				$ok_kunden = 0;
				$ok_anlagen = 0;
				$ok_anlagen_mit_turnus = 0;
				$anzeige_tabelle = 0;

				$anlage_ohne_name_nr = 1;
				foreach (array_slice($data, 1) as $anlage) {
					$wartungen_pro_monat = 1;
					$ort_firma = get_spalte("ort", $spaltennummern, $anlage);
					$erste_wartung_status = 1;
					if(!preg_match('/[a-zA-ZäöüÖÄÜß]/', $ort_firma)) {
						$error_lines[$line][$spaltennummern["ort"]["nr"]] = 'warning';
						warning("In Zeile ".print_line_link($line)." beinhaltet der Firmenort keine Buchstaben");
					}

					$material_wartung = get_spalte("material_wartung", $spaltennummern, $anlage);

					$firma_name = get_spalte("firma_name", $spaltennummern, $anlage);

					$anlage_kommentar = get_spalte("anlage_kommentar", $spaltennummern, $anlage);
					$anlage_name = get_spalte("anlage_name", $spaltennummern, $anlage);

					if(!$anlage_name) {
						$anlage_name = "Anlage ohne Namen Nr. $anlage_ohne_name_nr";
						$anlage_ohne_name_nr = $anlage_ohne_name_nr + 1;
						$data[$line][$spaltennummern["anlage_name"]["nr"]] = $anlage_name;
						$error_lines[$line][$spaltennummern["anlage_name"]["nr"]] = 'corrected';
					}

					$zeit_pro_wartung = get_spalte("zeit_pro_wartung", $spaltennummern, $anlage);

					if(!preg_match('/^\d+(?:[,\.]\d+)?$/', $zeit_pro_wartung)) {
						$error_lines[$line][$spaltennummern["zeit_pro_wartung"]["nr"]] = 'warning';
						$zeit_pro_wartung = null;
						warning("In Zeile ".print_line_link($line)." ist die Zeit pro Wartung keine valide Zahl");
					}

					$wartungspauschale = get_spalte("wartungspauschale", $spaltennummern, $anlage);

					if(!preg_match('/^\d+(?:[,\.]\d+)?$/', $wartungspauschale)) {
						$error_lines[$line][$spaltennummern["wartungspauschale"]["nr"]] = 'warning';
						$wartungspauschale = null;
						warning("In Zeile ".print_line_link($line)." ist die Wartungspauschale keine valide Zahl");
					}


					#$kein_vertrag = get_spalte("kein_vertrag", $spaltennummern, $anlage);
					#$tage_zwischen_wartungen = (365 / ($anzahl_wartungen_pro_jahr + 3));# get_spalte("tage_zwischen_wartungen", $spaltennummern, $anlage);
					#ceil($tage_zwischen_wartungen / 31);

					$letzte_wartung = fucked_up_date_to_real_date($anlage[$spaltennummern["letzte_wartung"]["nr"]], $is_csv); ### TODO geht nicht
					$naechste_wartung = fucked_up_date_to_real_date($anlage[$spaltennummern["naechste_wartung"]["nr"]], $is_csv);

					if(!preg_match('/^\d{4}-\d\d-\d\d$/', $letzte_wartung)) {
						$letzte_wartung = null;
						$error_lines[$line][$spaltennummern["letzte_wartung"]["nr"]] = 'warning';
					}

					if(!preg_match('/^\d{4}-\d\d-\d\d$/', $naechste_wartung)) {
						$naechste_wartung = null;
						$error_lines[$line][$spaltennummern["naechste_wartung"]["nr"]] = 'warning';
					}

					$anzahl_wartungen_pro_jahr = get_spalte("anzahl_wartungen_pro_jahr", $spaltennummern, $anlage);
					$monate_laut_anzahl_wartungen_pro_jahr = 0;
					if(is_valid_number($anzahl_wartungen_pro_jahr)) {
						$monate_laut_anzahl_wartungen_pro_jahr = 12 / $anzahl_wartungen_pro_jahr;
						if($monate_laut_anzahl_wartungen_pro_jahr > 0 && $monate_laut_anzahl_wartungen_pro_jahr < 1) {
							$wartungen_pro_monat = ceil(1 / ($monate_laut_anzahl_wartungen_pro_jahr));
							$monate_laut_anzahl_wartungen_pro_jahr = 1;
						}
					} else {
						$error_lines[$line][$spaltennummern["anzahl_wartungen_pro_jahr"]["nr"]] = 'warning';
					}

					if($letzte_wartung == $naechste_wartung && $monate_laut_anzahl_wartungen_pro_jahr > 0) {
						$letzte_wartung = null;
					}

					if(!$letzte_wartung && $naechste_wartung && $monate_laut_anzahl_wartungen_pro_jahr > 0) {
						$erste_wartung_status = 2;
						$letzte_wartung = $naechste_wartung;

						$naechste_wartung_date = new Datetime($letzte_wartung);
						$naechste_wartung_date->modify("+$monate_laut_anzahl_wartungen_pro_jahr month");
						$naechste_wartung = $naechste_wartung_date->format('Y-m-d');
						#dier("$letzte_wartung + $monate_laut_anzahl_wartungen_pro_jahr monate = $naechste_wartung");

						$data[$line][$spaltennummern["naechste_wartung"]["nr"]] = $naechste_wartung;
						$error_lines[$line][$spaltennummern["naechste_wartung"]["nr"]] = 'corrected';

						$data[$line][$spaltennummern["letzte_wartung"]["nr"]] = $letzte_wartung;
						$error_lines[$line][$spaltennummern["letzte_wartung"]["nr"]] = 'corrected';
					}

					#$data[$line][$spaltennummern["letzte_wartung"]["nr"]] = $letzte_wartung;
					#$error_lines[$line][$spaltennummern["letzte_wartung"]["nr"]] = 'corrected';

					#$data[$line][$spaltennummern["naechste_wartung"]["nr"]] = $naechste_wartung;
					#$error_lines[$line][$spaltennummern["naechste_wartung"]["nr"]] = 'corrected';

					$strasse_unbearbeitet = get_spalte("strasse", $spaltennummern, $anlage);
					$strasse = $strasse_unbearbeitet;
					$hausnummer = '';

					if(preg_match('/^(.*?)\s*(\d+[\/\s\da-zA-ZäöüßÖÄÜá\.-]*)$/', $strasse_unbearbeitet, $matches)) {
						$strasse = $matches[1];
						$hausnummer = $matches[2];
					} else if(preg_match('/^[\d\.\w\s]+$/', $strasse_unbearbeitet)) {
						$strasse = $strasse_unbearbeitet;
						$error_lines[$line][$spaltennummern["strasse"]["nr"]] = 'warning';
						warning("In Zeile ".print_line_link($line)." scheint die Hausnummer zu fehlen");
					} else {
						$error_lines[$line][$spaltennummern["strasse"]["nr"]] = 'warning';
						warning("In Zeile ".print_line_link($line)." fehlt ein plausibler Straßenname");
					}

					$plz_unbearbeitet = get_spalte("plz", $spaltennummern, $anlage);
					$plz = $plz_unbearbeitet;
					$land = '';
					if(preg_match('/([a-zA-Z]+)?(?:\s*|-)*([\d-]{4,6}?)$/', $plz, $matches)) {
						$land = $matches[1];
						if($land == "D") {
							$land = "Deutschland";
						} else if ($land == "F") {
							$land = "Frankreich";
						} else if ($land == "PL") {
							$land = "Polen";
						} else {
							$land = "Deutschland";
						}
						$plz = $matches[2];
						$plz = preg_replace('/^-/', '', $plz);
					} else if (preg_match('/^\d{5}$/', $plz_unbearbeitet)) {
						$land = "Deutschland";
						$plz = $plz_unbearbeitet;
					} else if (preg_match('/^[a-zA-Z]$/', $plz_unbearbeitet) || preg_match('/^\d{1,4}$/', $plz_unbearbeitet) || !empty($plz_unbearbeitet)) {
						$land = "Deutschland";
						$plz = $plz_unbearbeitet;
						$error_lines[$line][$spaltennummern["plz"]["nr"]] = 'warning';
						warning("Die PLZ in Zeile $line ist nicht plausibel (".fq($plz).")");
					} else {
						$error_lines[$line][$spaltennummern["plz"]["nr"]] = 'warning';
						warning("In Zeile ".print_line_link($line)." fehlt die PLZ");
					}

					$ort_anlage = get_spalte("ort_anlage", $spaltennummern, $anlage);
					if(empty($ort_anlage)) {
						$error_lines[$line][$spaltennummern["ort_anlage"]["nr"]] = 'warning';
						warning("In Zeile ".print_line_link($line)." fehlt der Ort");
					}

					$ansprechpartner_name = get_spalte("ansprechpartner_name", $spaltennummern, $anlage);
					if(!$ansprechpartner_name) {
						$error_lines[$line][$spaltennummern["ansprechpartner_name"]["nr"]] = 'warning';
					}
					$ansprechpartner_telnr = get_spalte("ansprechpartner_telnr", $spaltennummern, $anlage);

					$ansprechpartner_telnr = preg_replace('/\s*/', '', $ansprechpartner_telnr);
					$ansprechpartner_telnr = preg_replace('/\//', '', $ansprechpartner_telnr);

					$ansprechpartner_telnr = preg_replace('/Tel\.:\s*/', '', $ansprechpartner_telnr);

					if(!preg_match('/^[\(\),;0-9\s\/–+-]{3,}$/', $ansprechpartner_telnr)) {
						$error_lines[$line][$spaltennummern["ansprechpartner_telnr"]["nr"]] = 'warning';
						warning("In Zeile ".print_line_link($line)." scheint irgendwas mit der Telefonnummer nicht zu stimmen");
					}

					$ansprechpartner_id = get_or_create_ansprechpartner(null, $ansprechpartner_telnr, $ansprechpartner_name); #o
					$months_between_wartungen = months_between_two_dates($letzte_wartung, $naechste_wartung);
					$turnus_id = null;

					if($months_between_wartungen) {
						$turnus_id = get_or_create_turnus_by_anzahl_monate($months_between_wartungen, $wartungen_pro_monat);
					} else if($monate_laut_anzahl_wartungen_pro_jahr > 0) {
						$error_lines[$line][$spaltennummern["letzte_wartung"]["nr"]] = 'warning';
						$error_lines[$line][$spaltennummern["naechste_wartung"]["nr"]] = 'warning';
						$turnus_id = get_or_create_turnus_by_anzahl_monate($monate_laut_anzahl_wartungen_pro_jahr, $wartungen_pro_monat);
					} else {
						error("Für die Anlage ".fq($anlage_name)." konnte keine Anzahl von Monaten zwischen den Wartungen gefunden werden (Zeile ".print_line_link($line).")");
						$error_lines[$line][$spaltennummern["letzte_wartung"]["nr"]] = 'warning';
						$error_lines[$line][$spaltennummern["naechste_wartung"]["nr"]] = 'warning';
					}

					$anlage_id = null;
					$kunde_id = null;

					if($firma_name) {
						$kunde_id = create_kunde($firma_name, null, null, null, null, 0, 0, 0, null, null, $land);
						if($kunde_id) {
							$anlage_id = create_anlage($kunde_id, $anlage_name, $turnus_id, null, $letzte_wartung, null, $anlage_kommentar, $erste_wartung_status, $wartungspauschale, $ansprechpartner_id, $zeit_pro_wartung, $plz, $ort_anlage, $strasse, $hausnummer, $land, $material_wartung);

							$data[$line][$spaltennummern["firma_name"]["nr"]] .= "<br><span class='info_td'>(->kunde_id:&nbsp;$kunde_id)</span>";
							$data[$line][$spaltennummern["anlage_name"]["nr"]] .= "<br><span class='info_td'>(->anlage_id:&nbsp;".link_anlage($anlage_id).")</span>";

							if(is_null($turnus_id)) {
								if($months_between_wartungen == 0) {
									error("Konnte keine Turnus-ID für die Anlage &raquo;".htmle($anlage_name)."&laquo; erstellen (Zeile ".print_line_link($line).")");
									$error_lines[$line][$spaltennummern["letzte_wartung"]["nr"]] = 'warning';
									$error_lines[$line][$spaltennummern["naechste_wartung"]["nr"]] = 'warning';
								} else {
									error("Konnte keine Turnus-ID erstellen (Zeile ".print_line_link($line).")");
									$error_lines[$line][$spaltennummern["letzte_wartung"]["nr"]] = 'warning';
									$error_lines[$line][$spaltennummern["naechste_wartung"]["nr"]] = 'warning';
								}
							}
						} else {
							error("Konnte Kunde ".fq($firma_name)." nicht erstellen");
						}
					} else {
						if(empty($firma_name)) {
							error("Konnte Kunde nicht erstellen, weil der Name fehlt");
							$error_lines[$line][$spaltennummern["firma_name"]["nr"]] = 'error'; # $firma_name
						} else {
							error("Konnte Kunde nicht erstellen");
						}
					}

					$status[$line]['something_failed'] = 0;
					if(is_null($kunde_id)) {
						$status[$line]['kunde'] = "<span style='color: red;'>&#x2717;</span>";
						$failed_kunden = $failed_kunden + 1;
						$status[$line]['something_failed'] = 1;
					} else {
						$status[$line]['kunde'] = "<span style='color: green;'>&#9989;</span>";
						$ok_kunden = $ok_kunden + 1;
					}

					if(is_null($anlage_id)) {
						$status[$line]['anlage'] = "<span style='color: red;'>&#x2717;</span>";
						$failed_anlagen = $failed_anlagen + 1;
						$status[$line]['something_failed'] = 1;
					} else {
						$status[$line]['anlage'] = "<span style='color: green;'>&#9989;</span>";
						$ok_anlagen = $ok_anlagen + 1;
						if($turnus_id) {
							$ok_anlagen_mit_turnus = $ok_anlagen_mit_turnus + 1;
							if($letzte_wartung) {
								$anzeige_tabelle = $anzeige_tabelle + 1;
							}
						}
					}
					$line++;
				}

				$jahrstart = date('Y');
				$jahrauswahl = date('Y');
				$monatauswahl = null;
				$show_status_id = null;
				$show_anlage_id = null;
				$show_kunde_id = null;
				$plzbeginswith = null;
				$jahreplus = 10;

				add_wartungstermine($jahrstart + $jahreplus + 1);
				$wartungstabelle_data = prepare_wartungstermine($jahrstart, $jahreplus, null, null, null, null, 1, null, null, null);
				create_wartungstabelle_table_from_data($wartungstabelle_data, $jahrstart, $jahreplus, $monatauswahl, $jahrauswahl);

				$GLOBALS['import_table'] .= array2Table($data, $status, $error_lines);

				$GLOBALS['import_table'] .= "<br>Anzahl OKer Kundenimporte: $ok_kunden<br>";
				$GLOBALS['import_table'] .= "<br>Anzahl fehlgeschlagener Kundenimporte: $failed_kunden<br>";

				$GLOBALS['import_table'] .= "<br>Anzahl OKer Anlagenimporte: $ok_anlagen<br>";
				$GLOBALS['import_table'] .= "<br>Anzahl fehlgeschlagener Anlagenimporte: $failed_anlagen<br>";

				$failed_anlagen_mit_turnus = $ok_anlagen - $ok_anlagen_mit_turnus ;
				$GLOBALS['import_table'] .= "<br>Anzahl OKer Anlagenimporte mit Turnus: $ok_anlagen_mit_turnus<br>";
				$GLOBALS['import_table'] .= "<br>Anzahl OKer Anlagenimporte ohne Turnus: $failed_anlagen_mit_turnus<br>";

				$GLOBALS['import_table'] .= "<br>Anzahl Anlagen die in der Tabelle angezeigt werden sollten: $anzeige_tabelle<br>";
			}
		} else {
			$GLOBALS['import_table'] .= "Bitte uploade eine Datei";
		}
	}

	function kunde_has_problematische_anlagen ($kunde_id) {
		$has_problematische_anlagen = 0;

		$query = 'select count(*) from anlagen where kunde_id = '.esc($kunde_id);
		$query .= ' and (letzte_wartung is null or wv_turnus_id is null or ort is null or plz is null or name like " %")';
		$query .= ' order by id desc';

		if(get_single_value_from_query($query) >= 1) {
			$has_problematische_anlagen = 1;
		}

		return $has_problematische_anlagen;
	}

	function get_number_of_ersatzteile () {
		$query = 'select count(*) from ersatzteil';
		return get_single_value_from_query($query);
	}

	function get_status_from_termin_id ($termin_id) {
		$query = 'select status_id from wartungen where id = '.esc($termin_id);
		return get_single_value_from_query($query);
	}

	function get_status_color_by_termin_id ($termin_id) {
		$query = 'select s.color from wartungen w join status s on w.status_id = s.id where w.id = '.esc($termin_id);
		return get_single_value_from_query($query);
	}

	function color_inverse ($color){
		$color = str_replace('#', '', $color);
		if (strlen($color) != 6){
			return '000000';
		}
		$rgb = '';
		for ($x=0; $x<3; $x++){
			$c = 255 - hexdec(substr($color,(2*$x),2));
			$c = ($c < 0) ? 0 : dechex($c);
			$rgb .= (strlen($c) < 2) ? '0'.$c : $c;
		}
		return '#'.$rgb;
	}

	function get_kunde_name_by_id ($id) {
		$query = 'select id, kunde from kunden';
		return get_cached_result($id, $query, "get_kunde_name_by_id_cache");
	}

	function get_anlage_name_by_id ($id) {
		$query = 'select id, name from anlagen';
		return get_cached_result($id, $query, "get_anlage_name_by_id_cache");
	}

	function get_gebrauchte_zeit_pro_wartung ($termin_id) {
		$query = 'select gebrauchte_zeit from wartungen where id = '.esc($termin_id);
		$result = get_single_value_from_query($query);
		return $result;
	}

	function add_gebrauchte_zeit_zu_wartung ($termin_id, $gebrauchte_zeit) {
		$query = "update wartungen set gebrauchte_zeit = ".esc(string_to_number($gebrauchte_zeit))." where id = ".esc($termin_id);
		if(rquery($query)) {
			success("Das Eintragen der Zeit hat geklappt");
		} else {
			error("Das Eintragen der Zeit hat nicht geklappt");
		}
	}

	function get_string_statistik_gebrauchte_zeit_pro_wartung ($id) {
		$row = get_statistik_gebrauchte_zeit_pro_wartung($id);
		return $row[0].' / '.$row[1].' / '.$row[2];
	}

	function get_statistik_gebrauchte_zeit_pro_wartung ($id) {
		if(!array_key_exists($id, $GLOBALS['get_statistik_gebrauchte_zeit_pro_wartung_cache'])) {
			$query = 'select min(gebrauchte_zeit) as min, max(gebrauchte_zeit) as max, avg(gebrauchte_zeit) as avg, anlage_id from wartungen where gebrauchte_zeit is not null and gebrauchte_zeit > 0 group by anlage_id';
			$result = rquery($query);

			while ($row = mysqli_fetch_row($result)) {
				$t_id = $row[3];

				if(is_null($row) || is_null($row[0])) {
					$GLOBALS['get_statistik_gebrauchte_zeit_pro_wartung_cache'][$t_id] = array('&mdash;', '&mdash;', '&mdash;');
				} else {
					$row[2] = sprintf("%.2f", $row[2]);
					$GLOBALS['get_statistik_gebrauchte_zeit_pro_wartung_cache'][$t_id] = $row;
				}
			}
		}

		if(array_key_exists($id, $GLOBALS['get_statistik_gebrauchte_zeit_pro_wartung_cache'])) {
			return $GLOBALS['get_statistik_gebrauchte_zeit_pro_wartung_cache'][$id];
		} else {
			return array('&mdash;', '&mdash;', '&mdash;');
		}
	}

	function get_alternative ($first, $second, $mark_html = 1) {
		if(empty($first)) {
			if($mark_html) {
				return "<i style='color: red;'>$second</i>";
			} else {
				return $second;
			}
		} else {
			return $first;
		}
	}

	function search_for_anything_in_tabelle_get_anlage_ids ($anything) {
		$query = 'select anlage_id from view_anlagen_metadaten where name like '.esc("%$anything%").' or kunde like '.esc("%$anything%").' or plz like '.esc("%$anything%").' or ort like '.esc("%$anything%").' or land like '.esc("%$anything%").' or ansprechpartner_name like '.esc("%$anything%").' or strasse like '.esc("%$anything%").' or material_wartung like '.esc("%$anything%").' or this_anlage_comment like '.esc("%$anything%").' OR anlage_id IN (select id from anlagen where plz like '.esc("%$anything%").' or ort like '.esc("%$anything%").' or kunde_id in (select id from kunden where plz like '.esc("%$anything%").' or ort like '.esc("%$anything%").'))';

		$results = rquery($query);

		$ids = array();

		while ($row = mysqli_fetch_row($results)) {
			$ids[] = $row[0];
		}
		return $ids;
	}

	function termin_id_exists($termin_id) {
		$query = 'select count(*) from wartungen where id = '.esc($termin_id);
		return get_single_value_from_query($query);
	}

	function get_comment_1 ($terminid) {
		$query = 'select comment from wartungen where id = '.esc($terminid);
		return get_single_value_from_query($query);
	}


	function get_comment_2 ($terminid) {
		$query = 'select comment2 from wartungen where id = '.esc($terminid);
		return get_single_value_from_query($query);
	}

	function set_comments ($termin_id, $comment, $comment2) {
		$query = 'update wartungen set comment = '.esc($comment).', comment2 = '.esc($comment2).' where id = '.esc($termin_id);
		if(rquery($query)) {
			success("Die Kommentare wurden eingetragen.");
		} else {
			error("Die Kommentare konnten nicht eingetragen werden.");
		}
	}

	function format_phone ($phone) {
		if(get_setting("format_phone_number") && preg_match("/;/", $phone)) {
			$phone = preg_replace("/(\d)[;,](\d)/", "\1<br>\2", $phone);
		}
		return $phone;
	}

	function get_monat_by_termin_id ($termin_id) {
		$query = "select monat from wartungen where id = ".esc($termin_id);
		return get_single_value_from_query($query);
	}

	function get_jahr_by_termin_id ($termin_id) {
		$query = "select jahr from wartungen where id = ".esc($termin_id);
		return get_single_value_from_query($query);
	}

	function remove_leading_zeroes ($str) {
		$str = preg_replace("/^0+/", "", $str);
		return $str;
	}

	function print_ampel ($frage_id, $add_checkbox = 0, $initialize = 0) {
		$query = 'select show_ampel, red, yellow, green from fragen where id = '.esc($frage_id);
		$row = get_single_row_from_query($query);

		if(!$row) {
			$row = array(0, 0, 0, 0);
		}

		if($initialize) {
			$row = array(1, 0, 0, 0);
			$add_checkbox = 1;
		}

		$show_ampel = $row[0];

		$red = $row[1];
		$yellow = $row[2];
		$green = $row[3];

		if(!$red && !$yellow && !$green) {
			$show_ampel = 0;
		}

		$html = '<table border="0" cellspacing="0">';


		$red_color = "black";
		$red_checkbox = "<td style='font-size: 16px;'><input type='checkbox' name='red'>Rot</td>";
		if($red) {
			$red_color = "red";
			$red_checkbox = "<td style='font-size: 16px;'><input type='checkbox' checked='CHECKED' name='red' />Rot</td>";
		}

		$yellow_color = "black";
		$yellow_checkbox = "<td style='font-size: 16px;'><input type='checkbox' name='yellow'>Gelb</td>";
		if($yellow) {
			$yellow_color = "yellow";
			$yellow_checkbox = "<td style='font-size: 16px;'><input type='checkbox' checked='CHECKED' name='yellow' />Gelb</td>";
		}

		$green_color = "black";
		$green_checkbox = "<td style='font-size: 16px;'><input type='checkbox' name='green'>Grün</td>";
		if($green) {
			$green_color = "green";
			$green_checkbox = "<td style='font-size: 16px;'><input type='checkbox' checked='CHECKED' name='gree' />Grün</td>";
		}

		if(!$add_checkbox) {
			$green_checkbox = "";
			$red_checkbox = "";
			$yellow_checkbox = "";
		}

		$disable_ampel_str = "";
		if(!$show_ampel) {
			$disable_ampel_str = " style='display: none;'";
		}

		$html .= '<tr style="font-size: 0px">'.$red_checkbox.'<td '.$disable_ampel_str.' style="width: 86px; height: 80px; margin: 0px !important; padding: 0px !important; background-color: '.$red_color.'"><img src="i/ampel_roh.png"></td></tr>';
		$html .= '<tr style="font-size: 0px">'.$yellow_checkbox.'<td '.$disable_ampel_str.'  style="width: 86px; margin: 0px !important; padding: 0px !important; background-color: '.$yellow_color.'"><img src="i/ampel_roh.png"></td></tr>';
		$html .= '<tr style="font-size: 0px">'.$green_checkbox.'<td '.$disable_ampel_str.' style="width: 86px; margin: 0px !important; padding: 0px !important; background-color: '.$green_color.'"><img src="i/ampel_roh.png"></td></tr>';

		$html .= "</table>";

		return $html;
	}

	function get_antwort ($frage_id) {
		$antwort = get_single_value_from_query("select antwort from fragen where id = ".esc($frage_id));
		return $antwort;
	}

	function get_show_ampel ($frage_id) {
		return !!get_single_value_from_query("select show_ampel from fragen where id = ".esc($frage_id));
	}

	function update_frage($frage_id, $frage, $antwort, $show_ampel, $red, $yellow, $green) {
		$update_frage_query = "update fragen set frage = ".esc($frage).", antwort = ".esc($antwort).", show_ampel = ".esc($show_ampel).", red = ".esc($red).", yellow = ".esc($yellow).", green = ".esc($green)." where id = ".esc($frage_id);
		rquery($update_frage_query);
	}

	function create_frage($frage, $antwort, $show_ampel, $red, $yellow, $green) {
		$create_frage_query = "insert into fragen (frage, antwort, show_ampel, red, yellow, green) values (".multiple_esc_join(array($frage, $antwort, $show_ampel, $red, $yellow, $green)).")";
		rquery($create_frage_query);
	}

	function delete_frage ($frage_id) {
		$query = "delete from fragen where id = ".esc($frage_id);
		rquery($query);
	}
?>
