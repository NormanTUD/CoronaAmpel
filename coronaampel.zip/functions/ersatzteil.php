<?php
	function get_ersatzteil_name ($id) {
		$query = 'select name from ersatzteil where id = '.esc($id);
		return get_single_value_from_query($query);
	}

	function get_ersatzteil_default_price ($id) {
		$query = 'select default_price from ersatzteil where id = '.esc($id);
		return get_single_value_from_query($query);
	}

	function get_wartung_ersatzteil_price ($wartungs_id, $id) {
		$query = 'select price from wartung_ersatzteil where this_wartung_id = '.esc($wartungs_id).' and this_ersatzteil_id = '.esc($id);
		return get_single_value_from_query($query);
	}

	function get_kunde_ersatzteil_price ($kunde_id, $id) {
		$query = 'select price from kunde_ersatzteil where kunde_id = '.esc($kunde_id).' and ersatzteil_id = '.esc($id);
		return get_single_value_from_query($query);
	}

	function get_ersatzteil_price ($ersatzteil_id, $termin_id) {
		/*
		Suchreihenfolge: 
			- wartung_ersatzteil
			- kunde_ersatzteil
			- ersatzteil
		*/

		$value = get_wartung_ersatzteil_price($termin_id, $ersatzteil_id);
		if(!is_null($value)) {
			return $value;
		} else {
			$anlage_id = get_anlage_id_by_termin_id($termin_id);
			$kunde_id = get_kunde_id_by_anlage_id($anlage_id);
			$value = get_kunde_ersatzteil_price($kunde_id, $ersatzteil_id);
			if(!is_null($value)) {
				return $value;
			} else {
				$value = get_ersatzteil_default_price($ersatzteil_id);
				return $value;
			}
		}
	}

	function sum_of_ersatzteile_prices ($termin_id, $full = 0) {
		$ersatzteile_query = 'select amount, this_ersatzteil_id from wartung_ersatzteil where this_wartung_id = '.esc($termin_id);
		$result = rquery($ersatzteile_query);

		$sum = 0;
		if($full) {
			$sum = get_wartung_kosten($termin_id) + get_wartungspauschale(get_anlage_id_by_termin_id($termin_id));
		}
		while ($row = mysqli_fetch_row($result)) {
			$amount = $row[0];
			$this_ersatzteil_id = $row[1];
			$sum += ($amount * get_ersatzteil_price($this_ersatzteil_id, $termin_id));
		}

		return $sum;
	}

	function update_termin_ersatzteil_2($ersatzteil_id, $anzahl, $termin_id, $spezialpreis) {
		/*
+--------------------+-------------+------+-----+---------+-------+
| Field              | Type        | Null | Key | Default | Extra |
+--------------------+-------------+------+-----+---------+-------+
| amount             | int(11)     | YES  |     | 1       |       |
| this_wartung_id    | int(11)     | NO   | PRI | NULL    |       |
| this_ersatzteil_id | int(11)     | NO   | PRI | NULL    |       |
| price              | float(10,2) | YES  |     | NULL    |       |
+--------------------+-------------+------+-----+---------+-------+
		 */

		$spezialpreis = string_to_number($spezialpreis);
		$anzahl = string_to_number($anzahl);

		if($anzahl > 0) {
			$query = "insert into wartung_ersatzteil (amount, this_wartung_id, this_ersatzteil_id, price) values (".esc($anzahl).", ".esc($termin_id).", ".esc($ersatzteil_id).", ".esc($spezialpreis).") on duplicate key update price = values(price), amount = values(amount)";
			if(rquery($query)) {
				success("Das Ersatzteil ".fq(get_ersatzteil_name($ersatzteil_id))." konnte erfolgreich eingetragen werden");
			} else {
				error("Das Ersatzteil konnte leider nicht eingetragen werden");
			}
		} else {
			$query = "delete from wartung_ersatzteil where this_wartung_id = ".esc($termin_id)." and this_ersatzteil_id = ".esc($ersatzteil_id);
			if(rquery($query)) {
				success("Das Ersatzteil ".fq(get_ersatzteil_name($ersatzteil_id))." konnte erfolgreich entfernt werden");
			} else {
				error("Das Ersatzteil konnte leider nicht entfernt werden");
			}
		}
	}

	function update_termin_ersatzteil($ersatzteil_id, $anzahl, $termin_id, $spezialpreis) {
		/*
+--------------------+-------------+------+-----+---------+-------+
| Field              | Type        | Null | Key | Default | Extra |
+--------------------+-------------+------+-----+---------+-------+
| amount             | int(11)     | YES  |     | 1       |       |
| this_wartung_id    | int(11)     | NO   | PRI | NULL    |       |
| this_ersatzteil_id | int(11)     | NO   | PRI | NULL    |       |
| price              | float(10,2) | YES  |     | NULL    |       |
+--------------------+-------------+------+-----+---------+-------+
		 */

		$spezialpreis = string_to_number($spezialpreis);
		$anzahl = string_to_number($anzahl);

		$old_amount = get_amount_ersatzteile_from_termin_and_ersatzteil_id($termin_id, $ersatzteil_id);

		if($old_amount + $anzahl > 0) {
			$query = "insert into wartung_ersatzteil (amount, this_wartung_id, this_ersatzteil_id, price) values (".esc($anzahl).", ".esc($termin_id).", ".esc($ersatzteil_id).", ".esc($spezialpreis).") on duplicate key update price = values(price), amount = amount + values(amount)";
			if(rquery($query)) {
				success("Das Ersatzteil ".fq(get_ersatzteil_name($ersatzteil_id))." konnte erfolgreich eingetragen werden");
			} else {
				error("Das Ersatzteil konnte leider nicht eingetragen werden");
			}
		} else {
			$query = "delete from wartung_ersatzteil where this_wartung_id = ".esc($termin_id)." and this_ersatzteil_id = ".esc($ersatzteil_id);
			if(rquery($query)) {
				success("Das Ersatzteil ".fq(get_ersatzteil_name($ersatzteil_id))." konnte erfolgreich entfernt werden");
			} else {
				error("Das Ersatzteil konnte leider nicht entfernt werden");
			}
		}
	}

	function get_ersatzteil_id_by_name_and_price ($name, $price) {
		$query = 'select id from ersatzteil where name = '.esc($name);
		if(is_null($price)) {
			$query .= ' and default_price is null';
		} else {
			$query .= ' and default_price = '.esc($price);
		}
		return get_single_value_from_query($query);
	}

	function create_ersatzteil ($name, $default_price = null, $kundendaten = array()) {
		$default_price = string_to_number($default_price);
		if(!empty($name)) {
			$query = 'insert into ersatzteil (name, default_price) values ('.esc($name).', '.esc($default_price).') on duplicate key update default_price = values(default_price), name = values(name)';
			if(rquery($query)) {
				$last_id = get_ersatzteil_id_by_name_and_price($name, $default_price);
				if(array_key_exists('kunde_id', $kundendaten) && array_key_exists('kunde_price', $kundendaten)) {
					$kundendaten['kunde_price'] = string_to_number($kundendaten['kunde_price']);
					$query = 'insert into kunde_ersatzteil (kunde_id, ersatzteil_id, price) values ('.esc($kundendaten['kunde_id']).', '.esc($last_id).', '.esc($kundendaten['kunde_price']).') on duplicate key update price = values(price)';
					if(rquery($query)) {
						success("Ok, Ersatzteil &raquo;$name&laquo; erstellt");
					} else {
						error("Konnte Ersatzteil &raquo;$name&laquo; nicht erstellen, sorry...");
					}
				} else {
					success("Ok, Ersatzteil &raquo;$name&laquo; erstellt");
				}
			} else {
				error("Konnte Ersatzteil &raquo;$name&laquo; nicht erstellen, sorry...");
			}
		} else {
			error("Leere Ersatzteilnamen sind nicht erlaubt");
		}
	}

	function update_ersatzteil ($id, $name, $default_price, $kundendaten = array()) {
		$default_price = string_to_number($default_price);
		$query = 'update ersatzteil set default_price = '.esc($default_price).' where id = '.esc($id);
		if(rquery($query)) {
			if(array_key_exists('kunde_id', $kundendaten) && array_key_exists('kunde_price', $kundendaten)) {
				$kundendaten['kunde_price'] = string_to_number($kundendaten['kunde_price']);
				$query = 'insert into kunde_ersatzteil (kunde_id, ersatzteil_id, price) values ('.esc($kundendaten['kunde_id']).', '.esc($id).', '.esc($kundendaten['kunde_price']).') on duplicate key update price = values(price)';
				if(rquery($query)) {
					success("Ok, Ersatzteil &raquo;$name&laquo; geändert");
				} else {
					error("Konnte Ersatzteil &raquo;$name&laquo; nicht ändern, sorry...");
				}
			} else {
				success("Ok, Ersatzteil &raquo;$name&laquo; geändert");
			}
		} else {
			error("Konnte Ersatzteil &raquo;$name&laquo; nicht ändern, sorry...");
		}
	}

	function get_ersatzteile_ids_from_termin ($termin_id) {
		$query = 'select this_ersatzteil_id from wartung_ersatzteil where this_wartung_id = '.esc($termin_id);
		$result = rquery($query);
		$ersatzteile_ids = array();

		while ($row = mysqli_fetch_row($result)) {
			$ersatzteile_ids[] = $row[0];
		}
		return $ersatzteile_ids;
	}

	function get_amount_ersatzteile_from_termin_and_ersatzteil_id ($termin_id, $ersatzteil_id) {
		$query = 'select amount from wartung_ersatzteil where this_wartung_id = '.esc($termin_id).' and this_ersatzteil_id = '.esc($ersatzteil_id);
		return get_single_value_from_query($query);
	}

	function get_number_of_ersatzteile () {
		$query = 'select count(*) from ersatzteil';
		return get_single_value_from_query($query);
	}


?>
