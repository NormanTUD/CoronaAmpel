<?php
	function get_account_enabled_by_id ($id) {
		$query = 'select enabled from users where id = '.esc($id);
		$id = get_single_value_from_query($query);

		return $id;
	}

	if($GLOBALS['logged_in']) { // Wichtig, damit Niemand ohne Anmeldung etwas ändern kann
		// Falls eine ID gegeben ist, dann sind bereits Daten vorhanden, die editiert oder gelöscht werden sollen.


		if(get_post('verschiebe_anlage')) {
			$anlage_id = get_post('anlage_id');
			$neue_firma_id = get_post('neue_firma_id');

			$query = 'update anlagen set kunde_id = '.esc($neue_firma_id).' where id = '.esc($anlage_id);;
			if(rquery($query)) {
				success("Anlage wurde auf den neuen Kunden verschoben");
			} else {
				error("Anlage wurde NICHT auf den neuen Kunden verschoben");
			}
		}

		if(get_post('update_wartung_via_map')) {
			$wartung_id = get_post('update_wartung_via_map');
			$status_id = get_post('aendere_status');
			$kommentar1 = get_post('kommentar1');
			$kommentar2 = get_post('kommentar2');

			update_wartung_via_map($wartung_id, $status_id, $kommentar1, $kommentar2);
		}

		if(!is_null(get_post('id')) || !is_null(get_get('id'))) {
			$this_id = get_post('id');
			if(!$this_id) {
				$this_id = get_get('id');
			}
			if(get_post('delete') && !get_post('delete_for_sure')) {
				/*
					Festlegung der Tabellen, aus denen etwas gelöscht werden soll.
				 */
				$GLOBALS['deletion_page'] = 1;

				$GLOBALS['deletion_where'] = array('id' => $this_id);

				if(get_post('funktion_name')) {
					$GLOBALS['deletion_db'] = 'function_rights';
				}

				if(get_post('update_status')) {
					$GLOBALS['deletion_db'] = 'status';
				}

				if(get_post('update_turnus')) {
					$GLOBALS['deletion_db'] = 'turnus';
				}

				if(get_post('update_anlage')) {
					$GLOBALS['deletion_db'] = 'anlagen';
				}

				if(get_post('update_kunde')) {
					$GLOBALS['deletion_db'] = 'kunden';
				}

				if(get_post('update_wartungstermine')) {
					$GLOBALS['deletion_db'] = 'kunden';
				}

				if(get_post('neue_rolle') && get_post('page')) {
					$GLOBALS['deletion_db'] = 'role';
				}

				if(get_post('name') && get_post('id') && get_post('role')) {
					$GLOBALS['deletion_db'] = 'users';
				}

				if(get_post('updatepage') && get_post('id')) {
					$GLOBALS['deletion_db'] = 'page';
				}

				if(get_post('update_ersatzteil') && get_post('id')) {
					$GLOBALS['deletion_db'] = 'ersatzteil';
				}
			} else {
				if(get_post('update_ersatzteil') && get_post('ersatzteil_name')) {
					$kundendaten = array();
					if(get_get('kunde') && get_get('kunde') != "alle" && get_post('kunden_price')) {
						$kunde_id = get_get('kunde');
						$kunde_price = get_post('kunden_price');
						$kundendaten = array(
							'kunde_id' => $kunde_id,
							'kunde_price' => $kunde_price
						);
					}

					update_ersatzteil(get_post('id'), get_post("ersatzteil_name"), get_post("default_price"), $kundendaten);
				}

				if(get_post('update_anlage') && get_post('delete') && get_post('id')) {
					delete_anlage(get_post('id'));
				}

				if(get_post('update_ersatzteil') && get_post('delete') && get_post('id')) {
					delete_ersatzteil(get_post('id'));
				}

				foreach ($_POST as $this_post_key => $this_post_value) {
					if (preg_match('/^update_anlage_(\d+)_for_(\d+)$/', $this_post_key, $founds)) {
						$anlage_id = $founds[1];
						$kunde_id = $founds[2];
						$name = get_post($founds[0]);

						$turnus = get_post('turnus');
						$ibn_beendet_am = get_post('ibn_beendet_am');
						$letzte_wartung = get_post('letzte_wartung');
						$ende_gewaehrleistung = get_post('ende_gewaehrleistung');
						$this_anlage_comment = get_post('this_anlage_comment');
						$wartungspauschale = get_post('wartungspauschale');

						$ansprechpartner_email = get_post('ansprechpartner_email');
						$ansprechpartner_telnr = get_post('ansprechpartner_telnr');
						$ansprechpartner_name = get_post('ansprechpartner_name');
						$ansprechpartner_id = get_or_create_ansprechpartner($ansprechpartner_email, $ansprechpartner_telnr, $ansprechpartner_name);

						$zeit_pro_wartung = get_post('zeit_pro_wartung');

						$plz = get_post("plz");
						$ort = get_post("ort");
						$strasse = get_post("strasse");
						$hausnummer = get_post("hausnummer");
						$land = get_post("land");

						$material_wartung = get_post("material_wartung");

						update_anlage($anlage_id, $name, $turnus, $ibn_beendet_am, $letzte_wartung, $ende_gewaehrleistung, $this_anlage_comment, $wartungspauschale, $ansprechpartner_id, $zeit_pro_wartung, $plz, $ort, $strasse, $hausnummer, $land, $material_wartung);
					}
				}

				if(get_post('update_status')) {
					$id = get_post('id');
					if(!get_post('delete')) {
						$name = get_post('name');
						$color = get_post('color');
						update_status($id, $name, $color);
					} else {
						delete_status($id);
					}
				}

				if(get_post('update_turnus')) {
					$id = get_post('id');
					if(!get_post('delete')) {
						$name = get_post('name');
						$anzahl_monate = get_post('anzahl_monate');
						$wartungen_pro_monat = get_post('wartungen_pro_monat');
						update_turnus($id, $name, $anzahl_monate, $wartungen_pro_monat);
					} else {
						delete_turnus($id);
					}
				}

				if(get_post('newpage')) {
					$titel = get_post('titel');
					$datei = get_post('datei');
					$show_in_navigation = get_post('show_in_navigation') ? 1 : 0;
					$eltern = get_post('eltern') ? get_post('eltern') : '';
					$role_to_page = get_post('role_to_page');
					$beschreibung = get_post('beschreibung') ? get_post('beschreibung') : '';
					$hinweis = get_post('hinweis') ? get_post('hinweis') : '';

					if(isset($titel) && isset($datei) && isset($show_in_navigation) && isset($eltern) && isset($role_to_page) && isset($beschreibung) && isset($hinweis)) {

						create_new_page($titel, $datei, $show_in_navigation, $eltern, $role_to_page, $beschreibung, $hinweis);
					} else {
						error('Missing parameters!');
					}
				}

				if(get_post('updatepage')) {
					$id = get_post('id');
					if(get_post('delete')) {
						if(isset($id)) {
							delete_page($id);
						}
					} else {
						$titel = get_post('titel');
						$datei = get_post('datei');
						$show_in_navigation = get_post('show_in_navigation') ? 1 : 0;
						$eltern = get_post('eltern') ? get_post('eltern') : '';
						$role_to_page = get_post('role_to_page');
						$beschreibung = get_post('beschreibung') ? get_post('beschreibung') : '';
						$hinweis = get_post('hinweis') ? get_post('hinweis') : '';

						if(isset($id) && isset($titel) && isset($role_to_page)) {
							update_page_full($id, $titel, $datei, $show_in_navigation, $eltern, $role_to_page, $beschreibung, $hinweis);
						} else {
							error('Missing parameters!');
						}
					}
				}

				if(get_post('funktion_name')) {
					if(get_post('delete')) {
						delete_funktion_rights($this_id);
					} else {
						update_funktion_rights($this_id, get_post('funktion_name'));
					}
				}

				if(get_post('update_page_info')) {
					update_page_info(get_post('id'), get_post('info'));
				}

				if(get_post_multiple_check(array('name', 'plz', 'ort')) && !get_post('delete') && !get_post("update_kunde")) {
					$name = get_post('name');
					$plz = get_post('plz');
					$ort = get_post('ort');
					$strasse = get_post('strasse');
					$hausnummern = get_post('hausnummern');
					$erinnerung = get_post('erinnerung');
					$pruefung = get_post("pruefung");
					$pruefung_abgelehnt = get_post("pruefung_abgelehnt");
					$phone = get_post("telefon");
					$email = get_post("email");
					$land = get_post("land");
					create_kunde($name, $plz, $ort, $strasse, $hausnummern, $erinnerung, $pruefung, $pruefung_abgelehnt, $phone, $email, $land);
				} else if (get_post('new_user')) {
					warning('Benutzer müssen einen Namen, ein Passwort und eine Rolle haben. ');
				}


				if(get_post('neue_rolle') && get_post('page')) {
					if(get_post('delete')) {
						delete_role($this_id);
					} else {
						update_role($this_id, get_post('neue_rolle'));
						$query = 'DELETE FROM `role_to_page` WHERE `role_id` = '.esc(get_role_id(get_post('neue_rolle')));;
						rquery($query);
						foreach (get_post('page') as $key => $this_page_id) {
							if(preg_match('/^\d+$/', $this_page_id)) {
								assign_page_to_role(get_role_id(get_post('neue_rolle')), $this_page_id);
							}
						}
					}
				}

				if(get_post('id') && get_post('update_kunde')) {
					if(get_post('delete')) {
						delete_kunde(get_post('id'));
					} else {
						$id = get_post("id");
						$name = get_post("name");
						$plz = get_post("plz");
						$ort = get_post("ort");
						$strasse = get_post("strasse");
						$hausnummern = get_post("hausnummern");
						$ibn_beendet_am = get_post("ibn_beendet_am");
						$turnus = get_post("turnus");
						$letzte_wartung = get_post("letzte_wartung");
						$erinnerung = get_post('erinnerung');
						$pruefung = get_post('pruefung');
						$pruefung_abgelehnt = get_post("pruefung_abgelehnt");
						$phone = get_post("telefon");
						$email = get_post("email");
						$land = get_post("land");

						update_kunde($id, $name, $plz, $ort, $strasse, $hausnummern, $erinnerung, $pruefung, $pruefung_abgelehnt, $phone, $email, $land);
					}
				}

				if(get_post('name') && get_post('id') && get_post('role')) {
					if(get_post('delete')) {
						delete_user($this_id);
					} else {
						$enabled = get_account_enabled_by_id($this_id);
						if(get_post('disable_account')) {
							$enabled = 0;
						}

						if(get_post('enable_account')) {
							$enabled = 1;
						}

						$accpubdata = 1;
						if(get_post('accepted_public_data')) {
							$accpubdata = 1;
						}

						update_user(get_post('name'), get_post('id'), get_post('password'), get_post('role'), $enabled, $accpubdata);
					}
				}
			}
		} else {
			if(get_post('update_gebrauchte_zeit_pro_wartung') && get_post('termin_id')) {
				$termin_id = get_post("termin_id");
				$update_zeit_pro_wartung = get_post("update_zeit_pro_wartung");
				add_gebrauchte_zeit_zu_wartung($termin_id, $update_zeit_pro_wartung);
			}

			if(get_post('edit_ersatzteil') && get_post('update_termin_ersatzteil')) {
				$ersatzteil_id = get_post('edit_ersatzteil');
				$anzahl = get_post('amount');
				$spezialpreis = get_post('spezialpreis');
				$termin_id = get_get('terminid');
				update_termin_ersatzteil_2($ersatzteil_id, $anzahl, $termin_id, $spezialpreis);
			}

			#dier($_POST);
			if(get_post('create_ersatzteil') && get_post('ersatzteil_name')) {
				$kundendaten = array();
				if(get_get('kunde') && get_get('kunde') != "alle" && get_post('kunden_price')) {
					$kunde_id = get_get('kunde');
					$kunde_price = get_post('kunden_price');
					$kundendaten = array(
						'kunde_id' => $kunde_id,
						'kunde_price' => $kunde_price
					);
				}
				create_ersatzteil(get_post("ersatzteil_name"), get_post("default_price"), $kundendaten);
			}

			if(get_post('disable_termin') && !is_null(get_post('termin_id'))) {
				$termin_id = get_post('termin_id');

				disable_termin($termin_id);
			}

			if(get_post('disable_termin') && !is_null(get_post('termin_id'))) {
				$termin_id = get_post('termin_id');

				disable_termin($termin_id);
			}

			if(get_post('new_termin') && !is_null(get_post('anlage_id')) && get_post('monat') && get_post('year')) {
				$anlage_id = get_post('anlage_id');
				$monat = get_post('monat');
				$year = get_post('year');

				insert_wartungstermin($anlage_id, $monat, $year);
			}

			if(get_post('terminid') && get_post('new_jahr') && get_post('new_monat')) {
				verschiebe_termin(get_post('terminid'), get_post('new_jahr'), get_post('new_monat'), get_post('verschiebe_spaetere'));
			}

			if(get_post('terminid') && get_post('monat_diff')) {
				verschiebe_termin_um_monat(get_post('terminid'), get_post('monat_diff'), get_post('verschiebe_spaetere'));
			}

			if(get_post('create_anlage_page')) {
				foreach ($_POST as $this_post_key => $this_post_value) {
					if(preg_match('/^create_anlage_for_(\d+)/', $this_post_key, $founds)) {
						$name = get_post($founds[0]);
						$kunde_id = $founds[1];

						$turnus_id = get_post('turnus');
						$ibn_beendet_am = get_post('ibn_beendet_am');
						$letzte_wartung = get_post('letzte_wartung');
						$ende_gewaehrleistung = get_post('ende_gewaehrleistung');
						$this_anlage_comment = get_post('this_anlage_comment');
						$default_status_id = get_post('default_status_id');
						$wartungspauschale = get_post('wartungspauschale');

						$ansprechpartner_email = get_post('ansprechpartner_email');
						$ansprechpartner_telnr = get_post('ansprechpartner_telnr');
						$ansprechpartner_name = get_post('ansprechpartner_name');
						$ansprechpartner_id = get_or_create_ansprechpartner($ansprechpartner_email, $ansprechpartner_telnr, $ansprechpartner_name);

						$zeit_pro_wartung = get_post("zeit_pro_wartung");

						$plz = get_post("plz");
						$ort = get_post("ort");
						$strasse = get_post("strasse");
						$hausnummer = get_post("hausnummer");
						$land = get_post("land");

						$material_wartung = get_post("material_wartung");


						create_anlage($kunde_id, $name, $turnus_id, $ibn_beendet_am, $letzte_wartung, $ende_gewaehrleistung, $this_anlage_comment, $default_status_id, $wartungspauschale, $ansprechpartner_id, $zeit_pro_wartung, $plz, $ort, $strasse, $hausnummer, $land, $material_wartung);
					} else if (preg_match('/^update_anlage_(\d+)_for_(\d+)$/', $this_post_key, $founds)) {
						$anlage_id = $founds[1];
						$kunde_id = $founds[2];
						$name = get_post($founds[0]);

						$turnus = get_post('turnus');
						$ibn_beendet_am = get_post('ibn_beendet_am');
						$letzte_wartung = get_post('letzte_wartung');
						$ende_gewaehrleistung = get_post('ende_gewaehrleistung');
						$this_anlage_comment = get_post('this_anlage_comment');
						$wartungspauschale = get_post('wartungspauschale');

						$ansprechpartner_email = get_post('ansprechpartner_email');
						$ansprechpartner_telnr = get_post('ansprechpartner_telnr');
						$ansprechpartner_name = get_post('ansprechpartner_name');
						$ansprechpartner_id = get_or_create_ansprechpartner($ansprechpartner_email, $ansprechpartner_telnr, $ansprechpartner_name);

						$zeit_pro_wartung = get_post('zeit_pro_wartung');

						$plz = get_post("plz");
						$ort = get_post("ort");
						$strasse = get_post("strasse");
						$hausnummer = get_post("hausnummer");
						$land = get_post("land");

						$material_wartung = get_post("material_wartung");

						$GLOBALS['ibn_beendet_cache'] = array();
						update_anlage($anlage_id, $name, $turnus_id, $ibn_beendet_am, $letzte_wartung, $ende_gewaehrleistung, $this_anlage_comment, $wartungspauschale, $ansprechpartner_id, $zeit_pro_wartung, $plz, $ort, $strasse, $hausnummer, $land, $material_wartung);
						$GLOBALS['ibn_beendet_cache'] = array();
					}
				}
			}

			if(get_post('update_wartungstermine')) {
				$termine = array();
				$kommentare = array();
				$kommentare2 = array();

				foreach ($_POST as $this_get_key => $this_get_value) {
					if(preg_match('/(kommentar2?|termin)_(\d+)/', $this_get_key, $founds)) {
						$type = $founds[1];
						$id = $founds[2];

						if($type == 'termin') {
							if(preg_match('/^\d+$/', $this_get_value)) {
								$termine[$id] = $this_get_value;
							} else {
								error('Invalider Datentyp für Status!');
							}
						} else if ($type == 'kommentar') {
							if(preg_match('/.+/', $this_get_value)) {
								$kommentare[$id] = $this_get_value;
							}
						} else if ($type == 'kommentar2') {
							if(preg_match('/^.+/', $this_get_value)) {
								$kommentare2[$id] = $this_get_value;
							}

						}
					}
				}

				if(count($termine)) {
					update_wartungstermine($termine, $kommentare, $kommentare2);
				} else {
					warning("ACHTUNG: update_wartungstermine wird nicht ausgeführt, weil keine \$termine gefunden werden konnten! Bitte melde mir das!");
				}
			}

			if(get_post('update_setting')) {
				if(get_post('reset_setting')) {
					reset_setting(get_post('name'));
				} else {
					set_setting(get_post('name'), get_post('value'), get_post("description"));
				}
			}

			if(get_post("sqlinserter")) {
				$query_array = preg_split("/\n|;/", get_post("sqlinserter"));
				foreach ($query_array as $this_query) {
					if(!preg_match("/^\s*$/", $this_query)) {
						rquery($this_query);
					}
				}
			}

			if(get_post('create_status')) {
				create_status(get_post('new_name'), get_post('new_color'));
			}

			if(get_post('create_turnus')) {
				create_turnus(get_post('new_name'), get_post('new_anzahl_monate'), get_post('new_wartungen_pro_monat'));
			}

			if(get_post('merge_data')) {
				if(get_get('table') && get_post('merge_from') && get_post('merge_to')) {
					merge_data(get_get('table'), get_post('merge_from'), get_post('merge_to'));
				} else {
					error(' Sowohl eine bzw. mehrere Quelle als auch ein Zielort müssen angegeben werden.');
				}
			}

			if(get_post('new_function_right')) {
				$role_id = get_post('role_id');
				if($role_id) {
					$funktion_name = get_post('funktion_name');
					if($funktion_name) {
						create_function_right($role_id, $funktion_name);
					} else {
						error('Die Funktion konnte nicht angelegt werden, da sie keinen validen Namen zugeordnet bekommen hat. ');
					}
				} else {
					error('Die Funktion konnte nicht angelegt werden, da sie keiner Rolle zugeordnet wurden ist. ');
				}
			}

			if(get_post('import_datenbank')) {
				if(array_key_exists('sql_file', $_FILES) && array_key_exists('tmp_name', $_FILES['sql_file'])) {
					SplitSQL($_FILES['sql_file']['tmp_name']);
				}
			}

			if(get_post('datenbankvergleich')) {
				if(array_key_exists('sql_file', $_FILES) && array_key_exists('tmp_name', $_FILES['sql_file'])) {
					$GLOBALS['compare_db'] = compare_db($_FILES['sql_file']['tmp_name']);
				}
			}

			if(get_post('change_own_data')) {
				$new_password = get_post('password');
				$new_password_repeat = get_post('password_repeat');
				if($new_password && strlen($new_password) >= 5) {
					if($new_password == $new_password_repeat) {
						update_own_data($new_password);
					} else {
						error('Beide Passworteingaben müssen identisch sein. ');
					}
				} else {
					error('Das Passwort muss mindestens 5 Zeichen haben.');
				}
			}

			if(get_post('startseitentext')) {
				$startseitentext = get_post('startseitentext');
				update_startseitentext($startseitentext);
			}

			if(get_post('update_text') && get_post('page_id')) {
				update_text(get_post('page_id'), get_post('text'));
			}

			if(get_post('update_hinweis') && get_post('page_id')) {
				update_hinweis(get_post('page_id'), get_post('hinweis'));
			}

			if(get_post('update_wartung_preis')) {
				$wartung_id = get_post("wartung_id");
				$wartung_kosten = get_post("wartung_kosten");
				set_wartung_kosten($wartung_id, $wartung_kosten);
			}

			if(get_post('update_termin_ersatzteil')) {
				$ersatzteil_id = get_post('neues_ersatzteil');
				$anzahl = get_post('anzahl');
				$termin_id = get_get('terminid');
				$spezialpreis = get_post("spezialpreis");

				update_termin_ersatzteil($ersatzteil_id, $anzahl, $termin_id, $spezialpreis);
			}

			if(get_post_multiple_check(array('new_user', 'name', 'password', 'role'))) {
				create_user(get_post('name'), get_post('password'), get_post('role'));
			} else if (get_post('new_user')) {
				warning('Benutzer müssen einen Namen, ein Passwort und eine Rolle haben. ');
			}

			if(get_post('create_new_kunde')) {
				$name = get_post('name');
				$plz = get_post('plz');
				$ort = get_post('ort');
				$strasse = get_post('strasse');
				$hausnummern = get_post('hausnummern');

				$erinnerung = get_post('erinnerung');
				$pruefung = get_post('pruefung');
				$pruefung_abgelehnt = get_post('pruefung_abgelehnt');

				$email = get_post("email");
				$phone = get_post("telefon");

				$land = get_post("land");

				create_kunde($name, $plz, $ort, $strasse, $hausnummern, $erinnerung, $pruefung, $pruefung_abgelehnt, $phone, $email, $land);
			}

			if(get_post('neue_rolle') && get_post('page')) {
				create_role(get_post('neue_rolle'));
				// Alle alten Rollendaten löschen
				$query = 'DELETE FROM `role_to_page` WHERE `role_id` = '.esc(get_role_id(get_post('neue_rolle')));
				rquery($query);
				foreach (get_post('page') as $key => $this_page_id) {
					if(preg_match('/^\d+$/', $this_page_id)) {
						assign_page_to_role(get_role_id(get_post('neue_rolle')), $this_page_id);
					}
				}
			}
		}
	}
?>
