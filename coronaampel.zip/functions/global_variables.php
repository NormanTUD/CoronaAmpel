<?php
	$GLOBALS['insert_anlage_failed'] = 0;
	$GLOBALS['error'] = array();
	$GLOBALS['mysql_error'] = array();
	$GLOBALS['hint'] = array();
	$GLOBALS['message'] = array();
	$GLOBALS['warning'] = array();
	$GLOBALS['mysql_warning'] = array();
	$GLOBALS['trash'] = array();
	$GLOBALS['success'] = array();
	$GLOBALS['debug'] = array();
	$GLOBALS['easter_egg'] = array();
	$GLOBALS['number_of_non_month_columns'] = 9;
	$GLOBALS['import_table'] = '';
	$GLOBALS['return_null_if_anlage_creation_failed'] = 1;

	$GLOBALS['compare_db'] = '';

	$GLOBALS['end_html'] = 1;

	$GLOBALS['slurped_sql_file'] = 0;

	$GLOBALS['deletion_page'] = 0;

	$GLOBALS['rquery_print'] = 0;

	$GLOBALS['already_deleted_old_session_ids'] = 0;

	$GLOBALS['submenu_id'] = null;

	$GLOBALS['queries'] = array();
	$GLOBALS['function_usage'] = array();

	$GLOBALS['dbh'] = '';
	$GLOBALS['right_issue'] = array();
	$GLOBALS['reload_page'] = 0;

	$GLOBALS['get_naechste_wartung_cache'][0] = array();
	$GLOBALS['get_naechste_wartung_cache'][1] = array();
	$GLOBALS['create_select_for_kunden_cache'] = array();
	$GLOBALS['ibn_beendet_cache'] = array();
	$GLOBALS['anlagendaten_cache'] = array();
	$GLOBALS['get_erinnerung_pruefung_and_pruefung_ortsfester_anlagen_cache'] = array();
	$GLOBALS['get_anzahl_anlagen_pro_kunde_cache_old'] = array();
	$GLOBALS['get_anzahl_anlagen_pro_kunde_cache'] = array();
	$GLOBALS['get_letzte_wartung_cache'] = array();
	$GLOBALS['get_letzte_wartung_cache'][0] = array();
	$GLOBALS['get_letzte_wartung_cache'][1] = array();
	$GLOBALS['get_anlagen_cache'] = array();
	$GLOBALS['get_anlagen_data_cache'] = array();
	$GLOBALS['get_turnus_cache'] = array();
	$GLOBALS['termin_already_exists_cache'] = array();
	$GLOBALS['get_year_month_from_termin_id_cache'] = array();
	$GLOBALS['user_role_cache'] = array();
	$GLOBALS['settings_cache'] = array();
	$GLOBALS['table_exists_cache'] = array();
	$GLOBALS['db_exists_cache'] = array();
	$GLOBALS['get_ende_gewaehrleistung_cache'][0][0] = array();
	$GLOBALS['get_ende_gewaehrleistung_cache'][0][1] = array();
	$GLOBALS['get_ende_gewaehrleistung_cache'][1][0] = array();
	$GLOBALS['get_ende_gewaehrleistung_cache'][1][1] = array();
	$GLOBALS['get_ansprechpartner_daten_cache'] = array();
	$GLOBALS['get_turnus_name_by_id_cache'] = array();
	$GLOBALS['create_select_for_status_array'] = array();
	$GLOBALS['get_ansprechpartner_telnr_cache'] = array();
	$GLOBALS['get_ansprechpartner_email_cache'] = array();
	$GLOBALS['get_ansprechpartner_name_cache'] = array();
	$GLOBALS['status_color_cache'] = array();

	$GLOBALS['memoize'] = array();

	$GLOBALS['logged_in_was_tried'] = 0;
	$GLOBALS['logged_in'] = 0;
	$GLOBALS['logged_in_user_id'] = NULL;
	$GLOBALS['logged_in_data'] = NULL;
	$GLOBALS['accepted_public_data'] = NULL;

	$GLOBALS['pages'] = array();
?>
